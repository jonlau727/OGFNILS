#pragma once
// OGFNIL companion — observation-only launcher/game integration.
//
// Scope contract (hard project rule): this module discovers executables on
// disk, observes running process NAMES via Toolhelp32 snapshots, and uses the
// most restricted process right (PROCESS_QUERY_LIMITED_INFORMATION) solely to
// confirm a running image path — no memory access of any kind. Launching uses
// ShellExecuteW "open", identical to a desktop shortcut. It never reads or
// writes another process's memory, never touches its windows or input, never
// modifies game files, and never interacts with anti-cheat.
//
// Everything the synthetic ESP/aim/trigger simulations do stays inside this
// process and is untouched by game state.
#include <string>
#include <vector>
#include <chrono>

namespace sfs4::ogfnil {

// Canonical image names we watch for (case-insensitive comparison).
constexpr const wchar_t* kLauncherExe = L"ogfnil_launcher.exe";
constexpr const wchar_t* kGameExe     = L"FortniteClient-Win64-Shipping.exe";

struct ProcessInfo {
  unsigned long pid = 0;
};

// Snapshot scan: every process whose base name matches `exe_name`
// (case-insensitive). Opens no process handles.
std::vector<ProcessInfo> find_processes_by_name(const wchar_t* exe_name);

// Confirms the running image path of `pid` equals `expected_path`
// (case-insensitive). False on access denied, mismatch, or exit.
bool pid_matches_path(unsigned long pid, const std::wstring& expected_path);

// Version resource ("4.30.0.0" style) read from the executable FILE on disk.
// Empty when the file is missing or carries no version resource.
std::wstring file_version(const std::wstring& exe_path);

// Auto-detection: checks standard install locations only —
//   launcher: %LocalAppData%\OG FN IL Launcher\ogfnil_launcher.exe
//   game:     %USERPROFILE%\Documents\ogfnil\<ver>\FortniteGame\Binaries\Win64\FortniteClient-Win64-Shipping.exe
// Empty string when not found. A config-supplied path always wins.
std::wstring detect_launcher_path();
std::wstring detect_game_path();

// Starts the launcher normally (ShellExecuteW "open", default elevation
// semantics). Returns empty on success, else a user-readable error.
std::string launch_launcher(const std::wstring& launcher_path);

// ---- lifecycle monitor -------------------------------------------------------

enum class ProcState { Unknown, Stopped, Running };
enum class Transition { None, Started, Stopped };

struct TargetState {
  ProcState state = ProcState::Unknown;
  std::vector<unsigned long> pids;
  std::chrono::system_clock::time_point last_change{};
  unsigned long restarts = 0;       // started transitions after first observation
  bool unexpected_exit = false;     // vanished while being watched
};

struct Paths {
  std::wstring launcher;            // empty = not configured/detected (yet)
  std::wstring game;
};

struct Snapshot {
  Paths paths;
  TargetState launcher;
  TargetState game;
  std::wstring game_version;
  bool monitor_running = false;
  std::string last_error;           // empty = healthy
  std::string last_event;           // human-readable, e.g. "game started (pid 1234)"
  std::chrono::system_clock::time_point last_event_at{};
};

// Pure transition logic — unit-testable without any real process.
// `first_observation` seeds the state silently: the first poll never counts
// as a restart and never flags an unexpected exit. A name match that fails
// path confirmation is treated as "not our target" (state stays Stopped).
// Returns the transition so callers can react to game starts.
Transition apply_observation(TargetState& st, const std::vector<ProcessInfo>& now,
                             bool path_confirmed, bool first_observation,
                             const char* label, std::string& event_out);

// Monitor thread body: 2s poll loop, exits when request_stop() is called.
void monitor_thread();
void request_stop();

// Thread-safe copy for the UI.
Snapshot snapshot();

// UI actions (all internally synchronized).
void configure(const Paths& p);     // new paths + cache invalidation + re-poll
void refresh_now();                 // immediate re-poll
void note_event(const std::string& msg);  // surface a UI-side action in the event line

// Consumed once per game start transition (profile auto-apply hook).
bool consume_game_start();

} // namespace sfs4::ogfnil
