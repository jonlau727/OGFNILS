// sfs4_sign — keygen / license signing / manifest signing / verify CLI.
// Replaces the Phase-1 PowerShell signing scripts; one tool, one crypto path
// (Ed25519 via vendored TweetNaCl). The secret key never leaves the operator
// machine; only verify.pub ships with the product.
//
// Usage:
//   sfs4_sign keygen <pub-out> <sec-out>
//   sfs4_sign sign-license <license.json> <sec-key> <out.json>
//   sfs4_sign sign-manifest <manifest.json> <sec-key>
//   sfs4_sign verify <canonical-string> <sig-b64> <pub-key>

#include "core/ed25519.hpp"
#include <nlohmann/json.hpp>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>

using json = nlohmann::json;
using namespace sfs4::ed;

static std::string read_file(const std::string& p) {
  std::ifstream f(p, std::ios::binary);
  if (!f) { fprintf(stderr, "[error] cannot open %s\n", p.c_str()); exit(2); }
  std::ostringstream ss; ss << f.rdbuf();
  return ss.str();
}

static void write_file(const std::string& p, const std::string& data) {
  std::ofstream f(p, std::ios::binary | std::ios::trunc);
  if (!f) { fprintf(stderr, "[error] cannot write %s\n", p.c_str()); exit(2); }
  f << data;
}

static std::string trim(const std::string& s) {
  size_t a = 0, b = s.size();
  while (a < b && isspace((unsigned char)s[a])) ++a;
  while (b > a && isspace((unsigned char)s[b-1])) --b;
  return s.substr(a, b - a);
}

static std::string license_canonical(const json& j) {
  // product|licensee|device_id|issued|expires|plan  (fixed order)
  std::ostringstream os;
  os << j.at("product").get<std::string>() << '|'
     << j.at("licensee").get<std::string>() << '|'
     << j.at("device_id").get<std::string>() << '|'
     << j.at("issued").get<long long>() << '|'
     << j.value("expires", 0LL) << '|'
     << j.at("plan").get<std::string>();
  return os.str();
}

static std::string manifest_canonical(const json& j) {
  std::ostringstream os;
  os << j.at("version").get<long long>() << '|'
     << j.at("url").get<std::string>() << '|'
     << j.at("sha256").get<std::string>();
  return os.str();
}

static void attach_sig(json& j, const std::string& canonical, const uint8_t sec[SEC]) {
  uint8_t sig[SIG];
  if (!sign(sec, canonical, sig)) { fprintf(stderr, "[error] signing failed\n"); exit(3); }
  j["sig"] = b64_encode(sig, SIG);
}

int main(int argc, char** argv) {
  if (argc < 2) {
    fprintf(stderr,
      "usage:\n"
      "  sfs4_sign keygen <pub-out> <sec-out>\n"
      "  sfs4_sign sign-license <license.json> <sec-key> <out.json>\n"
      "  sfs4_sign sign-manifest <manifest.json> <sec-key>\n"
      "  sfs4_sign verify <canonical> <sig-b64> <pub-key>\n");
    return 1;
  }

  const std::string cmd = argv[1];

  if (cmd == "keygen" && argc == 4) {
    uint8_t pub[PUB], sec[SEC];
    if (!keypair(pub, sec)) { fprintf(stderr, "[error] keygen failed\n"); return 3; }
    if (!save_pub_file(argv[2], pub) || !save_sec_file(argv[3], sec)) {
      fprintf(stderr, "[error] key file write failed\n"); return 3;
    }
    printf("[ok] wrote %s (ship this) and %s (keep secret)\n", argv[2], argv[3]);
    return 0;
  }

  if (cmd == "sign-license" && argc == 5) {
    uint8_t sec[SEC];
    std::string err;
    if (!load_sec_file(argv[3], sec, err)) { fprintf(stderr, "[error] %s\n", err.c_str()); return 3; }
    json j;
    try { j = json::parse(read_file(argv[2])); }
    catch (...) { fprintf(stderr, "[error] license json unparseable\n"); return 2; }
    if (j.value("issued", 0LL) == 0) j["issued"] = (long long)time(nullptr);
    attach_sig(j, license_canonical(j), sec);
    write_file(argv[4], j.dump(2) + "\n");
    printf("[ok] signed license -> %s\n", argv[4]);
    return 0;
  }

  if (cmd == "sign-manifest" && argc == 4) {
    uint8_t sec[SEC];
    std::string err;
    if (!load_sec_file(argv[3], sec, err)) { fprintf(stderr, "[error] %s\n", err.c_str()); return 3; }
    json j;
    try { j = json::parse(read_file(argv[2])); }
    catch (...) { fprintf(stderr, "[error] manifest json unparseable\n"); return 2; }
    attach_sig(j, manifest_canonical(j), sec);
    write_file(argv[2], j.dump(2) + "\n");
    printf("[ok] manifest signed in place: %s\n", argv[2]);
    return 0;
  }

  if (cmd == "verify" && argc == 5) {
    uint8_t pub[PUB];
    std::string err;
    if (!load_pub_file(argv[4], pub, err)) { fprintf(stderr, "[error] %s\n", err.c_str()); return 3; }
    std::vector<uint8_t> sig;
    if (!b64_decode(argv[3], sig) || sig.size() != SIG) {
      fprintf(stderr, "[error] signature malformed\n"); return 2;
    }
    const bool ok = verify(pub, argv[2], sig.data());
    printf(ok ? "[ok] signature valid\n" : "[fail] signature REJECTED\n");
    return ok ? 0 : 4;
  }

  fprintf(stderr, "[error] unknown command or wrong arg count\n");
  return 1;
}
