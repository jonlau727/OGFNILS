#pragma once
// Application integrity: Authenticode self-check, distribution hash manifest
// verification, and configuration tamper detection (DPAPI-bound HMAC).
#include "common/config.hpp"
#include <filesystem>
#include <string>
#include <vector>

namespace sfs4::integrity {

enum class SigStatus { Trusted, Unsigned, Bad, Error, Skipped };
const char* to_string(SigStatus s);

// Authenticode-verify the running executable. In dev builds without a cert
// packed in, this returns Unsigned and callers log it, not panic.
SigStatus self_signature_status();

struct FileHash { std::string name; std::string sha256; };

bool sha256_file(const std::filesystem::path& p, std::string& hex_out);
bool sha256_bytes(const std::string& data, std::string& hex_out);

// Reads bundle.sha256.json from the install dir (built by package.ps1) and
// verifies every listed file. Missing manifest = clean dev tree, skipped.
// Returns true when everything listed matches.
bool verify_bundle(const std::filesystem::path& dir, std::string& report);

// ---- configuration tamper protection --------------------------------------
// First run: generates a random 32-byte key, stores it encrypted to THIS
// user+machine with CryptProtectData. Every save/update writes the HMAC of
// config.json bytes to config.hmac. On load, a mismatch means the file was
// edited outside the app → caller resets to defaults and logs a tamper event.
void config_rebinding(const std::filesystem::path& cfg_file, const Config& c);
bool config_verify(const std::filesystem::path& cfg_file, std::string& report);

} // namespace sfs4::integrity
