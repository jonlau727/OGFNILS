#pragma once
// Minimal WinHTTP client shared by licensing, heartbeat, and the updater.
// HTTPS is used whenever the URL scheme is https; dev servers may use plain
// HTTP on localhost. Timeouts are bounded; responses are capped.
#include <string>

namespace sfs4::net {

struct Response {
  long status = 0;
  std::string body;
  std::string error;    // set when the exchange itself failed
  bool ok() const { return status >= 200 && status < 300; }
};

Response request(const std::string& method, const std::string& url,
                 const std::string& body = {},
                 const std::string& content_type = "application/json");

inline Response get(const std::string& url)  { return request("GET", url); }
inline Response post(const std::string& url, const std::string& json) {
  return request("POST", url, json);
}

} // namespace sfs4::net
