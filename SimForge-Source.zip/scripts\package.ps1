# Stages the distributable app folder and generates the integrity manifest.
# Private keys are NEVER copied here; Release builds emit no PDBs to ship.
# Update manifests are signed with the sfs4_sign tool (tools/sign):
#   build\Release\sfs4_sign.exe sign-manifest <manifest.json> <private.key>
param([string]$Version = "0.2.0")
$ErrorActionPreference = "Stop"

$stage = "dist\app"
Remove-Item -Recurse -Force $stage -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $stage | Out-Null

$bins = @("build\Release\SimForgeS4.exe", "build\Release\SimForgeS4Boot.exe")
foreach ($b in $bins) {
  if (-not (Test-Path $b)) { Write-Error "missing $b — run scripts\build_release.bat first"; exit 1 }
  Copy-Item $b $stage
}
Copy-Item docs\config.example.json "$stage\config.json"
if (Test-Path "verify.pub") { Copy-Item verify.pub $stage }

# Bundle hash manifest consumed by the app's integrity check.
$files = Get-ChildItem $stage -File
$manifest = [ordered]@{
  generated = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
  version   = $Version
  files     = @()
}
foreach ($f in $files) {
  $manifest.files += [ordered]@{
    name  = $f.Name
    sha256 = (Get-FileHash $f.FullName -Algorithm SHA256).Hash.ToLower()
  }
}
$manifest | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 "$stage\bundle.sha256.json"

Write-Host "[ok] staged $stage ($($files.Count) files + manifest)"
