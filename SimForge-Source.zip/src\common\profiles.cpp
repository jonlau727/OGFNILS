#include "common/profiles.hpp"
#include "common/paths.hpp"
#include <filesystem>
#include <fstream>
#include <sstream>
#include <algorithm>

namespace sfs4::profiles {

static std::wstring sanitize(std::wstring name) {
  for (wchar_t& ch : name)
    if (ch == L'/' || ch == L'\\' || ch == L':' || ch == L'*' || ch == L'?' ||
        ch == L'"' || ch == L'<' || ch == L'>' || ch == L'|')
      ch = L'_';
  if (name.size() > 64) name.resize(64);
  return name;
}

std::filesystem::path dir() {
  return paths::app_data_dir() / L"profiles";
}

std::vector<std::wstring> list() {
  std::vector<std::wstring> out;
  std::error_code ec;
  std::filesystem::directory_iterator it(dir(), ec), end;
  for (; !ec && it != end; ++it) {
    if (it->path().extension() == L".json")
      out.push_back(it->path().stem().wstring());
  }
  if (!ec) std::sort(out.begin(), out.end());
  return out;
}

bool save(const Config& c, const std::wstring& name, std::string& err) {
  const std::wstring n = sanitize(name);
  if (n.empty()) { err = "profile name is empty"; return false; }
  std::error_code ec;
  std::filesystem::create_directories(dir(), ec);
  std::ofstream f(dir() / (n + L".json"), std::ios::binary | std::ios::trunc);
  if (!f) { err = "cannot write profile file"; return false; }
  f << config_to_raw(c);
  if (!f) { err = "profile write failed"; return false; }
  return true;
}

bool load(const std::wstring& name, Config& c, std::string& err) {
  const std::filesystem::path p = dir() / (sanitize(name) + L".json");
  std::ifstream f(p, std::ios::binary);
  if (!f) { err = "profile not found: " + to_narrow(name); return false; }
  std::stringstream ss;
  ss << f.rdbuf();
  bool ok = false;
  Config parsed = config_from_raw(ss.str(), ok);
  if (!ok) { err = "profile file is corrupt"; return false; }
  c = parsed;
  return true;
}

bool remove(const std::wstring& name) {
  std::error_code ec;
  const std::filesystem::path p = dir() / (sanitize(name) + L".json");
  const bool deleted = std::filesystem::remove(p, ec);
  return !ec && deleted;
}

void apply_sim(Config& dst, const Config& src) {
  dst.advanced_mode = src.advanced_mode;

  dst.esp_boxes    = src.esp_boxes;
  dst.esp_skeleton = src.esp_skeleton;
  dst.esp_health   = src.esp_health;
  dst.esp_distance = src.esp_distance;
  dst.esp_names    = src.esp_names;
  dst.esp_fov_ring = src.esp_fov_ring;
  dst.aura_alpha   = src.aura_alpha;
  dst.box_thick    = src.box_thick;
  dst.fov_px       = src.fov_px;
  dst.line_thick   = src.line_thick;

  dst.aim_enabled = src.aim_enabled;
  dst.aim_fov_deg = src.aim_fov_deg;
  dst.aim_smooth  = src.aim_smooth;
  dst.aim_head    = src.aim_head;
  dst.reaction_ms = src.reaction_ms;

  dst.trig_enabled   = src.trig_enabled;
  dst.trig_spread_deg = src.trig_spread_deg;
  dst.hitmarkers     = src.hitmarkers;

  dst.target_count    = src.target_count;
  dst.target_min_dist = src.target_min_dist;
  dst.target_max_dist = src.target_max_dist;

  dst.mouse_sens = src.mouse_sens;
  dst.target_hz  = src.target_hz;
  dst.vsync      = src.vsync;

  dst.cv_lab         = src.cv_lab;
  dst.cv_lab_overlay = src.cv_lab_overlay;
}

} // namespace sfs4::profiles
