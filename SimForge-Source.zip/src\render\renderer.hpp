#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <d3d11.h>
#include <string>

namespace sfs4::render {

class Renderer {
public:
  bool init(HWND hwnd);
  void shutdown();
  void resize(int w, int h);      // WM_SIZE path
  void new_frame(HWND hwnd);
  void begin_scene(float r, float g, float b);
  void end_scene_and_present(bool vsync);

  // GPU name for the stats HUD (queried once at init).
  std::wstring gpu_name;

  ID3D11Device* device() { return dev_; }
  int backbuffer_w = 0, backbuffer_h = 0;

private:
  void create_render_target();

  // Raw pointers + explicit release in shutdown() — no WRL dependency.
  ID3D11Device* dev_ = nullptr;
  ID3D11DeviceContext* ctx_ = nullptr;
  IDXGISwapChain* swap_ = nullptr;
  ID3D11RenderTargetView* rtv_ = nullptr;
  HWND hwnd_ = nullptr;
};

} // namespace sfs4::render
