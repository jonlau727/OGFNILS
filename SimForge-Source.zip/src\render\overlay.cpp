#include "render/overlay.hpp"
#include "sim/aimsim.hpp"
#include "companion/ogfnil.hpp"
#include "common/profiles.hpp"
#include "common/paths.hpp"
#include <imgui.h>

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <commdlg.h>

#include <cstdio>
#include <cmath>
#include <cwchar>

#pragma comment(lib, "comdlg32.lib")

namespace sfs4::ui {

std::atomic<bool> cv_bench_request{false};
std::atomic<bool> cv_bench_active{false};
std::atomic<bool> cv_bench_done{false};
std::string cv_bench_error;
cvlab::Metrics cv_bench_metrics;

using sim::Bone;

namespace {

ImVec2 v2(float x, float y) { return ImVec2(x, y); }

// Modal exe picker for companion paths. Empty on cancel.
std::wstring browse_for_exe() {
  wchar_t buf[MAX_PATH]{};
  OPENFILENAMEW ofn{};
  ofn.lStructSize = sizeof(ofn);
  ofn.hwndOwner = GetActiveWindow();
  ofn.lpstrFilter = L"Executables\0*.exe\0All files\0*.*\0";
  ofn.lpstrFile = buf;
  ofn.nMaxFile = MAX_PATH;
  ofn.Flags = OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR | OFN_HIDEREADONLY;
  if (!GetOpenFileNameW(&ofn)) return {};
  return buf;
}

void configure_from(Config& cfg) {
  ogfnil::configure({to_wide(cfg.ogfnil_launcher_path), to_wide(cfg.ogfnil_game_path)});
}

bool any_on_screen(const TargetDraw& t) {
  for (int i = 0; i < (int)Bone::Count; ++i) if (t.on_screen[i]) return true;
  return false;
}

void draw_corner_box(ImDrawList* dl, float x0, float y0, float x1, float y1, ImU32 col, float thick) {
  const float w = x1 - x0, h = y1 - y0;
  const float c = std::min(w, h) * 0.22f;
  dl->AddLine(v2(x0, y0), v2(x0 + c, y0), col, thick);
  dl->AddLine(v2(x0, y0), v2(x0, y0 + c), col, thick);
  dl->AddLine(v2(x1, y0), v2(x1 - c, y0), col, thick);
  dl->AddLine(v2(x1, y0), v2(x1, y0 + c), col, thick);
  dl->AddLine(v2(x0, y1), v2(x0 + c, y1), col, thick);
  dl->AddLine(v2(x0, y1), v2(x0, y1 - c), col, thick);
  dl->AddLine(v2(x1, y1), v2(x1 - c, y1), col, thick);
  dl->AddLine(v2(x1, y1), v2(x1, y1 - c), col, thick);
}

// Bounding box from projected feet→head span.
bool target_box(const TargetDraw& t, float& x0, float& y0, float& x1, float& y1) {
  if (!t.on_screen[(int)Bone::Head] && !t.on_screen[(int)Bone::LFoot]) return false;
  const float cx = t.sx[(int)Bone::Chest];
  const float head_y = t.sy[(int)Bone::Head];
  const float foot_y = t.sy[(int)Bone::LFoot];
  const float height = std::fabs(foot_y - head_y);
  const float width = height * 0.42f;
  x0 = cx - width * 0.5f;
  x1 = cx + width * 0.5f;
  y0 = head_y - height * 0.10f;
  y1 = foot_y + height * 0.03f;
  return height > 8.f;
}

ImU32 health_color(int hp) {
  const int g = (hp * 255) / 100;
  const int r = 255 - g;
  return IM_COL32(r, g, 40, 255);
}

const char* kind_name(sim::TargetKind k) {
  switch (k) {
    case sim::TargetKind::Lurker: return "lurker";
    case sim::TargetKind::Runner: return "runner";
    default: return "planted";
  }
}

} // namespace

void draw_esp(const Config& cfg, const FrameData& fd) {
  ImDrawList* dl = ImGui::GetForegroundDrawList();
  const bool advanced = cfg.advanced_mode;
  const float alpha = advanced ? 1.0f : cfg.aura_alpha;
  const float thick = cfg.box_thick;

  for (const TargetDraw& t : fd.targets) {
    if (!t.visible || !any_on_screen(t)) continue;

    float x0, y0, x1, y1;
    if (!target_box(t, x0, y0, x1, y1)) continue;

    if (cfg.esp_boxes) {
      const ImU32 col = IM_COL32(90, 220, 255, (int)(200 * alpha));
      if (advanced) draw_corner_box(dl, x0, y0, x1, y1, col, thick);
      else          dl->AddRect(v2(x0, y0), v2(x1, y1), IM_COL32(90, 220, 255, (int)(70 * alpha)), 0.f, 0, thick);
    }

    if (cfg.esp_skeleton && advanced) {
      const ImU32 scol = IM_COL32(120, 255, 140, (int)(220 * alpha));
      auto line = [&](Bone a, Bone b) {
        const int ia = (int)a, ib = (int)b;
        if (!t.on_screen[ia] || !t.on_screen[ib]) return;
        dl->AddLine(v2(t.sx[ia], t.sy[ia]), v2(t.sx[ib], t.sy[ib]), scol, cfg.line_thick);
      };
      line(Bone::Head, Bone::Neck);
      line(Bone::Neck, Bone::Chest);
      line(Bone::Chest, Bone::Pelvis);
      line(Bone::LShoulder, Bone::RShoulder);
      line(Bone::LShoulder, Bone::LElbow); line(Bone::LElbow, Bone::LHand);
      line(Bone::RShoulder, Bone::RElbow); line(Bone::RElbow, Bone::RHand);
      line(Bone::Pelvis, Bone::LKnee);     line(Bone::LKnee, Bone::LFoot);
      line(Bone::Pelvis, Bone::RKnee);     line(Bone::RKnee, Bone::RFoot);
      // head dot
      if (t.on_screen[(int)Bone::Head])
        dl->AddCircleFilled(v2(t.sx[(int)Bone::Head], t.sy[(int)Bone::Head]),
                            std::max(2.5f, std::fabs(t.sy[(int)Bone::Neck] - t.sy[(int)Bone::Head]) * 0.8f),
                            scol);
    }

    if (cfg.esp_health) {
      const float bw = std::max(3.f, (x1 - x0) * 0.06f);
      const float bx = x0 - bw - 3.f;
      const float bh = y1 - y0;
      // shield (top, blue) then health (bottom)
      const float sh = bh * (t.shield / 150.f);
      const float hh = bh * ((float)t.hp / 100.f) * (100.f / 150.f);
      dl->AddRectFilled(v2(bx, y0), v2(bx + bw, y0 + sh), IM_COL32(60, 140, 255, (int)(200 * alpha)));
      dl->AddRectFilled(v2(bx, y0 + sh), v2(bx + bw, y0 + sh + hh), health_color(t.hp));
      dl->AddRect(v2(bx, y0), v2(bx + bw, y1), IM_COL32(20, 20, 20, 160));
    }

    if (cfg.esp_distance && advanced) {
      char buf[32];
      snprintf(buf, sizeof(buf), "%.1fm", t.dist_m);
      dl->AddText(v2(x0, y1 + 2.f), IM_COL32(230, 230, 230, (int)(200 * alpha)), buf);
    }

    if (cfg.esp_names && advanced) {
      char buf[48];
      snprintf(buf, sizeof(buf), "%s [%d]", kind_name((sim::TargetKind)t.kind), t.hp);
      dl->AddText(v2(x0, y0 - 16.f), IM_COL32(255, 210, 120, (int)(220 * alpha)), buf);
    }
  }
}

void draw_aim_overlay(const Config& cfg, const sim::AimSim& aim, const FrameData& fd) {
  ImDrawList* dl = ImGui::GetForegroundDrawList();
  const float cx = fd.w * 0.5f, cy = fd.h * 0.5f;

  // FOV ring — acquisition cone for the aim sim (and Legit's guide circle).
  if (cfg.esp_fov_ring) {
    const ImU32 col = cfg.advanced_mode
        ? IM_COL32(255, 255, 255, 70)
        : IM_COL32(120, 255, 160, (int)(90 * cfg.aura_alpha));
    dl->AddCircle(v2(cx, cy), cfg.fov_px, col, 64, 1.2f);
  }

  // virtual crosshair (the aim simulator's actual state)
  const ImU32 ch = IM_COL32(255, 90, 90, 230);
  dl->AddLine(v2(aim.aim_screen.x - 7, aim.aim_screen.y), v2(aim.aim_screen.x + 7, aim.aim_screen.y), ch, 1.4f);
  dl->AddLine(v2(aim.aim_screen.x, aim.aim_screen.y - 7), v2(aim.aim_screen.x, aim.aim_screen.y + 7), ch, 1.4f);

  if (aim.locked_index >= 0 && cfg.advanced_mode) {
    const TargetDraw& t = fd.targets[aim.locked_index];
    if (t.visible && t.on_screen[(int)Bone::Head])
      dl->AddCircle(v2(t.sx[(int)Bone::Head], t.sy[(int)Bone::Head]), 10.f, IM_COL32(255, 220, 90, 160), 24, 1.1f);
  }

  // hitmarker
  if (cfg.hitmarkers && aim.hitmarker_active()) {
    const ImU32 col = aim.headshot_last ? IM_COL32(255, 60, 60, 240) : IM_COL32(255, 255, 255, 220);
    const float o = 5.f, e = 12.f;
    const float ax = aim.aim_screen.x, ay = aim.aim_screen.y;
    dl->AddLine(v2(ax - o, ay - o), v2(ax - e, ay - e), col, 2.f);
    dl->AddLine(v2(ax + o, ay - o), v2(ax + e, ay - e), col, 2.f);
    dl->AddLine(v2(ax - o, ay + o), v2(ax - e, ay + e), col, 2.f);
    dl->AddLine(v2(ax + o, ay + o), v2(ax + e, ay + e), col, 2.f);
  }

  // kill feed (top-right)
  float fy = 24.f;
  for (const auto& e : aim.feed()) {
    char buf[64];
    snprintf(buf, sizeof(buf), "%s  (%.1fs)", e.text.c_str(), e.t);
    dl->AddText(v2(fd.w - 260.f, fy),
                e.headshot ? IM_COL32(255, 80, 80, 230) : IM_COL32(240, 240, 240, 200), buf);
    fy += 18.f;
  }
}

void draw_stats(const Config& cfg, const FrameData& fd, const sim::AimSim& aim,
                float fps, float avg_ms, float p99_ms, float cpu_pct, const std::wstring& gpu) {
  ImDrawList* dl = ImGui::GetForegroundDrawList();
  char buf[256];
  snprintf(buf, sizeof(buf),
           "SimForge S4  |  %s Mode  |  %.0f fps  |  avg %.2f ms  p99 %.2f ms  |  CPU %.0f%%  |  targets %d/%d",
           cfg.advanced_mode ? "ADVANCED" : "LEGIT",
           fps, avg_ms, p99_ms, cpu_pct, sim_alive_count(fd), (int)fd.targets.size());
  dl->AddText(v2(12.f, 10.f), IM_COL32(200, 255, 200, 220), buf);

  char buf2[160];
  snprintf(buf2, sizeof(buf2), "aim sim: shots %d  hits %d  acc %.1f%%  hs %.1f%%",
           aim.shots, aim.hits, aim.accuracy(), aim.hs_rate());
  dl->AddText(v2(12.f, 28.f), IM_COL32(200, 220, 255, 200), buf2);

  if (!gpu.empty()) {
    char g[128];
    WideCharToMultiByte(CP_UTF8, 0, gpu.c_str(), -1, g, sizeof(g), nullptr, nullptr);
    char buf3[192];
    snprintf(buf3, sizeof(buf3), "GPU: %s", g);
    dl->AddText(v2(12.f, 46.f), IM_COL32(180, 180, 190, 170), buf3);
  }
}

void draw_cv_inset(const Config& cfg, const FrameData& fd) {
  if (!cfg.cv_lab || !cfg.cv_lab_overlay) return;
  ImDrawList* dl = ImGui::GetForegroundDrawList();

  // Mini-viewport, bottom-right: 320x180 with an 8px margin.
  const float iw = 320.f, ih = 180.f;
  const float x0 = fd.w - iw - 8.f, y0 = fd.h - ih - 8.f;
  const float x1 = x0 + iw, y1 = y0 + ih;
  dl->AddRectFilled(v2(x0, y0), v2(x1, y1), IM_COL32(8, 10, 14, 200));
  dl->AddRect(v2(x0, y0), v2(x1, y1), IM_COL32(90, 220, 255, 120));

  char hdr[128];
  snprintf(hdr, sizeof(hdr), "CV Lab  frames %d  IoU %.2f  FP %d  miss %d  %.2f ms",
           fd.cv_metrics.frames, fd.cv_metrics.mean_iou,
           fd.cv_metrics.false_pos, fd.cv_metrics.missed, fd.cv_metrics.avg_detect_ms);
  dl->AddText(v2(x0 + 6.f, y0 + 4.f), IM_COL32(160, 230, 255, 220), hdr);

  // Detection boxes are in synthetic-frame space; scale into the inset.
  for (const cvlab::Rect& r : fd.cv_boxes) {
    const float sx = x0 + r.x * (iw / 640.f);
    const float sy = y0 + 20.f + r.y * ((ih - 24.f) / 360.f);
    const float sw = r.w * (iw / 640.f), sh = r.h * ((ih - 24.f) / 360.f);
    dl->AddRect(v2(sx, sy), v2(sx + sw, sy + sh), IM_COL32(120, 255, 140, 220), 0.f, 0, 1.2f);
  }
}

int sim_alive_count(const FrameData& fd) {
  int n = 0;
  for (const auto& t : fd.targets) if (t.hp > 0) ++n;
  return n;
}

void draw_settings(Config& cfg, sim::TargetField& field, float session_t) {
  ImGui::SetNextWindowPos(ImVec2(40, 90), ImGuiCond_FirstUseEver);
  ImGui::SetNextWindowSize(ImVec2(430, 520), ImGuiCond_FirstUseEver);
  if (!ImGui::Begin("SimForge S4 — settings", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
    ImGui::End();
    return;
  }

  if (ImGui::BeginTabBar("##tabs")) {
    if (ImGui::BeginTabItem("Mode")) {
      bool legit = !cfg.advanced_mode;
      bool adv = cfg.advanced_mode;
      if (ImGui::RadioButton("Legit Mode", legit))   cfg.advanced_mode = false;
      if (ImGui::RadioButton("Advanced Mode", adv))  cfg.advanced_mode = true;
      ImGui::Separator();
      ImGui::TextWrapped("Legit: minimal ESP, FOV ring, subtle tracking aids.\n"
                         "Advanced: full ESP, skeletons, aim + trigger simulation, stats.");
      ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem("Visuals")) {
      ImGui::Checkbox("Boxes", &cfg.esp_boxes);
      ImGui::Checkbox("Skeletons (advanced)", &cfg.esp_skeleton);
      ImGui::Checkbox("Health/shield bars", &cfg.esp_health);
      ImGui::Checkbox("Distance labels", &cfg.esp_distance);
      ImGui::Checkbox("Target names", &cfg.esp_names);
      ImGui::Checkbox("FOV ring", &cfg.esp_fov_ring);
      if (!cfg.advanced_mode) ImGui::SliderFloat("Legit subtlety", &cfg.aura_alpha, 0.2f, 1.f);
      ImGui::SliderFloat("Box thickness", &cfg.box_thick, 0.5f, 4.f);
      ImGui::SliderFloat("Line thickness", &cfg.line_thick, 0.5f, 4.f);
      ImGui::SliderFloat("FOV ring radius (px)", &cfg.fov_px, 40.f, 500.f);
      ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem("Aim Sim")) {
      ImGui::Checkbox("Aim simulation enabled", &cfg.aim_enabled);
      ImGui::SliderFloat("Acquisition FOV (deg)", &cfg.aim_fov_deg, 2.f, 60.f);
      ImGui::SliderFloat("Smoothing", &cfg.aim_smooth, 0.02f, 0.95f);
      int bone = cfg.aim_head ? 0 : 1;
      ImGui::RadioButton("Head", &bone, 0); ImGui::SameLine();
      ImGui::RadioButton("Chest", &bone, 1);
      cfg.aim_head = bone == 0;
      ImGui::SliderInt("Reaction delay (ms)", &cfg.reaction_ms, 30, 600);
      ImGui::Separator();
      ImGui::Checkbox("Trigger simulation enabled", &cfg.trig_enabled);
      ImGui::SliderFloat("Spread (deg)", &cfg.trig_spread_deg, 0.f, 8.f);
      ImGui::Checkbox("Hitmarkers", &cfg.hitmarkers);
      ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem("World")) {
      ImGui::SliderInt("Target count", &cfg.target_count, 1, 64);
      ImGui::SliderFloat("Min distance (m)", &cfg.target_min_dist, 3.f, 60.f);
      ImGui::SliderFloat("Max distance (m)", &cfg.target_max_dist, 8.f, 300.f);
      if (ImGui::Button("Reseed targets")) field.reset((unsigned)(session_t * 1000.0) + 7);
      ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem("Performance")) {
      ImGui::Checkbox("V-Sync", &cfg.vsync);
      ImGui::SliderInt("Target frame rate (0 = uncapped)", &cfg.target_hz, 0, 360);
      ImGui::TextWrapped("165 Hz target: p99 frame time should sit under ~6.0 ms on the reference build (i7-14700F / RTX 3050).");
      ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem("CV Lab")) {
      ImGui::Checkbox("Run research loop", &cfg.cv_lab);
      ImGui::Checkbox("Show detection inset", &cfg.cv_lab_overlay);
      ImGui::Separator();
      ImGui::TextWrapped("Synthetic-image detection research: procedural frames, "
                         "detector vs ground-truth IoU. No external imagery, "
                         "no capture — everything is generated in-process.");
      if (ImGui::Button("Run 120-frame benchmark now")) {
        cv_bench_request = true;
      }
      if (cv_bench_active)
        ImGui::TextColored(ImVec4(1.f, 0.8f, 0.3f, 1.f), "benchmark running...");
      else if (!cv_bench_error.empty())
        ImGui::TextColored(ImVec4(1.f, 0.4f, 0.4f, 1.f), "%s", cv_bench_error.c_str());
      else if (cv_bench_done)
        ImGui::Text("last benchmark: %d frames, mean IoU %.2f, %.2f ms/frame",
                    cv_bench_metrics.frames, cv_bench_metrics.mean_iou,
                    cv_bench_metrics.avg_detect_ms);
      ImGui::EndTabItem();
    }
    if (ImGui::BeginTabItem("OGFNIL")) {
      const ogfnil::Snapshot snap = ogfnil::snapshot();

      auto state_text = [](ogfnil::ProcState s) {
        switch (s) {
          case ogfnil::ProcState::Running: return "running";
          case ogfnil::ProcState::Stopped: return "not running";
          default: return "unknown";
        }
      };
      auto state_col = [](ogfnil::ProcState s) {
        switch (s) {
          case ogfnil::ProcState::Running: return ImVec4(0.4f, 1.f, 0.5f, 1.f);
          case ogfnil::ProcState::Stopped: return ImVec4(0.85f, 0.85f, 0.85f, 1.f);
          default: return ImVec4(1.f, 0.8f, 0.3f, 1.f);
        }
      };

      ImGui::Text("monitor: %s", snap.monitor_running ? "active (2s poll)" : "stopped");
      if (!snap.last_error.empty())
        ImGui::TextColored(ImVec4(1.f, 0.4f, 0.4f, 1.f), "error: %s", snap.last_error.c_str());

      ImGui::Separator();
      ImGui::TextColored(state_col(snap.launcher.state), "launcher: %s", state_text(snap.launcher.state));
      if (!snap.launcher.pids.empty()) {
        ImGui::SameLine();
        ImGui::Text("pid %lu%s", snap.launcher.pids[0],
                    snap.launcher.pids.size() > 1 ? " (+more)" : "");
      }
      ImGui::TextColored(state_col(snap.game.state), "game: %s", state_text(snap.game.state));
      if (!snap.game.pids.empty()) {
        ImGui::SameLine();
        ImGui::Text("pid %lu%s", snap.game.pids[0],
                    snap.game.pids.size() > 1 ? " (+more)" : "");
      }
      if (!snap.game_version.empty())
        ImGui::Text("game version: %ls", snap.game_version.c_str());
      if (snap.game.restarts)
        ImGui::Text("game restarts observed: %lu", snap.game.restarts);
      if (snap.game.unexpected_exit)
        ImGui::TextColored(ImVec4(1.f, 0.8f, 0.3f, 1.f),
                           "last game exit was unexpected (crash or external kill)");

      ImGui::Separator();
      ImGui::TextDisabled("launcher: %ls",
                          snap.paths.launcher.empty() ? L"(not set)" : snap.paths.launcher.c_str());
      ImGui::TextDisabled("game:     %ls",
                          snap.paths.game.empty() ? L"(not set)" : snap.paths.game.c_str());

      if (ImGui::Button("Launch OGFNIL")) {
        const std::string lerr = ogfnil::launch_launcher(snap.paths.launcher);
        ogfnil::note_event(lerr.empty() ? "launcher started by user"
                                        : "launcher start failed: " + lerr);
        ogfnil::refresh_now();
      }
      ImGui::SameLine();
      if (ImGui::Button("Browse launcher...")) {
        const std::wstring p = browse_for_exe();
        if (!p.empty()) {
          cfg.ogfnil_launcher_path = to_narrow(p);
          configure_from(cfg);
          ogfnil::note_event("launcher path set");
        }
      }
      ImGui::SameLine();
      if (ImGui::Button("Browse game...")) {
        const std::wstring p = browse_for_exe();
        if (!p.empty()) {
          cfg.ogfnil_game_path = to_narrow(p);
          configure_from(cfg);
          ogfnil::note_event("game path set");
        }
      }
      ImGui::SameLine();
      if (ImGui::Button("Refresh")) ogfnil::refresh_now();

      ImGui::Separator();
      ImGui::Text("profile:");
      const auto wnames = profiles::list();
      std::vector<std::string> names;
      names.reserve(wnames.size());
      for (const auto& w : wnames) names.push_back(to_narrow(w));
      int cur = -1;
      for (int i = 0; i < (int)names.size(); ++i)
        if (names[i] == cfg.ogfnil_profile) cur = i;
      if (ImGui::BeginCombo("##ogfnilprofile", cur >= 0 ? names[cur].c_str() : "(none)")) {
        for (int i = 0; i < (int)names.size(); ++i)
          if (ImGui::Selectable(names[i].c_str(), i == cur)) cfg.ogfnil_profile = names[i];
        ImGui::EndCombo();
      }
      ImGui::SameLine();
      ImGui::Checkbox("auto-apply on game start", &cfg.ogfnil_auto_profile);

      static char newname[64] = "";
      ImGui::SetNextItemWidth(200);
      ImGui::InputTextWithHint("##newprofilename", "new profile name", newname, sizeof(newname));
      ImGui::SameLine();
      if (ImGui::Button("Save current as profile")) {
        if (newname[0]) {
          std::string perr;
          if (profiles::save(cfg, to_wide(newname), perr)) {
            cfg.ogfnil_profile = newname;
            ogfnil::note_event("profile saved: " + std::string(newname));
          } else {
            ogfnil::note_event("profile save failed: " + perr);
          }
        }
      }
      if (ImGui::Button("Apply profile now")) {
        if (!cfg.ogfnil_profile.empty()) {
          std::string perr;
          Config pc;
          if (profiles::load(to_wide(cfg.ogfnil_profile), pc, perr)) {
            profiles::apply_sim(cfg, pc);
            ogfnil::note_event("profile applied: " + cfg.ogfnil_profile);
          } else {
            ogfnil::note_event("profile load failed: " + perr);
          }
        }
      }
      ImGui::SameLine();
      if (ImGui::Button("Delete profile")) {
        if (!cfg.ogfnil_profile.empty() && profiles::remove(to_wide(cfg.ogfnil_profile))) {
          ogfnil::note_event("profile deleted: " + cfg.ogfnil_profile);
          cfg.ogfnil_profile.clear();
        }
      }

      ImGui::Separator();
      if (!snap.last_event.empty())
        ImGui::Text("last event: %s", snap.last_event.c_str());
      ImGui::EndTabItem();
    }
    ImGui::EndTabBar();
  }
  ImGui::End();
}

void draw_license_banner(const lic::Fields* lic, bool dev_mode) {
  ImDrawList* dl = ImGui::GetForegroundDrawList();
  char buf[192];
  if (lic) {
    snprintf(buf, sizeof(buf), "Licensed to %s  [%s]", lic->licensee.c_str(), lic->plan.c_str());
    dl->AddText(v2(12.f, 66.f), IM_COL32(120, 255, 140, 210), buf);
  } else if (dev_mode) {
    dl->AddText(v2(12.f, 66.f), IM_COL32(255, 200, 60, 230),
                "DEVELOPMENT BUILD - license bypass active (SFS4_DEV=1)");
  }
}

} // namespace sfs4::ui
