#include "core/license.hpp"
#include "core/ed25519.hpp"
#include "core/integrity.hpp"
#include "common/log.hpp"
#include "common/net.hpp"
#include "common/paths.hpp"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <wincrypt.h>
#include <bcrypt.h>
#include <nlohmann/json.hpp>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <vector>

#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "crypt32.lib")

using json = nlohmann::json;

namespace sfs4::lic {

// Base64 signature of the most recently verified license (file, cache, or
// server). Consumed by the heartbeat so it can re-send the exact token.
std::string g_cached_sig;

std::string canonical(const Fields& f) {
  // Byte-exact match with server/main.cpp and tools/sign. Pipe-joined, fixed
  // order — no JSON escaping pitfalls on any side.
  std::ostringstream os;
  os << f.product << '|' << f.licensee << '|' << f.device_id << '|'
     << f.issued << '|' << f.expires << '|' << f.plan;
  return os.str();
}

std::string device_guid() {
  // MachineGuid is stable per Windows install; we only ever persist a hash.
  char buf[128] = {};
  DWORD sz = sizeof(buf);
  if (RegGetValueA(HKEY_LOCAL_MACHINE, "SOFTWARE\\Microsoft\\Cryptography",
                   "MachineGuid", RRF_RT_REG_SZ, nullptr, buf, &sz) != ERROR_SUCCESS)
    return "";
  const std::string raw = std::string("sfs4-device|") + buf;
  // SHA-256 via the integrity module keeps one hashing implementation.
  std::string hex;
  if (!integrity::sha256_bytes(raw, hex)) return "";
  return hex.substr(0, 32);   // 128-bit device fingerprint
}

std::optional<License> load_from_file(const std::filesystem::path& p, std::string& err) {
  err.clear();
  std::ifstream f(p, std::ios::binary);
  if (!f) { err = "license file not found: " + p.string(); return std::nullopt; }
  std::stringstream ss; ss << f.rdbuf();
  const std::string text = ss.str();

  json j;
  try { j = json::parse(text); }
  catch (...) { err = "license JSON unparseable"; return std::nullopt; }

  License lic;
  lic.raw = text;
  try {
    lic.f.product   = j.at("product").get<std::string>();
    lic.f.licensee  = j.at("licensee").get<std::string>();
    lic.f.device_id = j.at("device_id").get<std::string>();
    lic.f.plan      = j.at("plan").get<std::string>();
    lic.f.issued    = j.at("issued").get<long long>();
    lic.f.expires   = j.value("expires", 0LL);
    lic.sig         = j.at("sig").get<std::string>();
  } catch (...) { err = "license missing required fields"; return std::nullopt; }

  uint8_t pub[ed::PUB];
  std::string kerr;
  if (!ed::load_pub_file(paths::key_file(), pub, kerr)) {
    err = "public key unavailable: " + kerr;
    return std::nullopt;
  }
  std::vector<uint8_t> sig;
  if (!ed::b64_decode(lic.sig, sig) || sig.size() != ed::SIG) {
    err = "license signature malformed";
    return std::nullopt;
  }
  if (!ed::verify(pub, canonical(lic.f), sig.data())) {
    err = "license signature rejected";
    return std::nullopt;
  }
  if (lic.f.product != "simforge-s4") { err = "license product mismatch"; return std::nullopt; }
  return lic;
}

bool secure_load_and_cache(const std::filesystem::path& p, Fields& out, std::string& err) {
  auto lic = load_from_file(p, err);
  if (!lic) return false;

  const std::string dev = device_guid();
  if (lic->f.device_id != "*" && lic->f.device_id != dev) {
    err = "license not valid on this device";
    return false;
  }
  const long long now = (long long)time(nullptr);
  if (lic->f.expires > 0 && now > lic->f.expires) {
    err = "license expired";
    return false;
  }
  out = lic->f;
  g_cached_sig = lic->sig;

  json j;
  j["product"] = out.product; j["licensee"] = out.licensee; j["plan"] = out.plan;
  j["device_id"] = out.device_id; j["issued"] = out.issued; j["expires"] = out.expires;
  j["sig"] = lic->sig;
  const std::string plain = j.dump();
  DATA_BLOB in{}, enc{};
  in.cbData = (DWORD)plain.size();
  in.pbData = (BYTE*)plain.data();
  if (CryptProtectData(&in, L"sfs4-license", nullptr, 0, nullptr, 0, &enc)) {
    std::ofstream f(paths::session_file(), std::ios::binary | std::ios::trunc);
    f.write((const char*)enc.pbData, enc.cbData);
    LocalFree(enc.pbData);
  }
  return true;
}

std::optional<Fields> load_cached_activation() {
  const std::filesystem::path sf = paths::session_file();
  if (!std::filesystem::exists(sf)) return std::nullopt;
  std::ifstream f(sf, std::ios::binary);
  std::vector<uint8_t> blob((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  if (blob.empty()) return std::nullopt;

  DATA_BLOB in{}, out{};
  in.cbData = (DWORD)blob.size();
  in.pbData = blob.data();
  if (!CryptUnprotectData(&in, nullptr, nullptr, 0, nullptr, 0, &out)) {
    std::remove((const char*)sf.c_str());   // moved from another machine/user
    return std::nullopt;
  }
  Fields fld;
  std::string sig;
  bool ok = true;
  try {
    json j = json::parse(std::string((const char*)out.pbData, out.cbData));
    fld.product   = j.at("product").get<std::string>();
    fld.licensee  = j.at("licensee").get<std::string>();
    fld.plan      = j.at("plan").get<std::string>();
    fld.device_id = j.at("device_id").get<std::string>();
    fld.issued    = j.at("issued").get<long long>();
    fld.expires   = j.value("expires", 0LL);
    sig           = j.value("sig", std::string{});
  } catch (...) { ok = false; }
  LocalFree(out.pbData);
  if (!ok) return std::nullopt;

  const long long now = (long long)time(nullptr);
  if (fld.expires > 0 && now > fld.expires) return std::nullopt;

  // Cache is only trusted when its signature still verifies (defends against
  // a tampered DPAPI blob on a compromised profile).
  uint8_t pub[ed::PUB];
  std::string kerr;
  if (!ed::load_pub_file(paths::key_file(), pub, kerr)) return std::nullopt;
  std::vector<uint8_t> sb;
  if (!ed::b64_decode(sig, sb) || sb.size() != ed::SIG) return std::nullopt;
  if (!ed::verify(pub, canonical(fld), sb.data())) return std::nullopt;

  // Expose the sig for heartbeat re-use.
  g_cached_sig = sig;
  return fld;
}

ActivateResult activate_remote(const std::string& api_base, const std::string& license_key,
                               Fields& out, std::string& err) {
  err.clear();
  if (api_base.empty()) { err = "no licensing server configured"; return ActivateResult::NetworkError; }

  json req;
  req["license_key"] = license_key;
  req["device_id"] = device_guid();
  req["product"] = "simforge-s4";

  const net::Response r = net::post(api_base + "/v1/activate", req.dump());
  if (r.status == 0) { err = "network error: " + r.error; return ActivateResult::NetworkError; }
  if (!r.ok()) {
    err = "activation rejected (" + std::to_string(r.status) + ")";
    try { err += ": " + json::parse(r.body).value("error", std::string{}); } catch (...) {}
    return ActivateResult::Rejected;
  }
  try {
    const json j = json::parse(r.body);
    out.product   = j.at("product").get<std::string>();
    out.licensee  = j.at("licensee").get<std::string>();
    out.device_id = j.at("device_id").get<std::string>();
    out.plan      = j.at("plan").get<std::string>();
    out.issued    = j.at("issued").get<long long>();
    out.expires   = j.value("expires", 0LL);
    g_cached_sig  = j.at("sig").get<std::string>();

    // Never trust the network: verify the signature locally before use.
    uint8_t pub[ed::PUB];
    std::string kerr;
    if (!ed::load_pub_file(paths::key_file(), pub, kerr)) {
      err = "public key unavailable: " + kerr;
      return ActivateResult::Rejected;
    }
    std::vector<uint8_t> sb;
    if (!ed::b64_decode(g_cached_sig, sb) || sb.size() != ed::SIG ||
        !ed::verify(pub, canonical(out), sb.data())) {
      err = "server response signature rejected";
      return ActivateResult::Rejected;
    }
    return ActivateResult::Ok;
  } catch (...) {
    err = "activation response malformed";
    return ActivateResult::Rejected;
  }
}

Heartbeat heartbeat(const std::string& api_base, const License& lic, std::string& err) {
  err.clear();
  if (api_base.empty()) { err = "no licensing server configured"; return Heartbeat::Error; }

  json req;
  req["product"] = lic.f.product;
  req["licensee"] = lic.f.licensee;
  req["device_id"] = lic.f.device_id;
  req["issued"] = lic.f.issued;
  req["expires"] = lic.f.expires;
  req["plan"] = lic.f.plan;
  req["sig"] = lic.sig;

  const net::Response r = net::post(api_base + "/v1/heartbeat", req.dump());
  if (r.status == 0) { err = "network error: " + r.error; return Heartbeat::Error; }
  if (r.status == 403 || r.status == 410) return Heartbeat::Revoked;
  if (!r.ok()) { err = "heartbeat failed (" + std::to_string(r.status) + ")"; return Heartbeat::Error; }
  return Heartbeat::Ok;
}

} // namespace sfs4::lic
