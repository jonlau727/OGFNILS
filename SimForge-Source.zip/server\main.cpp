// SimForge licensing server (dev/self-host).
//
// Minimal HTTP/1.1 server on Winsock — no http.sys dependency (httpapi.h is
// absent from some SDK installs, and raw sockets need no URL ACL or elevation).
// Single-threaded accept loop with bounded recv timeouts; traffic volume is
// licensing heartbeats, so a sequential loop is ample.
//
// Endpoints (all JSON):
//   GET  /v1/health
//   POST /v1/activate    {license_key, device_id, product} -> signed license
//   POST /v1/heartbeat   {full license fields + sig}       -> ok | revoked
//   POST /v1/deactivate  {license_key, device_id}          -> frees a seat
//   POST /v1/admin/issue {licensee, plan, seats, days}     -> {license_key}   [admin]
//   POST /v1/admin/revoke {license_key}                    -> 200             [admin]
//
// Admin endpoints require header X-Admin-Token AND a loopback peer address.
// TLS in production terminates at a reverse proxy (IIS/Caddy/nginx) in front
// of this process.
//
// Storage: JSON file, written atomically (temp + rename) on every mutation.
// Signing: Ed25519 (vendored TweetNaCl); keys auto-generate on first run.

#include "core/ed25519.hpp"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <bcrypt.h>
#include <nlohmann/json.hpp>
#include <algorithm>
#include <cctype>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "bcrypt.lib")

using json = nlohmann::json;

namespace {

struct Config {
  unsigned short port = 8085;
  std::string admin_token;
  std::filesystem::path data_dir;
  std::filesystem::path db_path;
  std::filesystem::path sec_path;
  std::filesystem::path pub_path;
};

Config g_cfg;
uint8_t g_pub[sfs4::ed::PUB];
uint8_t g_sec[sfs4::ed::SEC];
std::mutex g_db_mutex;

constexpr size_t kMaxHead = 16 * 1024;
constexpr size_t kMaxBody = 4 * 1024 * 1024;

long long now_epoch() {
  return (long long)std::chrono::duration_cast<std::chrono::seconds>(
      std::chrono::system_clock::now().time_since_epoch()).count();
}

std::string read_file_or_empty(const std::filesystem::path& p) {
  std::ifstream f(p, std::ios::binary);
  if (!f) return {};
  std::ostringstream ss; ss << f.rdbuf();
  return ss.str();
}

bool write_file_atomic(const std::filesystem::path& p, const std::string& data) {
  const std::filesystem::path tmp = p.string() + ".tmp";
  {
    std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
    if (!f) return false;
    f << data;
    if (!f) return false;
  }
  std::error_code ec;
  std::filesystem::rename(tmp, p, ec);
  if (ec) {
    std::filesystem::remove(p, ec);
    std::filesystem::rename(tmp, p, ec);
    if (ec) return false;
  }
  return true;
}

std::string gen_license_key() {
  static const char* alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no I,O,0,1
  char out[20];
  int pos = 0;
  for (int g = 0; g < 4; ++g) {
    if (g) out[pos++] = '-';
    for (int i = 0; i < 4; ++i) {
      uint8_t b;
      BCryptGenRandom(nullptr, &b, 1, BCRYPT_USE_SYSTEM_PREFERRED_RNG);
      out[pos++] = alphabet[b % 32];
    }
  }
  out[pos] = 0;
  return out;
}

// ---- license database -------------------------------------------------------

json g_db;   // {"licenses":[...]} — kept as raw JSON to preserve unknown fields

bool load_db() {
  const std::string text = read_file_or_empty(g_cfg.db_path);
  if (text.empty()) {
    g_db = json{{"licenses", json::array()}};
    return true;
  }
  try {
    g_db = json::parse(text);
    if (!g_db.contains("licenses")) g_db["licenses"] = json::array();
    return true;
  } catch (...) { return false; }
}

bool save_db() {
  return write_file_atomic(g_cfg.db_path, g_db.dump(2) + "\n");
}

json* find_record(const std::string& key) {
  for (auto& l : g_db["licenses"])
    if (l.value("key", "") == key) return &l;
  return nullptr;
}

json* find_by_licensee(const std::string& licensee) {
  for (auto& l : g_db["licenses"])
    if (l.value("licensee", "") == licensee) return &l;
  return nullptr;
}

json issue_license_json(const json& rec, const std::string& device_id) {
  json lic;
  lic["product"] = "simforge-s4";
  lic["licensee"] = rec.value("licensee", "");
  lic["device_id"] = device_id;
  lic["plan"] = rec.value("plan", "standard");
  lic["issued"] = now_epoch();
  lic["expires"] = rec.value("expires", 0LL);

  std::ostringstream canon;
  canon << lic["product"].get<std::string>() << '|'
        << lic["licensee"].get<std::string>() << '|'
        << lic["device_id"].get<std::string>() << '|'
        << lic["issued"].get<long long>() << '|'
        << lic["expires"].get<long long>() << '|'
        << lic["plan"].get<std::string>();

  uint8_t sig[sfs4::ed::SIG];
  if (!sfs4::ed::sign(g_sec, canon.str(), sig)) return {};
  lic["sig"] = sfs4::ed::b64_encode(sig, sfs4::ed::SIG);
  return lic;
}

// ---- endpoints -----------------------------------------------------------------

json handle_activate(const json& req) {
  const std::string key = req.value("license_key", "");
  const std::string device = req.value("device_id", "");
  if (key.empty() || device.empty())
    return json{{"error", "license_key and device_id required"}};

  std::lock_guard<std::mutex> lk(g_db_mutex);
  json* rec = find_record(key);
  if (!rec) return json{{"error", "unknown license key"}};
  if (rec->value("revoked", false)) return json{{"error", "license revoked"}};
  const long long exp = rec->value("expires", 0LL);
  if (exp > 0 && now_epoch() > exp) return json{{"error", "license expired"}};

  if (!(*rec).contains("devices") || !(*rec)["devices"].is_object())
    (*rec)["devices"] = json::object();

  bool registered = false;
  for (auto& d : (*rec)["devices"].items()) {
    if (d.key() == device) { (*rec)["devices"][device] = now_epoch(); registered = true; break; }
  }
  if (!registered) {
    const int used = (int)(*rec)["devices"].size();
    const int seats = std::max(1, rec->value("seats", 1));
    if (used >= seats)
      return json{{"error", "device limit reached (" + std::to_string(seats) + ")"}};
    (*rec)["devices"][device] = now_epoch();
  }
  if (!save_db()) return json{{"error", "storage failure"}};

  const json lic = issue_license_json(*rec, device);
  if (lic.empty()) return json{{"error", "signing failure"}};
  return lic;
}

json handle_heartbeat(const json& req) {
  // Verify the license signature first — the server never trusts its client.
  std::ostringstream canon;
  canon << req.value("product", "") << '|' << req.value("licensee", "") << '|'
        << req.value("device_id", "") << '|' << req.value("issued", 0LL) << '|'
        << req.value("expires", 0LL) << '|' << req.value("plan", "");
  std::vector<uint8_t> sig;
  if (!sfs4::ed::b64_decode(req.value("sig", ""), sig) || sig.size() != sfs4::ed::SIG ||
      !sfs4::ed::verify(g_pub, canon.str(), sig.data()))
    return json{{"status", "invalid"}};

  std::lock_guard<std::mutex> lk(g_db_mutex);
  json* rec = find_by_licensee(req.value("licensee", ""));
  if (!rec) return json{{"status", "unknown"}};
  if (rec->value("revoked", false)) return json{{"status", "revoked"}};
  const long long exp = rec->value("expires", 0LL);
  if (exp > 0 && now_epoch() > exp) return json{{"status", "expired"}};

  const std::string device = req.value("device_id", "");
  if (!rec->contains("devices") || !rec->value("devices", json::object()).contains(device))
    return json{{"status", "unregistered-device"}};
  (*rec)["devices"][device] = now_epoch();
  save_db();
  return json{{"status", "ok"}};
}

json handle_deactivate(const json& req) {
  const std::string key = req.value("license_key", "");
  const std::string device = req.value("device_id", "");
  std::lock_guard<std::mutex> lk(g_db_mutex);
  json* rec = find_record(key);
  if (!rec) return json{{"error", "unknown license key"}};
  if (rec->contains("devices") && (*rec)["devices"].contains(device)) {
    (*rec)["devices"].erase(device);
    save_db();
  }
  return json{{"status", "ok"}};
}

json handle_admin_issue(const json& req) {
  std::lock_guard<std::mutex> lk(g_db_mutex);
  json rec;
  rec["key"] = gen_license_key();
  rec["licensee"] = req.value("licensee", "");
  rec["plan"] = req.value("plan", "standard");
  rec["seats"] = std::max(1, req.value("seats", 1));
  rec["issued"] = now_epoch();
  rec["expires"] = req.value("days", 0) > 0
      ? now_epoch() + (long long)req.value("days", 0) * 86400LL : 0LL;
  rec["revoked"] = false;
  rec["devices"] = json::object();
  g_db["licenses"].push_back(rec);
  if (!save_db()) return json{{"error", "storage failure"}};
  return json{{"license_key", rec["key"]}, {"expires", rec["expires"]}};
}

json handle_admin_revoke(const json& req) {
  std::lock_guard<std::mutex> lk(g_db_mutex);
  json* rec = find_record(req.value("license_key", ""));
  if (!rec) return json{{"error", "unknown license key"}};
  (*rec)["revoked"] = true;
  save_db();
  return json{{"status", "revoked"}};
}

bool admin_authorized(const std::string& admin_token, bool loopback) {
  return loopback && !g_cfg.admin_token.empty() && admin_token == g_cfg.admin_token;
}

// Route a parsed request. Returns status + JSON body.
void route(const std::string& method, const std::string& path,
           const std::string& body, const std::string& admin_token, bool loopback,
           unsigned short& status, std::string& out) {
  try {
    json req = json::object();
    if (!body.empty()) {
      try { req = json::parse(body); }
      catch (...) { status = 400; out = json{{"error", "malformed json"}}.dump(); return; }
    }

  if (method == "GET" && path == "/v1/health") {
    status = 200; out = json{{"status", "ok"}}.dump(); return;
  }
  if (method == "POST" && path == "/v1/activate") {
    const json r = handle_activate(req);
    status = r.contains("error") ? 403 : 200;
    out = r.dump(); return;
  }
  if (method == "POST" && path == "/v1/heartbeat") {
    const json r = handle_heartbeat(req);
    const std::string st = r.value("status", "");
    if (st == "ok") status = 200;
    else if (st == "revoked") status = 403;
    else status = 404;
    out = r.dump(); return;
  }
  if (method == "POST" && path == "/v1/deactivate") {
    const json r = handle_deactivate(req);
    status = r.contains("error") ? 404 : 200;
    out = r.dump(); return;
  }
  if (method == "POST" && path.rfind("/v1/admin/", 0) == 0) {
    if (!admin_authorized(admin_token, loopback)) {
      status = 401; out = json{{"error", "admin authorization required"}}.dump(); return;
    }
    if (path == "/v1/admin/issue") {
      const json r = handle_admin_issue(req);
      status = r.contains("error") ? 400 : 200;
      out = r.dump(); return;
    }
    if (path == "/v1/admin/revoke") {
      const json r = handle_admin_revoke(req);
      status = r.contains("error") ? 404 : 200;
      out = r.dump(); return;
    }
  }
  status = 404;
  out = json{{"error", "not found"}}.dump();
  } catch (const std::exception& e) {
    // Malformed field types and DB hiccups must never kill the process.
    status = 400;
    out = json{{"error", std::string("bad request: ") + e.what()}}.dump();
  } catch (...) {
    status = 500;
    out = json{{"error", "internal error"}}.dump();
  }
}

// ---- connection handling ---------------------------------------------------------

// Reads one HTTP/1.1 request. Returns false on transport error / oversize.
// One request per connection (Connection: close) — WinHTTP handles that fine.
bool read_http_request(SOCKET s, std::string& method, std::string& path,
                       std::string& admin_token, std::string& body) {
  std::string head;
  char buf[4096];
  size_t hdr_end = std::string::npos;
  while (head.size() < kMaxHead) {
    const int n = recv(s, buf, sizeof(buf), 0);
    if (n <= 0) return false;
    head.append(buf, (size_t)n);
    hdr_end = head.find("\r\n\r\n");
    if (hdr_end != std::string::npos) break;
  }
  if (hdr_end == std::string::npos) return false;

  // Request line: METHOD SP PATH SP VERSION
  const size_t sp1 = head.find(' ');
  const size_t sp2 = head.find(' ', sp1 + 1);
  if (sp1 == std::string::npos || sp2 == std::string::npos) return false;
  method = head.substr(0, sp1);
  path = head.substr(sp1 + 1, sp2 - sp1 - 1);
  if (path.empty() || path[0] != '/') return false;

  // Headers (case-insensitive; we only care about Content-Length + X-Admin-Token).
  size_t content_length = 0;
  size_t hpos = head.find("\r\n", 0) + 2;
  while (hpos < hdr_end) {
    const size_t eol = head.find("\r\n", hpos);
    if (eol == std::string::npos || eol > hdr_end) break;
    const std::string line = head.substr(hpos, eol - hpos);
    hpos = eol + 2;
    const size_t colon = line.find(':');
    if (colon == std::string::npos) continue;
    std::string name = line.substr(0, colon);
    std::string value = line.substr(colon + 1);
    for (char& c : name) c = (char)tolower((unsigned char)c);
    size_t v = 0;
    while (v < value.size() && (value[v] == ' ' || value[v] == '\t')) ++v;
    value = value.substr(v);
    if (name == "content-length") content_length = (size_t)_strtoui64(value.c_str(), nullptr, 10);
    else if (name == "x-admin-token") admin_token = value;
  }
  if (content_length > kMaxBody) return false;

  // Body: whatever already arrived past the header block + the rest.
  body = head.substr(hdr_end + 4);
  while (body.size() < content_length) {
    const int n = recv(s, buf, sizeof(buf), 0);
    if (n <= 0) return false;
    body.append(buf, (size_t)n);
  }
  body.resize(content_length);   // exact — pipelined bytes are ignored (Connection: close)
  return true;
}

void send_http_response(SOCKET s, unsigned short status, const std::string& body) {
  const char* reason = (status == 200) ? "OK" :
                       (status == 400) ? "Bad Request" :
                       (status == 401) ? "Unauthorized" :
                       (status == 403) ? "Forbidden" :
                       (status == 404) ? "Not Found" : "Error";
  char head[256];
  snprintf(head, sizeof(head),
           "HTTP/1.1 %u %s\r\n"
           "Content-Type: application/json\r\n"
           "Content-Length: %zu\r\n"
           "Connection: close\r\n"
           "\r\n", status, reason, body.size());
  std::string resp = head;
  resp += body;
  size_t sent = 0;
  while (sent < resp.size()) {
    const int n = send(s, resp.data() + sent, (int)(resp.size() - sent), 0);
    if (n <= 0) return;
    sent += (size_t)n;
  }
}

void handle_connection(SOCKET s, bool loopback) {
  // Bounded I/O: a stalled or hostile client can't wedge the accept loop.
  DWORD timeout_ms = 10000;
  setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout_ms, sizeof(timeout_ms));
  setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, (const char*)&timeout_ms, sizeof(timeout_ms));

  std::string method, path, admin_token, body;
  if (!read_http_request(s, method, path, admin_token, body)) {
    send_http_response(s, 400, json{{"error", "bad request"}}.dump());
    return;
  }
  unsigned short status = 500;
  std::string out;
  route(method, path, body, admin_token, loopback, status, out);
  send_http_response(s, status, out);
}

bool is_loopback_peer(SOCKET s) {
  sockaddr_storage ss{};
  int len = sizeof(ss);
  if (getpeername(s, (sockaddr*)&ss, &len) != 0) return false;
  if (ss.ss_family == AF_INET) {
    const sockaddr_in* in4 = (const sockaddr_in*)&ss;
    return (ntohl(in4->sin_addr.s_addr) >> 24) == 127;
  }
  if (ss.ss_family == AF_INET6) {
    const sockaddr_in6* in6 = (const sockaddr_in6*)&ss;
    const unsigned char* b = in6->sin6_addr.s6_addr;
    for (int i = 0; i < 15; ++i) if (b[i]) return false;
    return b[15] == 1;
  }
  return false;
}

} // namespace

int main(int argc, char** argv) {
  unsigned short port = 8085;
  if (argc > 1) port = (unsigned short)atoi(argv[1]);

  char exe_dir_buf[MAX_PATH]{};
  GetModuleFileNameA(nullptr, exe_dir_buf, MAX_PATH);
  std::filesystem::path base = std::filesystem::path(exe_dir_buf).parent_path();
  // Walk up out of build-tree directories (build/src/Release, Debug, x64...)
  // until we reach the project root that owns server/data.
  for (;;) {
    const std::string name = base.filename().string();
    if (name.empty()) break;
    if (name == "Release" || name == "Debug" || name == "RelWithDebInfo" ||
        name == "MinSizeRel" || name == "src" || name == "build" || name == "x64") {
      base = base.parent_path();
      continue;
    }
    break;
  }

  g_cfg.data_dir = base / "server" / "data";
  std::filesystem::create_directories(g_cfg.data_dir);
  g_cfg.db_path  = g_cfg.data_dir / "licenses.json";
  g_cfg.sec_path = g_cfg.data_dir / "private.key";
  g_cfg.pub_path = g_cfg.data_dir / "verify.pub";

  // Admin token: env or fresh per-run value printed to console.
  {
    char buf[128]{};
    const DWORD n = GetEnvironmentVariableA("SFS4_ADMIN_TOKEN", buf, sizeof(buf));
    if (n > 0 && n < sizeof(buf)) g_cfg.admin_token = buf;
    else {
      uint8_t raw[24];
      BCryptGenRandom(nullptr, raw, sizeof(raw), BCRYPT_USE_SYSTEM_PREFERRED_RNG);
      g_cfg.admin_token = sfs4::ed::b64_encode(raw, sizeof(raw)).substr(0, 32);
    }
  }

  // Signing keys: generate on first run.
  std::string kerr;
  if (!sfs4::ed::load_sec_file(g_cfg.sec_path, g_sec, kerr)) {
    if (!sfs4::ed::keypair(g_pub, g_sec) ||
        !sfs4::ed::save_sec_file(g_cfg.sec_path, g_sec) ||
        !sfs4::ed::save_pub_file(g_cfg.pub_path, g_pub)) {
      fprintf(stderr, "[fatal] could not create signing keys\n");
      return 2;
    }
    printf("[init] generated new signing keys:\n");
    printf("  private: %s  (NEVER distribute)\n", g_cfg.sec_path.string().c_str());
    printf("  public:  %s  (ship as verify.pub with the app)\n", g_cfg.pub_path.string().c_str());
  } else if (!sfs4::ed::load_pub_file(g_cfg.pub_path, g_pub, kerr)) {
    fprintf(stderr, "[fatal] public key missing/corrupt: %s\n", kerr.c_str());
    return 2;
  }

  if (!load_db()) {
    fprintf(stderr, "[fatal] license database corrupt: %s\n", g_cfg.db_path.string().c_str());
    return 2;
  }

  // ---- Winsock setup ----
  WSADATA wsa{};
  if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
    fprintf(stderr, "[fatal] WSAStartup failed\n");
    return 3;
  }

  SOCKET listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if (listener == INVALID_SOCKET) {
    fprintf(stderr, "[fatal] socket() failed %d\n", WSAGetLastError());
    return 3;
  }
  BOOL reuse = TRUE;
  setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(reuse));

  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);   // loopback-only by design
  addr.sin_port = htons(port);
  if (bind(listener, (const sockaddr*)&addr, sizeof(addr)) != 0) {
    fprintf(stderr, "[fatal] bind 127.0.0.1:%u failed %d (port in use?)\n", port, WSAGetLastError());
    return 3;
  }
  if (listen(listener, 16) != 0) {
    fprintf(stderr, "[fatal] listen failed %d\n", WSAGetLastError());
    return 3;
  }

  printf("SimForge licensing server\n");
  printf("  listening on  http://127.0.0.1:%u/\n", port);
  printf("  database      %s\n", g_cfg.db_path.string().c_str());
  printf("  admin token   %s   (header: X-Admin-Token, loopback only)\n", g_cfg.admin_token.c_str());
  printf("  licenses      %zu\n", g_db["licenses"].size());
  printf("Ctrl+C to stop.\n\n");

  for (;;) {
    SOCKET client = accept(listener, nullptr, nullptr);
    if (client == INVALID_SOCKET) continue;
    const bool loop = is_loopback_peer(client);
    handle_connection(client, loop);
    closesocket(client);
  }
}
