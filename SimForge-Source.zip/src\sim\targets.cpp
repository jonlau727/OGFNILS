#include "sim/targets.hpp"
#include <cmath>
#include <algorithm>

namespace sfs4::sim {

using glm::vec3;
static constexpr float kPi = 3.14159265358979f;

void TargetField::config(int count, float min_dist, float max_dist) {
  count_  = std::clamp(count, 1, 64);
  min_d_  = std::max(3.f, min_dist);
  max_d_  = std::max(min_d_ + 5.f, max_dist);
}

void TargetField::reset(unsigned seed) {
  rng_.seed(seed);
  pool_.assign(count_, Target{});
  for (Target& t : pool_) {
    t.kind = (TargetKind)(rng_() % (int)TargetKind::Count);
    respawn(t, {0, 0, 0});
    t.alive = true;
  }
}

void TargetField::respawn(Target& t, const glm::vec3& cam_feet) {
  std::uniform_real_distribution<float> ang(0.f, 2.f * kPi);
  std::uniform_real_distribution<float> dist(min_d_, max_d_);
  std::uniform_int_distribution<int> kind(0, (int)TargetKind::Count - 1);
  const float a = ang(rng_), d = dist(rng_);
  t.pos = vec3(cam_feet.x + std::cos(a) * d, 0.f, cam_feet.z + std::sin(a) * d);
  t.vel = vec3(0, 0, 0);
  t.kind = (TargetKind)kind(rng_);
  t.height = 1.75f + (float)(rng_() % 100) * 0.002f;   // 1.75 .. 1.95 m
  t.hp = 100;
  t.shield = 50.f;
  t.alive = true;
  t.phase = (float)(rng_() % 1000) * 0.01f;
  t.respawn_t = 0.f;
}

void TargetField::tick(float dt, const glm::vec3& cam_feet) {
  for (Target& t : pool_) {
    if (!t.alive) {
      t.respawn_t -= dt;
      if (t.respawn_t <= 0.f) respawn(t, cam_feet);
      continue;
    }
    t.phase += dt;

    if (t.kind == TargetKind::Lurker) {
      // slow sinuous strafing around the anchor point
      t.vel.x = std::sin(t.phase * 0.9f) * 1.7f;
      t.vel.z = std::cos(t.phase * 0.6f) * 0.9f;
    } else if (t.kind == TargetKind::Runner) {
      // horizontal dashes flipping direction about every second
      if (std::fmod(t.phase, 1.15f) < dt) t.vel.x = (t.vel.x <= 0.f ? 1.f : -1.f) * (3.8f + std::fmod(t.phase, 3.3f));
      t.vel.z = 0.f;
    } else {
      t.vel = vec3(0, t.vel.y, 0);
    }

    // hop impulses for movers
    if (t.kind != TargetKind::Planted && t.pos.y <= 0.01f && std::fmod(t.phase, 2.4f) < dt)
      t.vel.y = 6.2f;

    t.vel.y -= 22.f * dt;   // gravity — snappy, arcade-y arc
    t.pos += t.vel * dt;
    if (t.pos.y < 0.f) {
      t.pos.y = 0.f;
      t.vel.y = std::max(0.f, t.vel.y);
    }

    // fold targets back inside the ring if the camera traveled far
    vec3 d = t.pos - cam_feet;
    d.y = 0.f;
    if (glm::length(d) > max_d_ * 1.3f) {
      d = glm::normalize(d) * max_d_;
      t.pos = cam_feet + d;
    }
  }
}

Bones TargetField::bones_of(const Target& t) const {
  const float H = t.height;
  Bones b{};
  auto at = [&](float frac) { return vec3(t.pos.x, t.pos.y + H * frac, t.pos.z); };

  b.p[(int)Bone::Head]   = at(0.905f);
  b.p[(int)Bone::Neck]   = at(0.80f);
  b.p[(int)Bone::Chest]  = at(0.68f);
  b.p[(int)Bone::Pelvis] = at(0.53f);

  // torso lean into the strafe direction
  const float lean = (t.kind == TargetKind::Planted ? 0.f : t.vel.x * 0.010f);
  const float sway = std::sin(t.phase * 2.1f) * 0.030f * H;

  auto shoulder = [&](int side) {
    return vec3(t.pos.x + lean + (side ? 0.115f : -0.115f) * H, t.pos.y + H * 0.78f, t.pos.z);
  };
  b.p[(int)Bone::LShoulder] = shoulder(0);
  b.p[(int)Bone::RShoulder] = shoulder(1);
  b.p[(int)Bone::LElbow] = b.p[(int)Bone::LShoulder] + vec3(-0.020f * H, -0.160f * H,  sway);
  b.p[(int)Bone::RElbow] = b.p[(int)Bone::RShoulder] + vec3( 0.020f * H, -0.160f * H, -sway);
  b.p[(int)Bone::LHand]  = b.p[(int)Bone::LElbow]    + vec3(-0.005f * H, -0.170f * H,  0.05f * H);
  b.p[(int)Bone::RHand]  = b.p[(int)Bone::RElbow]    + vec3( 0.005f * H, -0.170f * H,  0.05f * H);

  auto hip = [&](int side) { return vec3(t.pos.x + (side ? 0.070f : -0.070f) * H, t.pos.y + H * 0.53f, t.pos.z); };
  b.p[(int)Bone::LKnee] = hip(0) + vec3(-0.010f * H, -0.250f * H, 0.f);
  b.p[(int)Bone::RKnee] = hip(1) + vec3( 0.010f * H, -0.250f * H, 0.f);
  b.p[(int)Bone::LFoot] = hip(0) + vec3(-0.020f * H, -0.530f * H, 0.f);
  b.p[(int)Bone::RFoot] = hip(1) + vec3( 0.020f * H, -0.530f * H, 0.f);
  return b;
}

bool TargetField::apply_damage(int index, float dmg) {
  if (index < 0 || (size_t)index >= pool_.size()) return false;
  Target& t = pool_[index];
  if (!t.alive) return false;

  const float absorbed = std::min(t.shield, dmg);
  t.shield -= absorbed;
  t.hp -= (int)std::max(0.f, dmg - absorbed);
  if (t.hp <= 0) {
    t.alive = false;
    t.hp = 0;
    t.respawn_t = 0.9f;
    return true;
  }
  return false;
}

int TargetField::alive_count() const {
  int n = 0;
  for (const Target& t : pool_) if (t.alive) ++n;
  return n;
}

} // namespace sfs4::sim
