#pragma once
#include <string>

namespace sfs4 {

struct Config {
  // mode
  bool  advanced_mode = false;      // false = Legit Mode

  // ESP / HUD
  bool  esp_boxes = true;
  bool  esp_skeleton = true;
  bool  esp_health = true;
  bool  esp_distance = true;
  bool  esp_names = true;
  bool  esp_fov_ring = true;
  float aura_alpha = 0.85f;         // Legit-mode subtlety (0.2 .. 1.0)
  float box_thick = 1.6f;
  float fov_px = 120.f;             // aim circle radius in screen px
  float line_thick = 1.4f;

  // Aim simulator (synthetic-only; no OS input injection, other processes untouched)
  bool  aim_enabled = true;
  float aim_fov_deg = 18.f;         // acquisition cone
  float aim_smooth = 0.25f;         // lerp factor per frame (lower = snappier)
  bool  aim_head = true;            // false = chest
  int   reaction_ms = 150;          // simulated trigger delay

  // Trigger simulator
  bool  trig_enabled = true;
  float trig_spread_deg = 2.f;
  bool  hitmarkers = true;

  // world
  int   target_count = 12;
  float target_min_dist = 8.f;
  float target_max_dist = 45.f;

  // camera
  float mouse_sens = 0.0022f;

  // performance
  int   target_hz = 165;            // 0 = uncapped
  bool  vsync = true;

  // remote services
  std::string api_base;             // e.g. https://licensing.example.com
  std::string update_url;
  bool  auto_check = true;

  // CV research lab (synthetic images only)
  bool  cv_lab = false;             // run the benchmark loop in background
  bool  cv_lab_overlay = false;     // draw last detection boxes in the inset

  // OGFNIL companion (observation-only; see companion/ogfnil.hpp)
  std::string ogfnil_launcher_path; // empty = auto-detect
  std::string ogfnil_game_path;     // empty = auto-detect
  bool  ogfnil_monitor = true;      // start the lifecycle monitor at launch
  std::string ogfnil_profile;       // profile applied when the game starts
  bool  ogfnil_auto_profile = false;
};

// Loads config.json; missing/invalid fields fall back to defaults. Never throws.
Config load_config();
void save_config(const Config& c);

// Raw serialization used by the integrity module to bind an HMAC to the exact
// file bytes it protects.
std::string config_to_raw(const Config& c);
Config config_from_raw(const std::string& raw, bool& ok);

} // namespace sfs4
