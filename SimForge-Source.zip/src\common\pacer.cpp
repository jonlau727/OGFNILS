#include "common/pacer.hpp"
#include <algorithm>
#include <cmath>
#include <thread>

namespace sfs4 {

void Pacer::set_hz(int hz) {
  if (hz < 0) hz = 0;
  hz_ = hz;
  QueryPerformanceFrequency(&freq_);
  QueryPerformanceCounter(&tPrev_);
}

void Pacer::begin_frame() {
  QueryPerformanceCounter(&t0_);
}

void Pacer::refresh_stats() {
  frame_ms = double(t0_.QuadPart - tPrev_.QuadPart) * 1000.0 / double(freq_.QuadPart);
  tPrev_ = t0_;
  window_[wi_] = frame_ms;
  wi_ = (wi_ + 1) % window_.size();
  if (wi_ == 0) wrapped_ = true;

  const std::size_t n = wrapped_ ? window_.size() : wi_;
  if (n == 0) return;
  float sum = 0.f;
  for (std::size_t i = 0; i < n; ++i) sum += window_[i];
  avg_ms = sum / float(n);

  std::array<float, 128> sorted = window_;
  const std::size_t m = wrapped_ ? sorted.size() : wi_;
  std::sort(sorted.begin(), sorted.begin() + (long)m);
  p99_ms = sorted[std::min<std::size_t>(m - 1, (std::size_t)std::floor(0.99 * double(m)))];

  const float inst = (frame_ms > 0.0f) ? 1000.f / frame_ms : 0.f;
  smooth_fps_ = (smooth_fps_ <= 0.f) ? inst : smooth_fps_ * 0.9f + inst * 0.1f;
  fps = smooth_fps_;
}

void Pacer::end_frame() {
  refresh_stats();
  if (hz_ <= 0) { std::this_thread::yield(); return; }

  const double frame_budget = 1000.0 / double(hz_);
  double target_end = double(t0_.QuadPart) / double(freq_.QuadPart) * 1000.0 + frame_budget;
  for (;;) {
    LARGE_INTEGER now; QueryPerformanceCounter(&now);
    const double now_ms = double(now.QuadPart) / double(freq_.QuadPart) * 1000.0;
    const double remain = target_end - now_ms;
    if (remain <= 0.25) break;              // leave the last quarter-ms to the scheduler
    if (remain > 2.0) Sleep(1);
    else std::this_thread::yield();
  }
}

// Coarse system-wide CPU busy% via GetSystemTimes deltas; sampled by the app.
float Pacer::cpu_percent() {
  static bool first = true;
  static ULARGE_INTEGER last_total{}, last_idle{};

  FILETIME idlet, kernt, usert;
  if (!GetSystemTimes(&idlet, &kernt, &usert)) return 0.f;

  auto to_uli = [](const FILETIME& ft) {
    ULARGE_INTEGER u; u.LowPart = ft.dwLowDateTime; u.HighPart = ft.dwHighDateTime; return u;
  };
  const ULARGE_INTEGER idle = to_uli(idlet);
  const ULARGE_INTEGER kern = to_uli(kernt);  // kernel time INCLUDES idle
  const ULARGE_INTEGER user = to_uli(usert);

  if (first) {
    first = false;
    last_total.QuadPart = kern.QuadPart + user.QuadPart;
    last_idle = idle;
    return 0.f;
  }

  const ULONGLONG total_now  = kern.QuadPart + user.QuadPart;
  const ULONGLONG d_total    = total_now - last_total.QuadPart;
  const ULONGLONG d_idle     = idle.QuadPart - last_idle.QuadPart;
  const ULONGLONG d_busy     = (d_total > d_idle) ? d_total - d_idle : 0;

  last_total.QuadPart = total_now;
  last_idle = idle;

  if (d_total == 0) return 0.f;
  return 100.f * float(double(d_busy) / double(d_total));
}

} // namespace sfs4
