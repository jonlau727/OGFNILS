#pragma once
// Thin spdlog wrapper. All modules log through sfs4::log; internal only,
// never shipped to users (no PDBs, no logs in Program Files).
#include <filesystem>

namespace sfs4::log {

void init(const std::filesystem::path& file);
void info(const std::string& msg);
void warn(const std::string& msg);
void error(const std::string& msg);

} // namespace sfs4::log
