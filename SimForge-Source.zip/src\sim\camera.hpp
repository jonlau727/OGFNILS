#pragma once
// FPS camera + world→screen projection. Header-only; pure math.
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <cmath>

namespace sfs4::sim {

struct Camera {
  glm::vec3 pos {0.f, 1.62f, 0.f};  // eye position
  float yaw = 0.f;                  // radians, 0 = +Z forward
  float pitch = 0.f;
  float fov_deg = 90.f;

  glm::vec3 dir() const {
    const float cp = std::cos(pitch);
    return { std::sin(yaw) * cp, std::sin(pitch), std::cos(yaw) * cp };
  }
  glm::vec3 flat_forward() const {
    return { std::sin(yaw), 0.f, std::cos(yaw) };
  }
  glm::vec3 right() const {
    return { std::cos(yaw), 0.f, -std::sin(yaw) };
  }
  glm::mat4 view() const {
    return glm::lookAt(pos, pos + dir(), glm::vec3(0, 1, 0));
  }
  glm::mat4 proj(float aspect) const {
    return glm::perspective(glm::radians(fov_deg), aspect, 0.1f, 500.f);
  }
  glm::mat4 vp(float aspect) const { return proj(aspect) * view(); }
};

// World → screen px (origin top-left). Returns false when behind camera.
inline bool world_to_screen(const glm::vec3& p, const glm::mat4& vp,
                            float w, float h, float& sx, float& sy) {
  const glm::vec4 c = vp * glm::vec4(p, 1.f);
  if (c.w <= 0.001f) return false;
  const float inv = 1.f / c.w;
  const float ndc_x = c.x * inv;
  const float ndc_y = c.y * inv;
  sx = (ndc_x * 0.5f + 0.5f) * w;
  sy = (1.f - (ndc_y * 0.5f + 0.5f)) * h;
  return true;
}

} // namespace sfs4::sim
