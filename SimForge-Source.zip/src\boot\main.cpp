// SimForgeS4Boot — dependency bootstrapper.
//
// Checks the runtime dependencies listed in the product spec, downloads only
// what's missing from official Microsoft endpoints, verifies Authenticode
// signatures before executing anything, and installs with elevation only when
// actually required. Windows security features are never disabled.
//
// Runtime deps for this build:
//   * Microsoft Visual C++ 2022 Redistributable (x64)  — belt & braces; the
//     app links /MT, but GPU driver helpers occasionally want it.
//   * DirectX 11 — feature probe (present on every supported Windows).
//   * WebView2 Runtime — optional; only flagged, never auto-installed.

#include "common/log.hpp"
#include "common/paths.hpp"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winhttp.h>
#include <d3d11.h>
#include <shellapi.h>
#include <wincrypt.h>
#include <softpub.h>
#include <wintrust.h>
#include <cstdio>
#include <string>
#include <fstream>
#include <vector>
#include <filesystem>

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "wintrust.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "advapi32.lib")

namespace {

bool is_admin() {
  BOOL r = FALSE;
  SID_IDENTIFIER_AUTHORITY nt = SECURITY_NT_AUTHORITY;
  PSID group = nullptr;
  if (AllocateAndInitializeSid(&nt, 2, SECURITY_BUILTIN_DOMAIN_RID,
                               DOMAIN_ALIAS_RID_ADMINS, 0, 0, 0, 0, 0, 0, &group)) {
    CheckTokenMembership(nullptr, group, &r);
    FreeSid(group);
  }
  return r == TRUE;
}

bool relaunch_elevated() {
  wchar_t path[MAX_PATH]{};
  GetModuleFileNameW(nullptr, path, MAX_PATH);
  SHELLEXECUTEINFOW sei{sizeof(sei)};
  sei.lpVerb = L"runas";
  sei.lpFile = path;
  sei.nShow = SW_SHOWNORMAL;
  return ShellExecuteExW(&sei) != FALSE;
}

// ---- dependency probes ------------------------------------------------------

bool vc_redist_present() {
  // msvcp140_atomic_wait.dll exists only in VC 2015-2022 redist builds.
  HMODULE m = LoadLibraryExW(L"msvcp140_atomic_wait.dll", nullptr, LOAD_LIBRARY_SEARCH_SYSTEM32);
  if (m) { FreeLibrary(m); return true; }
  return false;
}

bool dx11_present() {
  D3D_FEATURE_LEVEL fl{};
  ID3D11Device* dev = nullptr;
  const HRESULT hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
                                       nullptr, 0, D3D11_SDK_VERSION, &dev, &fl, nullptr);
  if (dev) dev->Release();
  return SUCCEEDED(hr) && fl >= D3D_FEATURE_LEVEL_11_0;
}

bool webview2_present() {
  // Runtime key per WebView2 docs; pv must exist and not be "0.0.0.0".
  const wchar_t* keys[] = {
    L"SOFTWARE\\WOW6432Node\\Microsoft\\EdgeUpdate\\Clients\\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}",
    L"SOFTWARE\\Microsoft\\EdgeUpdate\\Clients\\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}",
  };
  for (const wchar_t* k : keys) {
    wchar_t ver[64]{};
    DWORD sz = sizeof(ver);
    if (RegGetValueW(HKEY_LOCAL_MACHINE, k, L"pv", RRF_RT_REG_SZ, nullptr, ver, &sz) == ERROR_SUCCESS &&
        wcscmp(ver, L"0.0.0.0") != 0)
      return true;
  }
  return false;
}

// ---- download + verify + install --------------------------------------------

struct SigCheck { bool ok; std::string publisher; };

SigCheck verify_microsoft_signature(const std::filesystem::path& file) {
  SigCheck r{false, {}};
  WINTRUST_FILE_INFO fi{};
  fi.cbStruct = sizeof(fi);
  fi.pcwszFilePath = file.c_str();

  WINTRUST_DATA wd{};
  wd.cbStruct = sizeof(wd);
  wd.dwUIChoice = WTD_UI_NONE;
  wd.fdwRevocationChecks = WTD_REVOKE_NONE;
  wd.dwUnionChoice = WTD_CHOICE_FILE;
  wd.dwStateAction = WTD_STATEACTION_VERIFY;
  wd.pFile = &fi;

  GUID action = WINTRUST_ACTION_GENERIC_VERIFY_V2;
  const LONG st = WinVerifyTrust((HWND)INVALID_HANDLE_VALUE, &action, &wd);

  wd.dwStateAction = WTD_STATEACTION_CLOSE;
  WinVerifyTrust((HWND)INVALID_HANDLE_VALUE, &action, &wd);

  r.ok = (st == 0);
  if (r.ok) {
    // Require a Microsoft-issued certificate, not just "any valid signature".
    // CryptQueryObject digs the publisher CN out of the file's embedded cert.
    HCERTSTORE fst = nullptr;
    HCRYPTMSG msg = nullptr;
    if (CryptQueryObject(CERT_QUERY_OBJECT_FILE, file.c_str(),
                         CERT_QUERY_CONTENT_FLAG_PKCS7_SIGNED,
                         CERT_QUERY_FORMAT_FLAG_ALL, 0, nullptr, nullptr,
                         nullptr, &fst, &msg, nullptr)) {
      (void)msg;
      PCCERT_CONTEXT ctx = nullptr;
      while ((ctx = CertEnumCertificatesInStore(fst, ctx)) != nullptr) {
        wchar_t subj[256]{};
        CertGetNameStringW(ctx, CERT_NAME_SIMPLE_DISPLAY_TYPE, 0, nullptr, subj, 256);
        std::wstring s = subj;
        if (s.find(L"Microsoft") != std::wstring::npos) { r.publisher = "Microsoft"; break; }
      }
      if (fst) CertCloseStore(fst, CERT_CLOSE_STORE_FORCE_FLAG);
      if (msg) CryptMsgClose(msg);
    }
    r.ok = (r.publisher == "Microsoft");
  }
  return r;
}

bool download_to(const std::string& url, const std::filesystem::path& dest) {
  // Parse https URL.
  const std::wstring wurl = sfs4::to_wide(url);
  URL_COMPONENTS uc{};
  uc.dwStructSize = sizeof(uc);
  wchar_t host[256]{}, path[2048]{};
  uc.lpszHostName = host; uc.dwHostNameLength = 255;
  uc.lpszUrlPath = path; uc.dwUrlPathLength = 2047;
  if (!WinHttpCrackUrl(wurl.c_str(), (DWORD)wurl.size(), 0, &uc)) return false;

  HINTERNET hs = WinHttpOpen(L"SimForgeS4Boot/0.1",
                             WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                             WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
  if (!hs) return false;
  WinHttpSetTimeouts(hs, 10000, 10000, 15000, 300000); // big installs need patience

  HINTERNET hc = WinHttpConnect(hs, host, uc.nPort, 0);
  HINTERNET hr = hc ? WinHttpOpenRequest(hc, L"GET", path, nullptr,
                                         WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
                                         uc.nScheme == INTERNET_SCHEME_HTTPS ? WINHTTP_FLAG_SECURE : 0)
                    : nullptr;
  bool ok = false;
  if (hr && WinHttpSendRequest(hr, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                               WINHTTP_NO_REQUEST_DATA, 0, 0, 0) &&
      WinHttpReceiveResponse(hr, nullptr)) {
    DWORD status = 0, sz = sizeof(status);
    WinHttpQueryHeaders(hr, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                        WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX);
    if (status == 200) {
      std::ofstream f(dest, std::ios::binary | std::ios::trunc);
      ok = (bool)f;
      DWORD total = 0;
      while (ok) {
        DWORD avail = 0;
        if (!WinHttpQueryDataAvailable(hr, &avail) || avail == 0) break;
        std::vector<char> buf(avail);
        DWORD read = 0;
        if (!WinHttpReadData(hr, buf.data(), avail, &read) || read == 0) break;
        f.write(buf.data(), read);
        total += read;
        printf("\r  downloading... %.1f MB", total / 1048576.0);
      }
      printf("\n");
      ok = (bool)std::filesystem::file_size(dest);
    }
  }
  if (hr) WinHttpCloseHandle(hr);
  if (hc) WinHttpCloseHandle(hc);
  WinHttpCloseHandle(hs);
  return ok;
}

bool run_installer_elevated(const std::filesystem::path& exe, const wchar_t* args) {
  SHELLEXECUTEINFOW sei{sizeof(sei)};
  sei.lpVerb = L"runas";
  sei.lpFile = exe.c_str();
  sei.lpParameters = args;
  sei.fMask = SEE_MASK_NOCLOSEPROCESS;
  sei.nShow = SW_SHOWNORMAL;
  if (!ShellExecuteExW(&sei)) return false;
  if (sei.hProcess) {
    WaitForSingleObject(sei.hProcess, 600000); // 10 min ceiling
    DWORD code = 1;
    GetExitCodeProcess(sei.hProcess, &code);
    CloseHandle(sei.hProcess);
    return code == 0;
  }
  return true;
}

} // namespace

int wmain(int argc, wchar_t** argv) {
  sfs4::log::init(sfs4::paths::app_data_dir() / L"boot.log");
  sfs4::log::info("bootstrapper start");

  printf("SimForge S4 — dependency check\n");
  printf("==============================\n");

  struct Dep { const char* name; bool (*probe)(); const char* url; const wchar_t* args; bool needs_admin; };
  const Dep deps[] = {
    { "Visual C++ 2022 Redistributable (x64)", vc_redist_present,
      "https://aka.ms/vs/17/release/vc_redist.x64.exe", L"/install /quiet /norestart", true },
    { "DirectX 11 runtime", dx11_present, nullptr, nullptr, false },
    { "WebView2 Runtime (optional)", webview2_present, nullptr, nullptr, false },
  };

  bool need_elevation = false;
  for (const Dep& d : deps) {
    const bool present = d.probe();
    printf("  %-42s %s\n", d.name, present ? "present" : (d.url ? "MISSING" : "not present (optional)"));
    if (!present && d.url && d.needs_admin) need_elevation = true;
  }

  bool failed = false;
  for (const Dep& d : deps) {
    if (d.probe() || !d.url) continue;
    if (!need_elevation || is_admin()) {
      // proceed below
    } else {
      printf("  elevation required for %s — relaunching elevated...\n", d.name);
      if (relaunch_elevated()) return 0;  // elevated instance takes over
      printf("  elevation declined; skipping %s\n", d.name);
      continue;
    }

    // Download to %TEMP% with the URL's file name.
    std::filesystem::path file = std::filesystem::temp_directory_path() /
                                 std::filesystem::path(sfs4::to_wide(d.url)).filename();

    printf("  installing %s\n", d.name);
    if (!download_to(d.url, file)) {
      printf("  [error] download failed for %s\n", d.name);
      failed = true;
      continue;
    }
    auto sig = verify_microsoft_signature(file);
    if (!sig.ok) {
      printf("  [error] signature check failed for %s — refusing to run it\n", d.name);
      std::filesystem::remove(file);
      failed = true;
      continue;
    }
    if (!run_installer_elevated(file, d.args)) {
      printf("  [error] installer returned failure for %s\n", d.name);
      failed = true;
      continue;
    }
    printf("  [ok] %s installed\n", d.name);
    std::filesystem::remove(file);
  }

  if (failed) {
    printf("\nOne or more dependencies failed to install. See boot.log for details.\n");
    return 1;
  }
  printf("\nAll dependencies satisfied.\n");

  // Launch the app when invoked without args (installer end-page / manual run).
  if (argc <= 1) {
    const std::filesystem::path app = sfs4::paths::exe_dir() / L"SimForgeS4.exe";
    if (std::filesystem::exists(app)) {
      SHELLEXECUTEINFOW sei{sizeof(sei)};
      sei.lpFile = app.c_str();
      sei.nShow = SW_SHOWNORMAL;
      ShellExecuteExW(&sei);
    }
  }
  sfs4::log::info("bootstrapper done");
  return 0;
}
