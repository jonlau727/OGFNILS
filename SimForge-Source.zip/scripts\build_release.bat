@echo off
REM SimForge S4 — release build (MSVC x64, Release, LTO, no PDB shipped)
setlocal enabledelayedexpansion

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
  echo [error] Visual Studio 2022 required — vswhere not found.
  exit /b 1
)

for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSPATH=%%i"
if not defined VSPATH (
  echo [error] VS2022 C++ workload missing — install "Desktop development with C++".
  exit /b 1
)

call "%VSPATH%\VC\Auxiliary\Build\vcvars64.bat" >nul
if errorlevel 1 (
  echo [error] vcvars64 failed.
  exit /b 1
)

where cmake >nul 2>nul
if errorlevel 1 (
  echo [error] CMake not on PATH — install CMake 3.24+ and add it to PATH.
  exit /b 1
)

cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DCMAKE_SYSTEM_VERSION=10.0
if errorlevel 1 exit /b 1

cmake --build build --config Release --target sfs4 sfs4_boot sfs4_sign sfs4_server sfs4_tests --parallel
if errorlevel 1 exit /b 1

echo.
echo [ok] build complete:
echo   build\Release\SimForgeS4.exe
echo   build\Release\SimForgeS4Boot.exe
echo   build\Release\sfs4_sign.exe        (operator tool — never ship)
echo   build\Release\sfs4_server.exe      (licensing server)
echo   build\Release\sfs4_tests.exe
echo Next: scripts\package.ps1, then iscc installer\simforge.iss
endlocal
