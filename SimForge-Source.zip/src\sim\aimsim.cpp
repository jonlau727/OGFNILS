#include "sim/aimsim.hpp"
#include <cmath>
#include <cstdlib>
#include <algorithm>

namespace sfs4::sim {

namespace {
constexpr float kPi = 3.14159265358979f;

float dist2(const glm::vec2& a, const glm::vec2& b) {
  const float dx = a.x - b.x, dy = a.y - b.y;
  return dx * dx + dy * dy;
}
} // namespace

bool AimSim::hitmarker_active() const {
  return hitmark_t_ > 0.f;
}

void AimSim::update(float dt, const Camera& cam, TargetField& field,
                    float screen_w, float screen_h, const glm::mat4& vp, float session_t) {
  fired = false;
  locked_index = -1;
  if (hitmark_t_ > 0.f) hitmark_t_ -= dt;

  // First potential activation — place the virtual crosshair at screen center.
  if (aim_screen.x <= 0.f && aim_screen.y <= 0.f)
    aim_screen = {screen_w * 0.5f, screen_h * 0.5f};

  // ---- acquisition: nearest bone projection inside the FOV circle ----------
  const float fov_px = std::tanf(glm::radians(p_.fov_deg) * 0.5f) / std::tanf(glm::radians(cam.fov_deg) * 0.5f) * screen_h * 0.5f;
  const int wanted = p_.aim_head ? (int)Bone::Head : (int)Bone::Chest;

  int   best = -1;
  float best_d = fov_px * fov_px;
  glm::vec2 best_px = aim_screen;

  for (int i = 0; i < (int)field.all().size(); ++i) {
    const Target& t = field.all()[i];
    if (!t.alive) continue;
    float sx, sy;
    if (!world_to_screen(field.bones_of(t).p[wanted], vp, screen_w, screen_h, sx, sy))
      continue;
    const float d = dist2(aim_screen, {sx, sy});
    if (d < best_d) { best_d = d; best = i; best_px = {sx, sy}; }
  }

  // ---- aim motion: exponential smoothing toward the acquired bone ----------
  if (p_.enabled && best >= 0) {
    locked_index = best;
    const float k = std::clamp(1.f - p_.smooth, 0.05f, 1.f) * std::min(1.f, dt * 60.f);
    aim_screen += (best_px - aim_screen) * k;
  }

  // spread drift so the crosshair isn't perfectly deterministic
  if (p_.trig_enabled && locked_index >= 0) {
    const float jitter_amt = std::tanf(glm::radians(p_.trig_spread_deg) * 0.5f) * screen_h * 0.5f;
    aim_screen.x += (float)((rand() % 1000) - 500) / 1000.f * jitter_amt * dt;
    aim_screen.y += (float)((rand() % 1000) - 500) / 1000.f * jitter_amt * dt;
  }

  // ---- trigger evaluation: is the virtual crosshair over a target? ---------
  if (!p_.trig_enabled || locked_index < 0 || !p_.enabled) {
    trigger_accum_ms_ = 0.f;
    return;
  }

  const Target& t = field.all()[locked_index];
  if (!t.alive) { trigger_accum_ms_ = 0.f; return; }

  const Bones b = field.bones_of(t);
  float hx, hy, cx, cy, fx, fy;
  const bool h_ok = world_to_screen(b.p[(int)Bone::Head], vp, screen_w, screen_h, hx, hy);
  const bool c_ok = world_to_screen(b.p[(int)Bone::Chest], vp, screen_w, screen_h, cx, cy);
  const bool f_ok = world_to_screen(b.p[(int)Bone::LFoot], vp, screen_w, screen_h, fx, fy);
  if (!h_ok || !c_ok) { trigger_accum_ms_ = 0.f; return; }

  // body silhouette radius in px, derived from projected widths
  const float head_r_px = std::max(6.f, std::fabs(hy - cy) * 0.55f);
  const float body_h_px = std::max(12.f, std::fabs(fy - hy) * 0.85f);
  const float body_r_px = body_h_px * 0.32f;

  const bool on_head = dist2(aim_screen, {hx, hy}) < head_r_px * head_r_px;
  const bool on_body = dist2(aim_screen, {cx, cy}) < body_r_px * body_r_px;

  if (on_head || on_body) {
    trigger_accum_ms_ += dt * 1000.f;
    if (trigger_accum_ms_ >= (float)std::max(20, p_.reaction_ms)) {
      trigger_accum_ms_ = 0.f;
      fired = true;
      ++shots;
      ++hits;
      if (on_head) {
        headshot_last = true;
        ++headshots;
        field.apply_damage(locked_index, 165.f);
      } else {
        headshot_last = false;
        field.apply_damage(locked_index, 44.f);
      }
      hitmark_t_ = 0.22f;
    }
  } else {
    trigger_accum_ms_ = std::max(0.f, trigger_accum_ms_ - dt * 400.f);
  }

  // kill feed
  if (field.all()[locked_index].alive == false) {
    KillFeedEntry e;
    e.headshot = headshot_last;
    e.t = session_t;
    e.text = headshot_last ? "HEADSHOT ELIMINATION" : "ELIMINATION";
    feed_.push_front(e);
    if (feed_.size() > 5) feed_.pop_back();
  }
}

} // namespace sfs4::sim
