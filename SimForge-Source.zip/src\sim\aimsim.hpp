#pragma once
// Aim + trigger simulation. IMPORTANT — scope of this module:
//   * the "crosshair" is a simulation-space state variable rendered by this app
//   * no SendInput / hooks / injected input — nothing leaves the process
//   * fully disableable; stats are informational research outputs
#include "sim/camera.hpp"
#include "sim/targets.hpp"
#include <glm/glm.hpp>
#include <deque>
#include <string>

namespace sfs4::sim {

struct AimParams {
  bool  enabled = true;
  float fov_deg = 18.f;      // acquisition cone
  float smooth = 0.25f;      // 0=snap .. 0.95=idle
  bool  aim_head = true;
  int   reaction_ms = 150;   // simulated human latency
  bool  trig_enabled = true;
  float trig_spread_deg = 2.f;
  bool  hitmarkers = true;
};

struct KillFeedEntry {
  std::string text;
  float t;                   // session time when it happened
  bool headshot;
};

class AimSim {
public:
  void set_params(const AimParams& p) { p_ = p; }
  void update(float dt, const Camera& cam, TargetField& field,
              float screen_w, float screen_h, const glm::mat4& vp, float session_t);

  // state for rendering
  glm::vec2 aim_screen {0, 0};   // virtual crosshair in screen px
  int locked_index = -1;
  bool fired = false;            // true during this frame's trigger event
  bool headshot_last = false;
  bool hitmarker_active() const;

  // stats
  int shots = 0, hits = 0, headshots = 0;
  double accuracy() const { return shots ? 100.0 * hits / shots : 0.0; }
  double hs_rate() const { return hits ? 100.0 * headshots / hits : 0.0; }

  const std::deque<KillFeedEntry>& feed() const { return feed_; }
  void clear_feed() { feed_.clear(); }

private:
  AimParams p_{};
  float trigger_accum_ms_ = 0.f;
  float hitmark_t_ = 0.f;
  glm::vec3 last_target_dir_ {0,0,1};
  std::deque<KillFeedEntry> feed_;
};

} // namespace sfs4::sim
