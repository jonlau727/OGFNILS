#include "core/ed25519.hpp"

extern "C" {
#include "tweetnacl.h"
}

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <bcrypt.h>
#include <cctype>
#include <cstring>
#include <fstream>
#include <sstream>

#pragma comment(lib, "bcrypt.lib")

// TweetNaCl requires the embedder to provide randombytes (used only by
// keypair). BCryptGenRandom is the CNG-approved source.
extern "C" void randombytes(unsigned char* p, unsigned long long n) {
  BCryptGenRandom(nullptr, p, (ULONG)n, BCRYPT_USE_SYSTEM_PREFERRED_RNG);
}

namespace sfs4::ed {

bool keypair(uint8_t* pub_out, uint8_t* sec_out) {
  return crypto_sign_keypair(pub_out, sec_out) == 0;
}

bool sign(const uint8_t sec[SEC], const std::string& msg, uint8_t sig_out[SIG]) {
  std::vector<uint8_t> sm(64 + msg.size());
  unsigned long long smlen = 0;
  if (crypto_sign(sm.data(), &smlen,
                  (const unsigned char*)msg.data(), msg.size(), sec) != 0)
    return false;
  std::memcpy(sig_out, sm.data(), SIG);
  return true;
}

bool verify(const uint8_t pub[PUB], const std::string& msg, const uint8_t sig[SIG]) {
  if (msg.size() > (1u << 22)) return false;   // sanity ceiling: 4 MiB
  std::vector<uint8_t> sm(SIG + msg.size());
  std::memcpy(sm.data(), sig, SIG);
  std::memcpy(sm.data() + SIG, msg.data(), msg.size());
  std::vector<uint8_t> m(sm.size());
  unsigned long long mlen = 0;
  return crypto_sign_open(m.data(), &mlen, sm.data(), sm.size(), pub) == 0 &&
         mlen == msg.size();
}

// ---- base64 ----------------------------------------------------------------

static const char* kAlphabet =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

std::string b64_encode(const uint8_t* data, size_t len) {
  std::string out;
  out.reserve(((len + 2) / 3) * 4);
  size_t i = 0;
  for (; i + 3 <= len; i += 3) {
    const uint32_t v = (uint32_t(data[i]) << 16) | (uint32_t(data[i+1]) << 8) | data[i+2];
    out += kAlphabet[(v >> 18) & 63];
    out += kAlphabet[(v >> 12) & 63];
    out += kAlphabet[(v >> 6) & 63];
    out += kAlphabet[v & 63];
  }
  if (len - i == 1) {
    const uint32_t v = uint32_t(data[i]) << 16;
    out += kAlphabet[(v >> 18) & 63];
    out += kAlphabet[(v >> 12) & 63];
    out += "==";
  } else if (len - i == 2) {
    const uint32_t v = (uint32_t(data[i]) << 16) | (uint32_t(data[i+1]) << 8);
    out += kAlphabet[(v >> 18) & 63];
    out += kAlphabet[(v >> 12) & 63];
    out += kAlphabet[(v >> 6) & 63];
    out += "=";
  }
  return out;
}

bool b64_decode(const std::string& in, std::vector<uint8_t>& out) {
  auto val = [](char c) -> int {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
  };
  out.clear();
  out.reserve(in.size() / 4 * 3);
  uint32_t acc = 0;
  int bits = 0;
  for (char c : in) {
    if (isspace((unsigned char)c) || c == '=') continue;
    const int v = val(c);
    if (v < 0) return false;
    acc = (acc << 6) | (uint32_t)v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      out.push_back(uint8_t((acc >> bits) & 0xFF));
    }
  }
  return true;
}

// ---- key files ---------------------------------------------------------------

static std::string read_trim(const std::filesystem::path& p) {
  std::ifstream f(p, std::ios::binary);
  if (!f) return {};
  std::ostringstream ss;
  ss << f.rdbuf();
  std::string s = ss.str();
  size_t a = 0, b = s.size();
  while (a < b && isspace((unsigned char)s[a])) ++a;
  while (b > a && isspace((unsigned char)s[b-1])) --b;
  return s.substr(a, b - a);
}

bool load_pub_file(const std::filesystem::path& p, uint8_t pub_out[PUB], std::string& err) {
  err.clear();
  std::vector<uint8_t> raw;
  if (!b64_decode(read_trim(p), raw) || raw.size() != PUB) {
    err = "verify.pub missing or not 32-byte base64";
    return false;
  }
  std::memcpy(pub_out, raw.data(), PUB);
  return true;
}

bool load_sec_file(const std::filesystem::path& p, uint8_t sec_out[SEC], std::string& err) {
  err.clear();
  std::vector<uint8_t> raw;
  if (!b64_decode(read_trim(p), raw) || raw.size() != SEC) {
    err = "secret key file missing or not 64-byte base64";
    return false;
  }
  std::memcpy(sec_out, raw.data(), SEC);
  return true;
}

bool save_pub_file(const std::filesystem::path& p, const uint8_t pub[PUB]) {
  std::ofstream f(p, std::ios::binary | std::ios::trunc);
  if (!f) return false;
  f << b64_encode(pub, PUB) << "\n";
  return (bool)f;
}

bool save_sec_file(const std::filesystem::path& p, const uint8_t sec[SEC]) {
  std::ofstream f(p, std::ios::binary | std::ios::trunc);
  if (!f) return false;
  f << b64_encode(sec, SEC) << "\n";
  return (bool)f;
}

} // namespace sfs4::ed
