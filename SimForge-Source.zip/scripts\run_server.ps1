# Runs the SimForge licensing server locally (plain Winsock — no URL ACL or
# elevation needed; binds loopback only).
# Admin endpoints: loopback only + X-Admin-Token header (printed at startup,
# or set SFS4_ADMIN_TOKEN before launching).
param([int]$Port = 8085)
$ErrorActionPreference = "Stop"

$exe = "build\Release\sfs4_server.exe"
if (-not (Test-Path $exe)) { Write-Error "missing $exe — run scripts\build_release.bat first"; exit 1 }

Write-Host "starting sfs4_server on 127.0.0.1:$Port ..."
& $exe $Port
