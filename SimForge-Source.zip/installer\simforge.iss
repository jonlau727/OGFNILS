; Inno Setup script — SimForge S4
; Build: iscc installer\simforge.iss  (or via scripts\package.ps1)
; Signing: uncomment SignTool below once a code-signing cert is in the
; machine/user store; signtool sign /fd sha256 /td sha256 <file> documents
; the thumbprint workflow.

#define MyAppName "SimForge S4"
#define MyAppVersion "0.2.0"
#define MyAppPublisher "SimForge Labs"
#define MyAppExeName "SimForgeS4.exe"
#define MyAppBootName "SimForgeS4Boot.exe"

[Setup]
AppId={{7E4F1B2C-93A8-4D6E-B1F0-2A5C7D9E0F11}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=..\dist\installer
OutputBaseFilename=SimForgeS4-Setup-{#MyAppVersion}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
LicenseFile=LICENSE-EULA.txt
UninstallDisplayIcon={app}\{#MyAppExeName}
; SignTool=signtool /fd sha256 /td sha256 /tr http://timestamp.digicert.com /sm $f

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional icons:"

[Files]
Source: "..\dist\app\SimForgeS4.exe";      DestDir: "{app}"; Flags: ignoreversion
Source: "..\dist\app\SimForgeS4Boot.exe";  DestDir: "{app}"; Flags: ignoreversion
Source: "..\dist\app\verify.pub";          DestDir: "{app}"; Flags: ignoreversion
Source: "..\dist\app\config.json";         DestDir: "{app}"; Flags: ignoreversion skipifsourcedoesntexist
Source: "LICENSE-EULA.txt";                DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}";          Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}";    Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppBootName}"; Flags: runhidden waituntilterminated; \
  StatusMsg: "Checking and installing runtime dependencies..."
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; \
  Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: filesandordirs; Name: "{app}\logs"
