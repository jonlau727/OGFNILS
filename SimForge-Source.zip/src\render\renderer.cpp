#include "render/renderer.hpp"
#include <imgui.h>
#include <backends/imgui_impl_dx11.h>
#include <backends/imgui_impl_win32.h>
#include <dxgi1_2.h>
#include <vector>
#include <memory>

namespace sfs4::render {

bool Renderer::init(HWND hwnd) {
  hwnd_ = hwnd;

  DXGI_SWAP_CHAIN_DESC scd{};
  scd.BufferCount = 2;
  scd.BufferDesc.Width = 0;
  scd.BufferDesc.Height = 0;
  scd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
  scd.BufferDesc.RefreshRate.Numerator = 0;
  scd.BufferDesc.RefreshRate.Denominator = 1;
  scd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
  scd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
  scd.OutputWindow = hwnd;
  scd.SampleDesc.Count = 1;
  scd.Windowed = TRUE;
  scd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

  const D3D_FEATURE_LEVEL want[1] = { D3D_FEATURE_LEVEL_11_0 };
  UINT flags = 0;
  D3D_FEATURE_LEVEL got{};
  HRESULT hr = D3D11CreateDeviceAndSwapChain(
      nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags,
      want, 1, D3D11_SDK_VERSION, &scd,
      &swap_, &dev_, &got, &ctx_);
  if (FAILED(hr)) {
    // Fallback: WARP software raster keeps the sim usable in VMs / no-GPU hosts.
    hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_WARP, nullptr, flags,
        want, 1, D3D11_SDK_VERSION, &scd,
        &swap_, &dev_, &got, &ctx_);
    if (FAILED(hr)) return false;
  }

  create_render_target();

  // GPU description for the stats panel.
  {
    IDXGIDevice* dxgiDev = nullptr;
    if (SUCCEEDED(dev_->QueryInterface(__uuidof(IDXGIDevice), (void**)&dxgiDev))) {
      IDXGIAdapter* adapter = nullptr;
      if (SUCCEEDED(dxgiDev->GetAdapter(&adapter))) {
        DXGI_ADAPTER_DESC desc{};
        if (SUCCEEDED(adapter->GetDesc(&desc)))
          gpu_name = desc.Description;
        adapter->Release();
      }
      dxgiDev->Release();
    }
  }

  ImGui::CreateContext();
  ImGui_ImplWin32_Init(hwnd);
  ImGui_ImplDX11_Init(dev_, ctx_);
  return true;
}

void Renderer::create_render_target() {
  ID3D11Texture2D* back = nullptr;
  swap_->GetBuffer(0, __uuidof(ID3D11Texture2D), (void**)&back);
  if (back) {
    D3D11_TEXTURE2D_DESC td{};
    back->GetDesc(&td);
    backbuffer_w = td.Width;
    backbuffer_h = td.Height;
    dev_->CreateRenderTargetView(back, nullptr, &rtv_);
    back->Release();
  }
}

void Renderer::resize(int w, int h) {
  if (!swap_) return;
  if (rtv_) { rtv_->Release(); rtv_ = nullptr; }
  swap_->ResizeBuffers(0, (UINT)w, (UINT)h, DXGI_FORMAT_UNKNOWN, 0);
  create_render_target();
}

void Renderer::new_frame(HWND hwnd) {
  ImGui_ImplDX11_NewFrame();
  ImGui_ImplWin32_NewFrame();
  ImGui::NewFrame();
}

void Renderer::begin_scene(float r, float g, float b) {
  const float clear[4] = { r, g, b, 1.f };
  ctx_->OMSetRenderTargets(1, &rtv_, nullptr);
  ctx_->ClearRenderTargetView(rtv_, clear);
}

void Renderer::end_scene_and_present(bool vsync) {
  ImGui::Render();
  ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
  swap_->Present(vsync ? 1 : 0, 0);
}

void Renderer::shutdown() {
  ImGui_ImplDX11_Shutdown();
  ImGui_ImplWin32_Shutdown();
  ImGui::DestroyContext();
  if (rtv_) { rtv_->Release(); rtv_ = nullptr; }
  if (swap_) { swap_->Release(); swap_ = nullptr; }
  if (ctx_) { ctx_->Release(); ctx_ = nullptr; }
  if (dev_) { dev_->Release(); dev_ = nullptr; }
}

} // namespace sfs4::render
