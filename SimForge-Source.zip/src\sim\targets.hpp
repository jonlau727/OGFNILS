#pragma once
// Synthetic target population. Self-contained; nothing here touches any other
// process or the real game — it's a capped, deterministic training sandbox.
#include <glm/glm.hpp>
#include <vector>
#include <cstdint>
#include <random>

namespace sfs4::sim {

enum class TargetKind : int { Lurker = 0, Runner, Planted, Count = 3 };

// 14 keypoints, fixed order — skeleton draw + aim points.
enum class Bone : int {
  Head = 0, Neck, Chest, Pelvis,
  LShoulder, RShoulder, LElbow, RElbow, LHand, RHand,
  LKnee, RKnee, LFoot, RFoot,
  Count = 14
};

struct Target {
  glm::vec3 pos {0, 0, 0};   // feet position (ground = y 0)
  glm::vec3 vel {0, 0, 0};
  TargetKind kind = TargetKind::Lurker;
  float height = 1.85f;      // meters, feet→head-top
  int hp = 100;
  float shield = 50.f;
  bool alive = true;
  float phase = 0.f;         // strafe/hop clock
  float respawn_t = 0.f;
};

// World-space skeleton for a target.
struct Bones {
  glm::vec3 p[(int)Bone::Count];
};

class TargetField {
public:
  void config(int count, float min_dist, float max_dist);
  void reset(unsigned seed);
  void tick(float dt, const glm::vec3& cam_feet);
  const std::vector<Target>& all() const { return pool_; }
  Bones bones_of(const Target& t) const;

  // Applies damage; returns true on kill (target respawns after a beat).
  bool apply_damage(int index, float dmg);

  int alive_count() const;

private:
  void respawn(Target& t, const glm::vec3& cam_feet);
  std::vector<Target> pool_;
  std::mt19937 rng_{1337};
  int count_ = 12;
  float min_d_ = 8.f, max_d_ = 45.f;
};

} // namespace sfs4::sim
