#include "sim/cvlab.hpp"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <chrono>
#include <queue>

namespace sfs4::cvlab {

namespace {

// xorshift32 — deterministic, tiny, enough for procedural imagery.
unsigned next_rand(unsigned& s) {
  s ^= s << 13; s ^= s >> 17; s ^= s << 5;
  return s;
}

float iou(const Rect& a, const Rect& b) {
  const float x0 = std::max(a.x, b.x), y0 = std::max(a.y, b.y);
  const float x1 = std::min(a.x + a.w, b.x + b.w);
  const float y1 = std::min(a.y + a.h, b.y + b.h);
  const float iw = std::max(0.f, x1 - x0), ih = std::max(0.f, y1 - y0);
  const float inter = iw * ih;
  const float uni = a.w * a.h + b.w * b.h - inter;
  return uni > 0.f ? inter / uni : 0.f;
}

} // namespace

void generate_frame(unsigned seed, int w, int h, Frame& out) {
  out.w = w; out.h = h; out.seed = seed;
  out.rgb.assign((size_t)w * h * 3, 0);
  out.ground_truth.clear();

  unsigned s = seed ^ 0x9E3779B9u;

  // Background: vertical gradient 18..42 + per-pixel noise.
  for (int y = 0; y < h; ++y) {
    const uint8_t base = (uint8_t)(18 + (24 * y) / std::max(1, h));
    uint8_t* row = out.rgb.data() + (size_t)y * w * 3;
    for (int x = 0; x < w; ++x) {
      const uint8_t n = (uint8_t)(next_rand(s) % 14);   // sensor noise
      const uint8_t v = (uint8_t)(base + n);
      row[x * 3 + 0] = v;
      row[x * 3 + 1] = v;
      row[x * 3 + 2] = (uint8_t)(v + 4);
    }
  }

  // Targets: 3-6 bright rectangles, sizes 14..46 px, never touching edges.
  const int count = 3 + (int)(next_rand(s) % 4);
  for (int i = 0; i < count; ++i) {
    const int tw = 14 + (int)(next_rand(s) % 33);
    const int th = 22 + (int)(next_rand(s) % 25);
    const int tx = 2 + (int)(next_rand(s) % std::max(1, w - tw - 4));
    const int ty = 2 + (int)(next_rand(s) % std::max(1, h - th - 4));
    const uint8_t bright = (uint8_t)(150 + next_rand(s) % 80);

    for (int y = ty; y < ty + th; ++y) {
      uint8_t* row = out.rgb.data() + (size_t)y * w * 3;
      for (int x = tx; x < tx + tw; ++x) {
        row[x * 3 + 0] = bright;
        row[x * 3 + 1] = (uint8_t)(bright - 10);
        row[x * 3 + 2] = (uint8_t)(bright - 20);
      }
    }
    out.ground_truth.push_back({(float)tx, (float)ty, (float)tw, (float)th});
  }
}

bool detect_pure(const Frame& f, std::vector<Rect>& out, double& ms_out) {
  out.clear();
  const auto t0 = std::chrono::steady_clock::now();
  if (f.w <= 0 || f.h <= 0 || f.rgb.size() != (size_t)f.w * f.h * 3) return false;

  constexpr uint8_t kThresh = 100;
  const int w = f.w, h = f.h;
  std::vector<uint8_t> mask((size_t)w * h, 0);
  for (int i = 0; i < w * h; ++i) {
    const uint8_t* px = f.rgb.data() + (size_t)i * 3;
    const unsigned lum = (px[0] * 299u + px[1] * 587u + px[2] * 114u) / 1000u;
    mask[i] = lum >= kThresh;
  }

  // Connected components (4-neighbour, BFS) -> bounding boxes.
  std::vector<int8_t> label((size_t)w * h, 0);
  std::queue<int> q;
  for (int start = 0; start < w * h; ++start) {
    if (!mask[start] || label[start]) continue;
    int minx = w, maxx = 0, miny = h, maxy = 0, area = 0;
    label[start] = 1;
    q.push(start);
    while (!q.empty()) {
      const int p = q.front(); q.pop();
      const int px_ = p % w, py = p / w;
      ++area;
      minx = std::min(minx, px_); maxx = std::max(maxx, px_);
      miny = std::min(miny, py);  maxy = std::max(maxy, py);
      const int nb[4] = {p - 1, p + 1, p - w, p + w};
      for (int k = 0; k < 4; ++k) {
        const int n = nb[k];
        if (n < 0 || n >= w * h) continue;
        if (k == 0 && px_ == 0) continue;
        if (k == 1 && px_ == w - 1) continue;
        if (mask[n] && !label[n]) { label[n] = 1; q.push(n); }
      }
    }
    if (area >= 120)   // noise floor: real targets are 300+ px
      out.push_back({(float)minx, (float)miny,
                     (float)(maxx - minx + 1), (float)(maxy - miny + 1)});
  }

  ms_out = std::chrono::duration<double, std::milli>(
      std::chrono::steady_clock::now() - t0).count();
  return true;
}

#if SFS4_WITH_OPENCV
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>

bool detect_cv(const Frame& f, std::vector<Rect>& out, double& ms_out) {
  out.clear();
  if (f.w <= 0 || f.h <= 0 || f.rgb.size() != (size_t)f.w * f.h * 3) return false;

  const auto t0 = std::chrono::steady_clock::now();
  cv::Mat img(f.h, f.w, CV_8UC3, const_cast<uint8_t*>(f.rgb.data()));
  cv::Mat gray, bin;
  cv::cvtColor(img, gray, cv::COLOR_RGB2GRAY);
  cv::threshold(gray, bin, 100, 255, cv::THRESH_BINARY);

  std::vector<std::vector<cv::Point>> contours;
  cv::findContours(bin, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
  for (const auto& c : contours) {
    const double area = cv::contourArea(c);
    if (area < 120) continue;
    const cv::Rect r = cv::boundingRect(c);
    out.push_back({(float)r.x, (float)r.y, (float)r.width, (float)r.height});
  }
  ms_out = std::chrono::duration<double, std::milli>(
      std::chrono::steady_clock::now() - t0).count();
  return true;
}
#endif // SFS4_WITH_OPENCV

Metrics score(const Frame& f, const std::vector<Rect>& dets, float iou_thresh) {
  Metrics m;
  m.frames = 1;
  std::vector<bool> used(dets.size(), false);
  for (const Rect& gt : f.ground_truth) {
    int best = -1;
    float best_iou = iou_thresh;
    for (size_t i = 0; i < dets.size(); ++i) {
      if (used[i]) continue;
      const float v = iou(gt, dets[i]);
      if (v >= best_iou) { best_iou = v; best = (int)i; }
    }
    if (best >= 0) { used[best] = true; ++m.true_pos; m.mean_iou += best_iou; }
    else ++m.missed;
  }
  m.false_pos = (int)dets.size() - m.true_pos;
  if (m.true_pos > 0) m.mean_iou /= (float)m.true_pos;
  return m;
}

std::string run_benchmark(int frames, unsigned seed0, int w, int h, Metrics& m) {
  m = Metrics{};
  if (frames <= 0) return "frame count must be positive";
  w = std::clamp(w, 64, 1920);
  h = std::clamp(h, 64, 1080);

  double total_ms = 0.0;
  float total_iou = 0.f;
  int matched = 0;

  Frame f;
  std::vector<Rect> dets;
  for (int i = 0; i < frames; ++i) {
    generate_frame(seed0 + (unsigned)i, w, h, f);
    double ms = 0.0;
#if SFS4_WITH_OPENCV
    if (!detect_cv(f, dets, ms)) return "OpenCV detection failed on a generated frame";
#else
    if (!detect_pure(f, dets, ms)) return "detection failed on a generated frame";
#endif
    const Metrics s = score(f, dets);
    m.frames++;
    m.true_pos += s.true_pos;
    m.false_pos += s.false_pos;
    m.missed += s.missed;
    total_ms += ms;
    if (s.true_pos > 0) { total_iou += s.mean_iou * (float)s.true_pos; matched += s.true_pos; }
  }
  m.avg_detect_ms = total_ms / (double)frames;
  m.mean_iou = matched > 0 ? total_iou / (float)matched : 0.f;
  return {};
}

} // namespace sfs4::cvlab
