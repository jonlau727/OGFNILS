// SimForge S4 — synthetic season lab (Phase 2).
//
// Scope contract (project rule): this executable renders and simulates its own
// world. It never opens, reads, injects into, or sends input to any other
// process. ESP/aim/trigger are visualizations of sim state only.
//
// Startup pipeline: log → config (+tamper check) → integrity self-check →
// license gate (+ heartbeat thread) → optional update check → window/renderer
// → sim loop. On exit: staged update apply → config rebind.

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>

#include <imgui.h>
#include <backends/imgui_impl_dx11.h>
#include <backends/imgui_impl_win32.h>
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

#include "common/log.hpp"
#include "common/paths.hpp"
#include "common/config.hpp"
#include "common/pacer.hpp"
#include "core/integrity.hpp"
#include "core/license.hpp"
#include "core/updater.hpp"
#include "sim/targets.hpp"
#include "sim/camera.hpp"
#include "sim/aimsim.hpp"
#include "sim/cvlab.hpp"
#include "companion/ogfnil.hpp"
#include "common/profiles.hpp"
#include "render/renderer.hpp"
#include "render/overlay.hpp"

#include <mutex>
#include <shellapi.h>
#include <timeapi.h>
#include <glm/glm.hpp>

#include <cstdio>
#include <string>
#include <algorithm>
#include <atomic>
#include <thread>
#include <chrono>

#pragma comment(lib, "winmm.lib")

using namespace sfs4;
using sfs4::ui::FrameData;
using sfs4::ui::TargetDraw;

namespace {

struct App {
  Config cfg;
  sim::Camera cam;
  sim::TargetField field;
  sim::AimSim aim;
  Pacer pacer;
  render::Renderer renderer;

  bool running = true;
  bool settings_open = true;
  bool mouse_captured = false;
  bool dev_mode = false;
  bool licensed = false;
  lic::Fields license{};
  lic::License license_token{};     // full token for heartbeat re-send
  float session_t = 0.f;
  float cpu_pct = 0.f;
  float cpu_timer = 1.f;
  int win_w = 1600, win_h = 900;

  // heartbeat: 0 = ok, 1 = revoked (grace window running), 2 = exited grace
  std::atomic<int> hb_state{0};
  std::atomic<bool> hb_stop{false};
  std::chrono::steady_clock::time_point hb_revoked_at{};

  // CV lab worker output (guarded by atomics; boxes swapped under mutex)
  std::mutex cv_mutex;
  std::vector<cvlab::Rect> cv_boxes;
  cvlab::Metrics cv_metrics;
  std::atomic<bool> cv_stop{false};
};

App* g_app = nullptr;
render::Renderer* g_renderer = nullptr;

void set_capture(App& a, HWND hwnd, bool on) {
  if (a.mouse_captured == on) return;
  a.mouse_captured = on;
  if (on) {
    RECT r; GetClientRect(hwnd, &r);
    POINT tl{r.left, r.top}, br{r.right, r.bottom};
    ClientToScreen(hwnd, &tl); ClientToScreen(hwnd, &br);
    RECT s{tl.x, tl.y, br.x, br.y};
    ClipCursor(&s);
  } else {
    ClipCursor(nullptr);
  }
}

LRESULT WINAPI wnd_proc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
  if (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wp, lp)) return 1;

  App& a = *g_app;
  switch (msg) {
  case WM_SIZE: {
    if (wp == SIZE_MINIMIZED || !g_renderer) break;
    a.win_w = LOWORD(lp);
    a.win_h = HIWORD(lp);
    g_renderer->resize(a.win_w, a.win_h);
    return 0;
  }
  case WM_ACTIVATE:
    if (LOWORD(wp) == WA_INACTIVE) set_capture(a, hwnd, false);
    return 0;
  case WM_RBUTTONDOWN: {
    ImGuiIO& io = ImGui::GetIO();
    if (!io.WantCaptureMouse) set_capture(a, hwnd, true);
    return 0;
  }
  case WM_RBUTTONUP:
    set_capture(a, hwnd, false);
    return 0;
  case WM_INPUT: {
    if (!a.mouse_captured) break;
    UINT sz = sizeof(RAWINPUT);
    BYTE buf[sizeof(RAWINPUT)] = {};
    if (GetRawInputData((HRAWINPUT)lp, RID_INPUT, buf, &sz, sizeof(RAWINPUTHEADER)) == (UINT)-1)
      break;
    const RAWINPUT* r = (const RAWINPUT*)buf;
    if (r->header.dwType == RIM_TYPEMOUSE &&
        !(r->data.mouse.usFlags & MOUSE_MOVE_ABSOLUTE)) {
      a.cam.yaw   -= (float)r->data.mouse.lLastX * a.cfg.mouse_sens;
      a.cam.pitch -= (float)r->data.mouse.lLastY * a.cfg.mouse_sens;
      if (a.cam.pitch > 1.45f) a.cam.pitch = 1.45f;
      if (a.cam.pitch < -1.45f) a.cam.pitch = -1.45f;
      if (a.cam.yaw > 6.2831853f) a.cam.yaw -= 6.2831853f;
      if (a.cam.yaw < -6.2831853f) a.cam.yaw += 6.2831853f;
    }
    return 0;
  }
  case WM_KEYDOWN: {
    switch (wp) {
    case VK_F1: a.settings_open = !a.settings_open; return 0;
    case VK_F2: a.cfg.advanced_mode = !a.cfg.advanced_mode; return 0;
    case VK_ESCAPE:
      if (!ImGui::GetIO().WantCaptureKeyboard) a.running = false;
      return 0;
    case 'R': a.field.reset((unsigned)(a.session_t * 1000.f) + 7); return 0;
    }
    break;
  }
  case WM_DESTROY:
    PostQuitMessage(0);
    return 0;
  }
  return DefWindowProcW(hwnd, msg, wp, lp);
}

void apply_settings(App& a) {
  sim::AimParams p;
  p.enabled = a.cfg.aim_enabled;
  p.fov_deg = a.cfg.aim_fov_deg;
  p.smooth = a.cfg.aim_smooth;
  p.aim_head = a.cfg.aim_head;
  p.reaction_ms = a.cfg.reaction_ms;
  p.trig_enabled = a.cfg.trig_enabled;
  p.trig_spread_deg = a.cfg.trig_spread_deg;
  p.hitmarkers = a.cfg.hitmarkers;
  a.aim.set_params(p);
  a.field.config(a.cfg.target_count, a.cfg.target_min_dist, a.cfg.target_max_dist);
}

void movement(App& a, float dt) {
  if (!a.mouse_captured) return;
  const ImGuiIO& io = ImGui::GetIO();
  if (io.WantTextInput) return;

  const float speed = (GetAsyncKeyState(VK_SHIFT) & 0x8000) ? 12.f : 6.f;
  glm::vec3 move{0, 0, 0};
  const glm::vec3 fwd = a.cam.flat_forward();
  const glm::vec3 rgt = a.cam.right();
  if (GetAsyncKeyState('W') & 0x8000) move += fwd;
  if (GetAsyncKeyState('S') & 0x8000) move -= fwd;
  if (GetAsyncKeyState('D') & 0x8000) move += rgt;
  if (GetAsyncKeyState('A') & 0x8000) move -= rgt;
  if (glm::length(move) > 0.f) {
    move = glm::normalize(move) * speed * dt;
    a.cam.pos.x += move.x;
    a.cam.pos.z += move.z;
  }
}

bool startup_checks(App& a) {
  // 1) configuration tamper check
  const std::filesystem::path cfg_path = paths::config_file();
  std::string report;
  if (!integrity::config_verify(cfg_path, report)) {
    log::warn("integrity: " + report);
    a.cfg = Config{};               // refuse to honor tampered config
    save_config(a.cfg);
  } else {
    log::info("integrity: " + report);
  }

  // 2) self signature (informational in dev trees)
  const auto sig = integrity::self_signature_status();
  log::info(std::string("integrity: executable signature = ") + integrity::to_string(sig));

  // 3) distribution bundle hashes (only present in packaged installs)
  std::string bundle;
  integrity::verify_bundle(paths::exe_dir(), bundle);
  log::info(std::string("integrity: ") + bundle);

  // 4) license gate
  auto cached = lic::load_cached_activation();
  if (cached) {
    a.license = *cached;
    a.licensed = true;
    a.license_token.f = *cached;
    a.license_token.sig = lic::g_cached_sig;
    log::info("license: cached activation accepted for " + a.license.licensee);
  } else {
    std::string err;
    lic::Fields f;
    if (lic::secure_load_and_cache(paths::license_file(), f, err)) {
      a.license = f;
      a.licensed = true;
      a.license_token.f = f;
      a.license_token.sig = lic::g_cached_sig;
      log::info("license: verified " + f.licensee + " [" + f.plan + "]");
    } else if (a.dev_mode) {
      log::warn("license: dev bypass active (SFS4_DEV=1)");
    } else {
      MessageBoxA(nullptr,
        "No valid license found.\n\n"
        "Place a signed license.sfs4.json next to SimForgeS4.exe, or contact\n"
        "support to activate. (Developers: set SFS4_DEV=1 to bypass.)",
        "SimForge S4 — License", MB_OK | MB_ICONWARNING);
      log::error("license: " + err);
      return false;
    }
  }

  // 5) update check (only when an endpoint is configured)
  if (a.cfg.auto_check && !a.cfg.update_url.empty()) {
    std::string reason;
    auto m = upd::check(a.cfg.update_url, reason);
    if (m) {
      std::string err;
      if (upd::stage(*m, paths::exe_dir(), err)) {
        log::info("update: staged v" + std::to_string(m->version) + " — applied on exit");
      } else {
        log::warn("update: staging failed: " + err);
      }
    } else {
      log::info("update: " + reason);
    }
  }
  return true;
}

} // namespace

// ---- background: license heartbeat -----------------------------------------
// Sends the full signed license every 5 min. Server re-verifies signature and
// revocation. On revocation the app gets a 5-minute grace window, then exits
// gracefully. Network errors never kill the session (offline tolerance).
static void heartbeat_thread(App* a) {
  if (a->cfg.api_base.empty()) return;   // self-hosted/dev: no heartbeat
  while (!a->hb_stop) {
    std::string err;
    const lic::Heartbeat h = lic::heartbeat(a->cfg.api_base, a->license_token, err);
    if (h == lic::Heartbeat::Revoked) {
      if (a->hb_state.load() == 0) {
        a->hb_revoked_at = std::chrono::steady_clock::now();
        a->hb_state = 1;
        log::warn("license: REVOKED by server — grace window started");
      }
    } else if (h == lic::Heartbeat::Ok) {
      if (a->hb_state.exchange(0) == 1)
        log::info("license: revocation cleared by server");
    } else {
      log::warn("license: heartbeat error (offline tolerated): " + err);
    }
    for (int i = 0; i < 300 && !a->hb_stop; ++i)   // 5 min in 1s slices
      std::this_thread::sleep_for(std::chrono::seconds(1));
  }
}

// ---- background: CV lab research loop ---------------------------------------
// Purely synthetic: procedural frames generated + detected in this process.
static void cvlab_thread(App* a) {
  cvlab::Metrics last;
  while (!a->cv_stop) {
    if (!a->cfg.cv_lab) { std::this_thread::sleep_for(std::chrono::milliseconds(200)); continue; }

    if (ui::cv_bench_request.exchange(false)) {
      ui::cv_bench_active = true;
      cvlab::Metrics m{};
      const std::string err = cvlab::run_benchmark(120, 42, 640, 360, m);
      ui::cv_bench_error = err;
      ui::cv_bench_metrics = m;
      ui::cv_bench_done = true;
      ui::cv_bench_active = false;
      continue;
    }

    // continuous loop: one frame per tick, results surface in the inset
    cvlab::Frame f;
    cvlab::generate_frame((unsigned)(a->session_t * 10.0) + 1u, 640, 360, f);
    std::vector<cvlab::Rect> dets;
    double ms = 0.0;
#if SFS4_WITH_OPENCV
    const bool ok = cvlab::detect_cv(f, dets, ms);
#else
    const bool ok = cvlab::detect_pure(f, dets, ms);
#endif
    if (ok) {
      cvlab::Metrics s = cvlab::score(f, dets);
      s.avg_detect_ms = ms;
      std::lock_guard<std::mutex> lk(a->cv_mutex);
      a->cv_boxes = dets;
      a->cv_metrics = s;
    }
    std::this_thread::sleep_for(std::chrono::milliseconds(100));   // 10 Hz
  }
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, PWSTR, int nCmdShow) {
  SetProcessDPIAware();
  timeBeginPeriod(1);

  static App app;
  g_app = &app;
  g_renderer = &app.renderer;
  app.dev_mode = [] {
    char v[8] = {};
    const DWORD n = GetEnvironmentVariableA("SFS4_DEV", v, sizeof(v));
    return n > 0 && n < sizeof(v) && v[0] == '1';
  }();

  log::init(paths::log_file());
  log::info("SimForge S4 0.2.0 starting (dev_mode=" + std::string(app.dev_mode ? "1" : "0") + ")");

  app.cfg = load_config();
  if (!startup_checks(app)) { timeEndPeriod(1); return 2; }
  apply_settings(app);
  app.field.reset(1337);

  // ---- window --------------------------------------------------------------
  WNDCLASSEXW wc{sizeof(wc)};
  wc.style = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc = wnd_proc;
  wc.hInstance = hInst;
  wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
  wc.lpszClassName = L"SimForgeS4Wnd";
  RegisterClassExW(&wc);

  RECT wr{0, 0, (LONG)app.win_w, (LONG)app.win_h};
  AdjustWindowRect(&wr, WS_OVERLAPPEDWINDOW, FALSE);
  HWND hwnd = CreateWindowExW(0, wc.lpszClassName, L"SimForge S4 — synthetic season lab",
                              WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
                              wr.right - wr.left, wr.bottom - wr.top,
                              nullptr, nullptr, hInst, nullptr);
  if (!hwnd) { timeEndPeriod(1); return 3; }

  if (!app.renderer.init(hwnd)) {
    MessageBoxA(nullptr, "Direct3D 11 initialization failed.\nUpdate your GPU driver and retry.",
                "SimForge S4", MB_OK | MB_ICONERROR);
    timeEndPeriod(1);
    return 4;
  }

  // DPI-friendly font; falls back to ImGui default when missing.
  {
    ImGuiIO& io = ImGui::GetIO();
    io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\segoeui.ttf", 18.0f);
  }

  // raw mouse input for smooth look
  {
    RAWINPUTDEVICE rid{};
    rid.usUsagePage = 0x01;
    rid.usUsage = 0x02;
    rid.dwFlags = RIDEV_INPUTSINK;
    rid.hwndTarget = hwnd;
    RegisterRawInputDevices(&rid, 1, sizeof(rid));
  }

  ShowWindow(hwnd, nCmdShow);

  // background workers
  std::thread hb, cvw, monow;
  if (app.licensed) hb = std::thread(heartbeat_thread, &app);
  cvw = std::thread(cvlab_thread, &app);
  if (app.cfg.ogfnil_monitor) {
    ogfnil::configure({to_wide(app.cfg.ogfnil_launcher_path),
                       to_wide(app.cfg.ogfnil_game_path)});
    monow = std::thread(ogfnil::monitor_thread);
    log::info("companion: OGFNIL monitor started (observation-only)");
  } else {
    log::info("companion: OGFNIL monitor disabled in config");
  }

  // ---- main loop -------------------------------------------------------------
  const double fixed_dt = 1.0 / 120.0;
  double accumulator = 0.0;
  app.pacer.set_hz(app.cfg.target_hz);

  while (app.running) {
    app.pacer.begin_frame();

    MSG msg;
    while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
      TranslateMessage(&msg);
      DispatchMessageW(&msg);
      if (msg.message == WM_QUIT) app.running = false;
    }
    if (!app.running) break;

    const float dt = app.pacer.frame_ms / 1000.f;
    app.session_t += dt;

    // OGFNIL game start -> auto-apply the selected profile (sim subset only)
    if (app.cfg.ogfnil_auto_profile && !app.cfg.ogfnil_profile.empty() &&
        ogfnil::consume_game_start()) {
      std::string perr;
      Config pc;
      if (profiles::load(to_wide(app.cfg.ogfnil_profile), pc, perr)) {
        profiles::apply_sim(app.cfg, pc);
        log::info("companion: profile '" + app.cfg.ogfnil_profile +
                  "' applied on OGFNIL game start");
      } else {
        log::warn("companion: profile load failed: " + perr);
      }
    }

    app.cpu_timer -= dt;
    if (app.cpu_timer <= 0.f) {
      app.cpu_pct = Pacer::cpu_percent();
      app.cpu_timer = 1.f;
    }

    // revocation grace window: 5 minutes, then a graceful exit
    if (app.hb_state.load() == 1 &&
        std::chrono::duration_cast<std::chrono::seconds>(
            std::chrono::steady_clock::now() - app.hb_revoked_at).count() > 300) {
      app.hb_state = 2;
      log::warn("license: grace window elapsed — shutting down");
      app.running = false;
    }

    // fixed-step world simulation
    accumulator += std::min<double>((double)app.pacer.frame_ms, 100.0);
    while (accumulator >= fixed_dt) {
      app.field.tick((float)fixed_dt, glm::vec3(app.cam.pos.x, 0.f, app.cam.pos.z));
      accumulator -= fixed_dt;
    }

    movement(app, dt);
    apply_settings(app);

    // aim + trigger simulation (in-process only)
    const float aspect = (float)app.win_w / (float)std::max(1, app.win_h);
    const glm::mat4 vp = app.cam.vp(aspect);
    app.aim.update(dt, app.cam, app.field, (float)app.win_w, (float)app.win_h, vp, app.session_t);

    // frame data for the overlay
    FrameData fd;
    fd.w = (float)app.win_w;
    fd.h = (float)app.win_h;
    {
      std::lock_guard<std::mutex> lk(app.cv_mutex);
      fd.cv_boxes = app.cv_boxes;
      fd.cv_metrics = app.cv_metrics;
    }
    fd.targets.reserve(app.field.all().size());
    for (int i = 0; i < (int)app.field.all().size(); ++i) {
      const sim::Target& t = app.field.all()[i];
      TargetDraw td;
      td.index = i;
      td.kind = (int)t.kind;
      td.hp = t.hp;
      td.shield = t.shield;
      td.dist_m = glm::length(glm::vec2(t.pos.x - app.cam.pos.x, t.pos.z - app.cam.pos.z));
      const sim::Bones b = app.field.bones_of(t);
      for (int k = 0; k < (int)sim::Bone::Count; ++k) {
        td.on_screen[k] = sim::world_to_screen(b.p[k], vp, fd.w, fd.h, td.sx[k], td.sy[k]);
        // margin-clip: ignore points far off-screen
        if (td.on_screen[k] && (td.sx[k] < -80.f || td.sx[k] > fd.w + 80.f ||
                                td.sy[k] < -80.f || td.sy[k] > fd.h + 80.f))
          td.on_screen[k] = false;
      }
      td.visible = false;
      for (int k = 0; k < (int)sim::Bone::Count && !td.visible; ++k)
        td.visible = td.on_screen[k];
      fd.targets.push_back(td);
    }

    // draw
    app.renderer.new_frame(hwnd);
    app.renderer.begin_scene(0.055f, 0.065f, 0.085f);
    ui::draw_esp(app.cfg, fd);
    ui::draw_aim_overlay(app.cfg, app.aim, fd);
    ui::draw_stats(app.cfg, fd, app.aim, app.pacer.fps, app.pacer.avg_ms,
                   app.pacer.p99_ms, app.cpu_pct, app.renderer.gpu_name);
    if (app.settings_open) ui::draw_settings(app.cfg, app.field, app.session_t);
    ui::draw_cv_inset(app.cfg, fd);
    ui::draw_license_banner(app.licensed ? &app.license : nullptr, app.dev_mode);
    app.renderer.end_scene_and_present(app.cfg.vsync);

    app.pacer.end_frame();
  }

  set_capture(app, hwnd, false);

  // stop workers first
  ogfnil::request_stop();
  app.hb_stop = true;
  app.cv_stop = true;
  if (monow.joinable()) monow.join();
  if (hb.joinable()) hb.join();
  if (cvw.joinable()) cvw.join();

  // persist config + rebind its integrity HMAC
  save_config(app.cfg);
  integrity::config_rebinding(paths::config_file(), app.cfg);

  // apply a staged update if one was downloaded this session
  if (upd::apply_staged(paths::exe_dir()))
    log::info("update: staged update applied on exit");

  app.renderer.shutdown();
  DestroyWindow(hwnd);
  UnregisterClassW(wc.lpszClassName, hInst);
  timeEndPeriod(1);
  log::info("clean shutdown");
  return 0;
}
