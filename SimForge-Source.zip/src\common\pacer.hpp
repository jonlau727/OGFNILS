#pragma once
// Frame pacing + session stats. Built around QPC; Sleep(1)+spin hybrid keeps
// jitter low on a 165 Hz target without pegging a core when uncapped.
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <array>
#include <cstddef>

namespace sfs4 {

class Pacer {
public:
  void set_hz(int hz);              // 0 = uncapped
  void begin_frame();               // top of loop: starts timers
  void end_frame();                 // after present: throttles to target

  float fps = 0.f;                  // smoothed
  float frame_ms = 0.f;             // last frame
  float avg_ms = 0.f;               // rolling mean of window_
  float p99_ms = 0.f;               // rough p99 of window_

  // Sampled once per second by the app loop; returns busy% of wall time.
  static float cpu_percent();

private:
  void refresh_stats();
  LARGE_INTEGER freq_{}; 
  LARGE_INTEGER t0_{}; 
  LARGE_INTEGER tPrev_{};
  int hz_ = 0;
  std::array<float, 128> window_{}; 
  std::size_t wi_ = 0; 
  bool wrapped_ = false;
  float smooth_fps_ = 0.f;
};

} // namespace sfs4
