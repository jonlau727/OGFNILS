#include "common/log.hpp"
#include <spdlog/spdlog.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <memory>

namespace sfs4::log {

void init(const std::filesystem::path& file) {
  auto sink = std::make_shared<spdlog::sinks::basic_file_sink_mt>(file.string(), true);
  auto lg = std::make_shared<spdlog::logger>("sfs4", sink);
  lg->set_pattern("[%Y-%m-%d %H:%M:%S] [%l] %v");
  lg->set_level(spdlog::level::info);
  spdlog::set_default_logger(lg);
  spdlog::flush_every(std::chrono::seconds(1));
  spdlog::info("logging initialized: {}", file.string());
}

void info(const std::string& m)  { spdlog::info(m); }
void warn(const std::string& m)  { spdlog::warn(m); }
void error(const std::string& m) { spdlog::error(m); }

} // namespace sfs4::log
