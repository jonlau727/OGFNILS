#pragma once
// CV Lab — synthetic-image research module.
//
// Generates fully procedural frames (targets on a noisy background — no
// real-world imagery, no capture of anything), runs a detector over them,
// and scores detections against ground truth with IoU. Used to benchmark
// detection ideas entirely inside the sandbox.
//
// Two detector paths:
//   * pure C++ connected-components baseline — always compiled
//   * OpenCV (threshold + contours) — compiled when SFS4_WITH_OPENCV=1
#include <cstdint>
#include <string>
#include <vector>

namespace sfs4::cvlab {

struct Rect { float x = 0, y = 0, w = 0, h = 0; };

struct Frame {
  int w = 0, h = 0;
  std::vector<uint8_t> rgb;          // w*h*3
  std::vector<Rect> ground_truth;
  unsigned seed = 0;
};

struct Metrics {
  int frames = 0;
  int true_pos = 0, false_pos = 0, missed = 0;
  float mean_iou = 0.f;
  double avg_detect_ms = 0.0;
};

// Deterministic procedural frame: gradient background + Gaussian-ish noise
// + bright target rectangles (the "players"). Same seed -> same frame.
void generate_frame(unsigned seed, int w, int h, Frame& out);

// Pure C++ baseline: luminance threshold + connected components + bbox filter.
bool detect_pure(const Frame& f, std::vector<Rect>& out, double& ms_out);

#if SFS4_WITH_OPENCV
// OpenCV path: cv::threshold + findContours + boundingRect. Same contract.
bool detect_cv(const Frame& f, std::vector<Rect>& out, double& ms_out);
#endif

// Greedy one-to-one IoU matching at the given threshold.
Metrics score(const Frame& f, const std::vector<Rect>& dets, float iou_thresh = 0.45f);

// Runs `frames` iterations (generate + detect + score), accumulating metrics.
// error string empty on success.
std::string run_benchmark(int frames, unsigned seed0, int w, int h, Metrics& m);

} // namespace sfs4::cvlab
