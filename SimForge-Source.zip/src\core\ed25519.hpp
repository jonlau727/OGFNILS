#pragma once
// Ed25519 (via vendored TweetNaCl, public domain) — the product's signing
// primitive for licenses and update manifests.
//
// Key material:
//   * public key  = 32 bytes, shipped as verify.pub (single-line base64)
//   * secret key  = 64 bytes (seed||pub), NEVER shipped; lives on the
//     licensing server / signing workstation only
//
// Canonical strings that get signed (MUST match scripts + server):
//   license:  product|licensee|device_id|issued|expires|plan
//   update:   version|url|sha256
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

namespace sfs4::ed {

constexpr size_t PUB = 32;
constexpr size_t SIG = 64;
constexpr size_t SEC = 64;

bool keypair(uint8_t* pub_out, uint8_t* sec_out);           // 32 / 64 bytes
bool sign(const uint8_t sec[SEC], const std::string& msg, uint8_t sig_out[SIG]);
bool verify(const uint8_t pub[PUB], const std::string& msg, const uint8_t sig[SIG]);

// base64 helpers (standard alphabet, padded); decode ignores whitespace.
std::string b64_encode(const uint8_t* data, size_t len);
bool b64_decode(const std::string& in, std::vector<uint8_t>& out);

// Key file I/O: single-line base64 blobs.
bool load_pub_file(const std::filesystem::path& p, uint8_t pub_out[PUB], std::string& err);
bool load_sec_file(const std::filesystem::path& p, uint8_t sec_out[SEC], std::string& err);
bool save_pub_file(const std::filesystem::path& p, const uint8_t pub[PUB]);
bool save_sec_file(const std::filesystem::path& p, const uint8_t sec[SEC]);

} // namespace sfs4::ed
