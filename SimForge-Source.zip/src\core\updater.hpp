#pragma once
// Secure update flow (end-to-end Ed25519):
//   1. fetch manifest from the update endpoint (version|url|sha256|sig)
//   2. verify manifest Ed25519 signature against verify.pub
//   3. download package over HTTPS, check SHA-256
//   4. stage into %LOCALAPPDATA%\SimForgeS4\update\stage.exe
//   5. write apply-update.cmd (atomic swap + rollback); run at app exit
#include <filesystem>
#include <optional>
#include <string>

namespace sfs4::upd {

struct Manifest {
  long long version = 0;
  std::string url;
  std::string sha256;
  std::string sig;
};

// nullopt when: endpoint unset, fetch failed, signature rejected, or the
// incoming version <= CURRENT_VERSION. `reason` says which.
std::optional<Manifest> check(const std::string& update_url, std::string& reason);

// Downloads + verifies + stages + writes the apply script. Nothing is touched
// in the install dir until the swap runs.
bool stage(const Manifest& m, const std::filesystem::path& install_dir, std::string& err);

// If a staged apply script exists, launches it elevated and returns true.
// The script swaps the exe, restarts the app, and rolls back on failure.
bool apply_staged(const std::filesystem::path& install_dir);

} // namespace sfs4::upd
