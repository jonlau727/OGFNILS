#include "common/paths.hpp"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <shlobj.h>
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "ole32.lib")

namespace sfs4 {

std::string to_narrow(const std::wstring& w) {
  if (w.empty()) return {};
  const int n = WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), nullptr, 0, nullptr, nullptr);
  std::string out(n, 0);
  WideCharToMultiByte(CP_UTF8, 0, w.c_str(), (int)w.size(), out.data(), n, nullptr, nullptr);
  return out;
}

std::wstring to_wide(const std::string& s) {
  if (s.empty()) return {};
  const int n = MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), nullptr, 0);
  std::wstring out(n, 0);
  MultiByteToWideChar(CP_UTF8, 0, s.c_str(), (int)s.size(), out.data(), n);
  return out;
}

} // namespace sfs4

namespace sfs4::paths {

static std::filesystem::path module_path() {
  wchar_t buf[MAX_PATH]{};
  const DWORD n = GetModuleFileNameW(nullptr, buf, MAX_PATH);
  return std::filesystem::path(buf, buf + n);
}

std::filesystem::path exe_path() { return module_path(); }
std::filesystem::path exe_dir()  { return module_path().parent_path(); }

std::filesystem::path app_data_dir() {
  wchar_t* local = nullptr;
  std::filesystem::path root;
  if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &local))) {
    root = std::filesystem::path(local) / L"SimForgeS4";
    CoTaskMemFree(local);
  } else {
    root = exe_dir();
  }
  std::error_code ec;
  std::filesystem::create_directories(root, ec);
  return root;
}

std::filesystem::path log_file()           { return app_data_dir() / L"sfs4.log"; }
std::filesystem::path config_file()        { return exe_dir() / L"config.json"; }
std::filesystem::path config_hmac_file()   { return app_data_dir() / L"config.hmac"; }
std::filesystem::path integrity_key_file() { return app_data_dir() / L"integrity.key"; }
std::filesystem::path key_file()           { return exe_dir() / L"verify.pub"; }
std::filesystem::path license_file()       { return exe_dir() / L"license.sfs4.json"; }
std::filesystem::path session_file()       { return app_data_dir() / L"session.bin"; }

std::filesystem::path update_stage_dir() {
  std::filesystem::path d = app_data_dir() / L"update";
  std::error_code ec;
  std::filesystem::create_directories(d, ec);
  return d;
}

} // namespace sfs4::paths
