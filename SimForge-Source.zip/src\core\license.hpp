#pragma once
// Licensing: Ed25519-signed license tokens (license.sfs4.json) verified
// against verify.pub. Activation + heartbeat talk to the licensing server
// (src/server); the client keeps working offline within the grace window.
#include <filesystem>
#include <optional>
#include <string>

namespace sfs4::lic {

struct Fields {
  std::string product;    // "simforge-s4"
  std::string licensee;
  std::string device_id;  // "*" widens it (site license)
  long long issued = 0;
  long long expires = 0;  // epoch seconds; 0 = no expiry
  std::string plan;       // "standard"|"pro"|"dev"
};

struct License {
  Fields f;
  std::string sig;        // base64 Ed25519 signature over canonical(Fields)
  std::string raw;        // original JSON text
};

// Canonical string EXACTLY as the server and sfs4_sign build it:
//   product|licensee|device_id|issued|expires|plan
std::string canonical(const Fields& f);

std::optional<License> load_from_file(const std::filesystem::path& p, std::string& err);

// Verifies signature, device binding, expiry; caches a DPAPI activation blob.
bool secure_load_and_cache(const std::filesystem::path& p, Fields& out, std::string& err);

// Fast path: DPAPI blob from a previous successful activation.
std::optional<Fields> load_cached_activation();

// ---- server interaction -----------------------------------------------------

enum class ActivateResult { Ok, Rejected, NetworkError };
ActivateResult activate_remote(const std::string& api_base, const std::string& license_key,
                               Fields& out, std::string& err);

enum class Heartbeat { Ok, Revoked, Error };
// Sends the full license (fields + sig); server re-verifies and checks revocation.
Heartbeat heartbeat(const std::string& api_base, const License& lic, std::string& err);

// Base64 signature of the most recently verified license; set by
// load_cached_activation / activate_remote / secure_load_and_cache.
extern std::string g_cached_sig;

std::string device_guid();

} // namespace sfs4::lic
