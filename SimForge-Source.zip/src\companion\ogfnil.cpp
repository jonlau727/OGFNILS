#include "companion/ogfnil.hpp"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <shellapi.h>
#include <tlhelp32.h>
#include <shlobj.h>
#include <psapi.h>
#include <cwchar>
#include <algorithm>
#include <atomic>
#include <filesystem>
#include <mutex>
#include <thread>

#include "common/log.hpp"
#include "common/paths.hpp"

#pragma comment(lib, "version.lib")

namespace sfs4::ogfnil {

// ---- discovery ----------------------------------------------------------------

std::vector<ProcessInfo> find_processes_by_name(const wchar_t* exe_name) {
  std::vector<ProcessInfo> out;
  const HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
  if (snap == INVALID_HANDLE_VALUE) return out;
  PROCESSENTRY32W pe{};
  pe.dwSize = sizeof(pe);
  if (Process32FirstW(snap, &pe)) {
    do {
      if (_wcsicmp(pe.szExeFile, exe_name) == 0) out.push_back({pe.th32ProcessID});
    } while (Process32NextW(snap, &pe));
  }
  CloseHandle(snap);
  return out;
}

bool pid_matches_path(unsigned long pid, const std::wstring& expected_path) {
  // QUERY_LIMITED_INFORMATION is the most restrictive documented right that
  // still allows QueryFullProcessImageNameW — metadata only, no memory access.
  const HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
  if (!h) return false;
  wchar_t buf[MAX_PATH * 2]{};
  DWORD sz = (DWORD)(sizeof(buf) / sizeof(buf[0]));
  const bool ok = QueryFullProcessImageNameW(h, 0, buf, &sz) &&
                  _wcsicmp(std::wstring(buf, sz).c_str(), expected_path.c_str()) == 0;
  CloseHandle(h);
  return ok;
}

std::wstring file_version(const std::wstring& exe_path) {
  DWORD handle = 0;
  const DWORD sz = GetFileVersionInfoSizeW(exe_path.c_str(), &handle);
  if (sz == 0) return {};
  std::vector<BYTE> data(sz);
  if (!GetFileVersionInfoW(exe_path.c_str(), 0, sz, data.data())) return {};
  VS_FIXEDFILEINFO* ffi = nullptr;
  UINT len = 0;
  if (!VerQueryValueW(data.data(), L"\\", (LPVOID*)&ffi, &len) || !ffi) return {};
  wchar_t buf[64]{};
  swprintf_s(buf, L"%u.%u.%u.%u",
             HIWORD(ffi->dwFileVersionMS), LOWORD(ffi->dwFileVersionMS),
             HIWORD(ffi->dwFileVersionLS), LOWORD(ffi->dwFileVersionLS));
  return buf;
}

std::wstring detect_launcher_path() {
  wchar_t* local = nullptr;
  std::wstring base;
  if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &local))) {
    base = std::wstring(local) + L"\\OG FN IL Launcher\\" + kLauncherExe;
    CoTaskMemFree(local);
  }
  std::error_code ec;
  if (!base.empty() && std::filesystem::exists(base, ec)) return base;
  return {};
}

std::wstring detect_game_path() {
  wchar_t* docs = nullptr;
  std::filesystem::path root;
  if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Documents, 0, nullptr, &docs))) {
    root = std::filesystem::path(docs) / L"ogfnil";
    CoTaskMemFree(docs);
  }
  // Pick the highest-versioned install directory (lexicographic on the folder
  // name — "14.30" style names order correctly in practice).
  std::error_code ec;
  std::filesystem::directory_iterator it(root, ec), end;
  if (ec) return {};
  std::wstring best_dir, best_exe;
  for (; it != end; ++it) {
    const auto cand = it->path() / L"FortniteGame" / L"Binaries" / L"Win64" / kGameExe;
    std::error_code ec2;
    if (!std::filesystem::exists(cand, ec2)) continue;
    const std::wstring dir = it->path().filename().wstring();
    if (dir > best_dir) {
      best_dir = dir;
      best_exe = cand.wstring();
    }
  }
  return best_exe;
}

std::string launch_launcher(const std::wstring& launcher_path) {
  std::error_code ec;
  if (launcher_path.empty() || !std::filesystem::exists(launcher_path, ec))
    return "launcher executable not found";
  const HINSTANCE r = ShellExecuteW(nullptr, L"open", launcher_path.c_str(),
                                    nullptr, nullptr, SW_SHOWNORMAL);
  const INT_PTR code = reinterpret_cast<INT_PTR>(r);
  return code > 32 ? std::string() : "ShellExecute failed (code " + std::to_string(code) + ")";
}

// ---- lifecycle monitor --------------------------------------------------------

namespace {

std::mutex g_mtx;
Paths g_paths;
Snapshot g_snap;
std::wstring g_cached_launcher;   // last auto-detection results (avoid re-probing)
std::wstring g_cached_game;

std::atomic<bool> g_stop{false};
std::atomic<bool> g_refresh{false};
std::atomic<bool> g_game_start{false};

bool any_pid_matches(const std::vector<ProcessInfo>& procs, const std::wstring& path) {
  size_t checked = 0;
  for (const auto& p : procs) {
    if (++checked > 8) break;   // bounded: enough to disambiguate duplicates
    if (pid_matches_path(p.pid, path)) return true;
  }
  return false;
}

} // namespace

Transition apply_observation(TargetState& st, const std::vector<ProcessInfo>& now,
                             bool path_confirmed, bool first_observation,
                             const char* label, std::string& event_out) {
  const auto now_tp = std::chrono::system_clock::now();
  const bool running = path_confirmed && !now.empty();
  const bool was = (st.state == ProcState::Running);

  if (running && !was) {
    st.state = ProcState::Running;
    st.pids.clear();
    for (const auto& p : now) st.pids.push_back(p.pid);
    st.last_change = now_tp;
    st.unexpected_exit = false;
    if (!first_observation) {
      st.restarts += 1;
      event_out = std::string(label) + " restarted (pid " + std::to_string(st.pids[0]) + ")";
    } else {
      event_out = std::string(label) + " detected running (pid " + std::to_string(st.pids[0]) + ")";
    }
    return Transition::Started;
  }
  if (!running && was) {
    st.state = ProcState::Stopped;
    st.pids.clear();
    st.last_change = now_tp;
    st.unexpected_exit = !first_observation;
    event_out = std::string(label) + (st.unexpected_exit ? " exited (unexpected)" : " exited");
    return Transition::Stopped;
  }
  if (!running) {
    // Definitive "not running" — also seeds Unknown -> Stopped on the first
    // poll, and covers name-matches-but-path-mismatches (not our target).
    if (st.state != ProcState::Stopped) {
      st.state = ProcState::Stopped;
      st.pids.clear();
      st.last_change = now_tp;
    }
  }
  if (running && was) {
    bool same = st.pids.size() == now.size();
    for (size_t i = 0; same && i < now.size(); ++i) same = st.pids[i] == now[i].pid;
    st.pids.clear();
    for (const auto& p : now) st.pids.push_back(p.pid);
    if (!same) event_out = std::string(label) + " pid set changed";
  }
  return Transition::None;
}

Snapshot snapshot() {
  std::lock_guard<std::mutex> lk(g_mtx);
  return g_snap;
}

void configure(const Paths& p) {
  {
    std::lock_guard<std::mutex> lk(g_mtx);
    g_paths = p;
    g_cached_launcher.clear();
    g_cached_game.clear();
    g_snap.paths = p;
  }
  g_refresh = true;
}

void refresh_now() { g_refresh = true; }

void note_event(const std::string& msg) {
  std::lock_guard<std::mutex> lk(g_mtx);
  g_snap.last_event = msg;
  g_snap.last_event_at = std::chrono::system_clock::now();
}

bool consume_game_start() { return g_game_start.exchange(false); }

void request_stop() { g_stop = true; }

void monitor_thread() {
  bool first_launcher = true, first_game = true;
  std::wstring version_path, version_cache;

  for (;;) {
    if (g_stop.load()) break;

    Snapshot s;
    {
      std::lock_guard<std::mutex> lk(g_mtx);
      s.paths = g_paths;
      // fall back to cached detection so a configured-then-cleared path keeps
      // resolving without re-probing the filesystem every poll
      if (s.paths.launcher.empty()) s.paths.launcher = g_cached_launcher;
      if (s.paths.game.empty()) s.paths.game = g_cached_game;
    }

    if (s.paths.launcher.empty()) {
      s.paths.launcher = detect_launcher_path();
      if (!s.paths.launcher.empty()) {
        std::lock_guard<std::mutex> lk(g_mtx);
        g_cached_launcher = s.paths.launcher;
      }
    }
    if (s.paths.game.empty()) {
      s.paths.game = detect_game_path();
      if (!s.paths.game.empty()) {
        std::lock_guard<std::mutex> lk(g_mtx);
        g_cached_game = s.paths.game;
      }
    }

    std::string ev;
    if (!s.paths.launcher.empty()) {
      const auto procs = find_processes_by_name(kLauncherExe);
      const bool conf = any_pid_matches(procs, s.paths.launcher);
      apply_observation(s.launcher, procs, conf, first_launcher, "launcher", ev);
      first_launcher = false;
    } else {
      s.launcher.state = ProcState::Unknown;
    }

    if (!s.paths.game.empty()) {
      const auto procs = find_processes_by_name(kGameExe);
      const bool conf = any_pid_matches(procs, s.paths.game);
      const Transition t = apply_observation(s.game, procs, conf, first_game, "game", ev);
      first_game = false;
      if (t == Transition::Started) g_game_start = true;
      if (version_path != s.paths.game) {
        s.game_version = file_version(s.paths.game);
        version_path = s.paths.game;
        version_cache = s.game_version;
      } else {
        s.game_version = version_cache;
      }
    } else {
      s.game.state = ProcState::Unknown;
    }

    if (s.paths.launcher.empty() && s.paths.game.empty())
      s.last_error = "launcher/game not configured and auto-detection found nothing";
    else
      s.last_error.clear();
    s.monitor_running = true;

    {
      std::lock_guard<std::mutex> lk(g_mtx);
      if (ev.empty()) {
        s.last_event = g_snap.last_event;
        s.last_event_at = g_snap.last_event_at;
      } else {
        s.last_event = ev;
        s.last_event_at = std::chrono::system_clock::now();
        log::info("companion: " + ev);
      }
      g_snap = s;
    }

    // 2s poll in 100ms slices so stop/refresh stay responsive
    for (int i = 0; i < 20 && !g_stop && !g_refresh.load(); ++i)
      std::this_thread::sleep_for(std::chrono::milliseconds(100));
    g_refresh = false;
  }
}

} // namespace sfs4::ogfnil
