#include "core/integrity.hpp"
#include "common/config.hpp"
#include "common/log.hpp"
#include "common/paths.hpp"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#define WIN32_NO_STATUS   // ntstatus.h owns the STATUS_* names; windows.h must not
#include <windows.h>
#include <wincrypt.h>
#include <bcrypt.h>
#include <softpub.h>
#include <wintrust.h>
#undef WIN32_NO_STATUS
#include <ntstatus.h>
#include <nlohmann/json.hpp>
#include <fstream>
#include <sstream>
#include <vector>
#include <array>
#include <iterator>

#pragma comment(lib, "bcrypt.lib")
#pragma comment(lib, "crypt32.lib")
#pragma comment(lib, "wintrust.lib")

using json = nlohmann::json;

namespace sfs4::integrity {

const char* to_string(SigStatus s) {
  switch (s) {
    case SigStatus::Trusted: return "trusted";
    case SigStatus::Unsigned: return "unsigned";
    case SigStatus::Bad: return "bad signature";
    case SigStatus::Error: return "error";
    default: return "skipped";
  }
}

SigStatus self_signature_status() {
  wchar_t path[MAX_PATH]{};
  if (!GetModuleFileNameW(nullptr, path, MAX_PATH)) return SigStatus::Error;

  WINTRUST_FILE_INFO fi{};
  fi.cbStruct = sizeof(fi);
  fi.pcwszFilePath = path;

  WINTRUST_DATA wd{};
  wd.cbStruct = sizeof(wd);
  wd.dwUIChoice = WTD_UI_NONE;
  wd.fdwRevocationChecks = WTD_REVOKE_NONE;
  wd.dwUnionChoice = WTD_CHOICE_FILE;
  wd.dwStateAction = WTD_STATEACTION_VERIFY;
  wd.pFile = &fi;

  GUID action = WINTRUST_ACTION_GENERIC_VERIFY_V2;
  const LONG st = WinVerifyTrust((HWND)INVALID_HANDLE_VALUE, &action, &wd);

  wd.dwStateAction = WTD_STATEACTION_CLOSE;
  WinVerifyTrust((HWND)INVALID_HANDLE_VALUE, &action, &wd);

  if (st == 0) return SigStatus::Trusted;
  if (st == TRUST_E_NOSIGNATURE) return SigStatus::Unsigned;
  if (st == TRUST_E_EXPLICIT_DISTRUST || st == TRUST_E_FAIL || st == CERT_E_REVOKED)
    return SigStatus::Bad;
  return SigStatus::Error;
}

static bool sha_bytes(const uint8_t* data, size_t len, uint8_t out[32]) {
  BCRYPT_ALG_HANDLE hAlg = nullptr;
  if (BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_SHA256_ALGORITHM, nullptr, 0) != STATUS_SUCCESS)
    return false;
  BCRYPT_HASH_HANDLE hHash = nullptr;
  DWORD objLen = 0, cb = 0;
  bool ok = false;
  if (BCryptGetProperty(hAlg, BCRYPT_OBJECT_LENGTH, (PUCHAR)&objLen, sizeof(objLen), &cb, 0) == STATUS_SUCCESS) {
    std::vector<uint8_t> obj(objLen);
    if (BCryptCreateHash(hAlg, &hHash, obj.data(), objLen, nullptr, 0, 0) == STATUS_SUCCESS) {
      BCryptHashData(hHash, (PUCHAR)data, (ULONG)len, 0);
      ok = BCryptFinishHash(hHash, out, 32, 0) == STATUS_SUCCESS;
      BCryptDestroyHash(hHash);
    }
  }
  BCryptCloseAlgorithmProvider(hAlg, 0);
  return ok;
}

bool sha256_file(const std::filesystem::path& p, std::string& hex_out) {
  std::ifstream f(p, std::ios::binary);
  if (!f) return false;

  BCRYPT_ALG_HANDLE hAlg = nullptr;
  if (BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_SHA256_ALGORITHM, nullptr, 0) != STATUS_SUCCESS)
    return false;
  DWORD objLen = 0, cb = 0;
  BCryptGetProperty(hAlg, BCRYPT_OBJECT_LENGTH, (PUCHAR)&objLen, sizeof(objLen), &cb, 0);
  std::vector<uint8_t> obj(objLen);

  BCRYPT_HASH_HANDLE hHash = nullptr;
  bool ok = BCryptCreateHash(hAlg, &hHash, obj.data(), objLen, nullptr, 0, 0) == STATUS_SUCCESS;
  std::array<char, 65536> buf{};
  while (ok && f) {
    f.read(buf.data(), buf.size());
    const std::streamsize got = f.gcount();
    if (got > 0 && BCryptHashData(hHash, (PUCHAR)buf.data(), (ULONG)got, 0) != STATUS_SUCCESS) {
      ok = false; break;
    }
    if (got == 0) break;
  }
  uint8_t digest[32]{};
  if (ok) ok = BCryptFinishHash(hHash, digest, sizeof(digest), 0) == STATUS_SUCCESS;
  BCryptDestroyHash(hHash);
  BCryptCloseAlgorithmProvider(hAlg, 0);
  if (!ok) return false;

  static const char* hexd = "0123456789abcdef";
  hex_out.clear();
  hex_out.reserve(64);
  for (uint8_t b : digest) { hex_out.push_back(hexd[b >> 4]); hex_out.push_back(hexd[b & 0xF]); }
  return true;
}

bool sha256_bytes(const std::string& data, std::string& hex_out) {
  uint8_t digest[32];
  if (!sha_bytes((const uint8_t*)data.data(), data.size(), digest)) return false;
  static const char* hexd = "0123456789abcdef";
  hex_out.clear();
  hex_out.reserve(64);
  for (uint8_t b : digest) { hex_out.push_back(hexd[b >> 4]); hex_out.push_back(hexd[b & 0xF]); }
  return true;
}

bool verify_bundle(const std::filesystem::path& dir, std::string& report) {
  report.clear();
  const std::filesystem::path mf = dir / L"bundle.sha256.json";
  if (!std::filesystem::exists(mf)) {
    report = "no manifest (dev tree) - bundle checks skipped";
    return true;
  }
  std::ifstream f(mf, std::ios::binary);
  std::stringstream ss; ss << f.rdbuf();
  json j;
  try { j = json::parse(ss.str()); }
  catch (...) { report = "manifest unparseable - bundle considered corrupt"; return false; }

  bool all_ok = true;
  if (!j.contains("files") || !j["files"].is_array()) {
    report = "manifest has no file list"; return false;
  }
  for (const auto& e : j["files"]) {
    if (!e.contains("name") || !e.contains("sha256")) continue;
    const std::string name = e["name"].get<std::string>();
    const std::string want = e["sha256"].get<std::string>();
    const std::filesystem::path p = dir / to_wide(name);
    std::string got;
    if (!std::filesystem::exists(p)) {
      report += name + ": missing; "; all_ok = false; continue;
    }
    if (!sha256_file(p, got) || _stricmp(got.c_str(), want.c_str()) != 0) {
      report += name + ": hash mismatch; "; all_ok = false;
    }
  }
  if (all_ok) report = "bundle verified (" + std::to_string(j["files"].size()) + " files)";
  return all_ok;
}

// ---- config HMAC binding ----

namespace {

bool derive_or_load_key(std::vector<uint8_t>& key) {
  const std::filesystem::path kf = paths::integrity_key_file();
  // Existing: DPAPI-encrypted blob → unprotect.
  if (std::filesystem::exists(kf)) {
    std::ifstream f(kf, std::ios::binary);
    std::vector<uint8_t> blob((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    if (blob.empty()) return false;
    DATA_BLOB in{}, out{};
    in.cbData = (DWORD)blob.size();
    in.pbData = blob.data();
    if (!CryptUnprotectData(&in, nullptr, nullptr, 0, nullptr, 0, &out)) return false;
    key.assign(out.pbData, out.pbData + out.cbData);
    LocalFree(out.pbData);
    return key.size() == 32;
  }
  // Fresh install: generate 32 random bytes, protect, store.
  key.resize(32);
  if (BCryptGenRandom(nullptr, key.data(), 32, BCRYPT_USE_SYSTEM_PREFERRED_RNG) != STATUS_SUCCESS)
    return false;
  DATA_BLOB in{}, out{};
  in.cbData = (DWORD)key.size();
  in.pbData = key.data();
  if (!CryptProtectData(&in, L"sfs4-integrity", nullptr, 0, nullptr, 0, &out)) return false;
  std::ofstream f(kf, std::ios::binary | std::ios::trunc);
  f.write((const char*)out.pbData, out.cbData);
  LocalFree(out.pbData);
  return true;
}

bool hmac_config(const std::vector<uint8_t>& key, const std::filesystem::path& cfg, std::string& hex_out) {
  std::ifstream f(cfg, std::ios::binary);
  std::vector<uint8_t> data((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  if (data.empty()) { hex_out.clear(); return false; }

  BCRYPT_ALG_HANDLE hAlg = nullptr;
  if (BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_SHA256_ALGORITHM, MS_PRIMITIVE_PROVIDER,
                                  BCRYPT_ALG_HANDLE_HMAC_FLAG) != STATUS_SUCCESS)
    return false;
  BCRYPT_HASH_HANDLE hHash = nullptr;
  DWORD objLen = 0, cb = 0, hashLen = 0;
  bool ok = false;
  if (BCryptGetProperty(hAlg, BCRYPT_OBJECT_LENGTH, (PUCHAR)&objLen, sizeof(objLen), &cb, 0) == STATUS_SUCCESS &&
      BCryptGetProperty(hAlg, BCRYPT_HASH_LENGTH, (PUCHAR)&hashLen, sizeof(hashLen), &cb, 0) == STATUS_SUCCESS) {
    std::vector<uint8_t> obj(objLen);
    if (BCryptCreateHash(hAlg, &hHash, obj.data(), objLen, (PUCHAR)key.data(), (ULONG)key.size(), 0) == STATUS_SUCCESS) {
      BCryptHashData(hHash, (PUCHAR)data.data(), (ULONG)data.size(), 0);
      std::vector<uint8_t> dig(hashLen);
      ok = BCryptFinishHash(hHash, dig.data(), hashLen, 0) == STATUS_SUCCESS;
      BCryptDestroyHash(hHash);
      if (ok) {
        static const char* hexd = "0123456789abcdef";
        hex_out.clear();
        hex_out.reserve(dig.size() * 2);
        for (uint8_t b : dig) { hex_out.push_back(hexd[b >> 4]); hex_out.push_back(hexd[b & 0xF]); }
      }
    }
  }
  BCryptCloseAlgorithmProvider(hAlg, 0);
  return ok;
}

bool read_hmac_file(std::string& out) {
  const std::filesystem::path hf = paths::config_hmac_file();
  if (!std::filesystem::exists(hf)) return false;
  std::ifstream f(hf);
  std::getline(f, out);
  while (!out.empty() && (out.back() == '\r' || out.back() == '\n' || out.back() == ' ')) out.pop_back();
  return !out.empty();
}

} // namespace

void config_rebinding(const std::filesystem::path& cfg_file, const Config&) {
  // Binding is over file bytes, not the struct — keeps it byte-accurate
  // even if serialization changes version to version.
  std::vector<uint8_t> key;
  if (!derive_or_load_key(key)) return;
  std::string mac;
  if (!hmac_config(key, cfg_file, mac)) return;
  std::ofstream hf(paths::config_hmac_file(), std::ios::trunc);
  if (hf) hf << mac << "\n";
}

bool config_verify(const std::filesystem::path& cfg_file, std::string& report) {
  report.clear();
  std::vector<uint8_t> key;
  if (!derive_or_load_key(key)) { report = "integrity key unavailable - config binding skipped"; return true; }

  if (!std::filesystem::exists(cfg_file)) { report = "no config file (first run)"; return true; }
  std::string mac_file;
  if (!read_hmac_file(mac_file)) {
    // First binding after initial deploy.
    std::string mac;
    if (hmac_config(key, cfg_file, mac)) {
      std::ofstream hf(paths::config_hmac_file(), std::ios::trunc);
      if (hf) { hf << mac << "\n"; report = "config binding created"; return true; }
    }
    report = "config binding failed";
    return false;
  }
  std::string mac_now;
  if (!hmac_config(key, cfg_file, mac_now)) { report = "hmac computation failed"; return false; }
  if (_stricmp(mac_now.c_str(), mac_file.c_str()) != 0) {
    report = "config modified outside the application - restoring defaults";
    return false;
  }
  report = "config verified";
  return true;
}

} // namespace sfs4::integrity
