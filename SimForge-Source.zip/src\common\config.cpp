#include "common/config.hpp"
#include "common/paths.hpp"
#include <nlohmann/json.hpp>
#include <fstream>
#include <sstream>
#include <algorithm>

using json = nlohmann::json;

namespace sfs4 {

static json to_json(const Config& c) {
  json j;
  j["mode"]["advanced"] = c.advanced_mode;
  j["esp"]["boxes"] = c.esp_boxes;
  j["esp"]["skeleton"] = c.esp_skeleton;
  j["esp"]["health"] = c.esp_health;
  j["esp"]["distance"] = c.esp_distance;
  j["esp"]["names"] = c.esp_names;
  j["esp"]["fov_ring"] = c.esp_fov_ring;
  j["esp"]["aura_alpha"] = c.aura_alpha;
  j["esp"]["box_thick"] = c.box_thick;
  j["esp"]["fov_px"] = c.fov_px;
  j["esp"]["line_thick"] = c.line_thick;
  j["aim"]["enabled"] = c.aim_enabled;
  j["aim"]["fov_deg"] = c.aim_fov_deg;
  j["aim"]["smooth"] = c.aim_smooth;
  j["aim"]["aim_head"] = c.aim_head;
  j["aim"]["reaction_ms"] = c.reaction_ms;
  j["trigger"]["enabled"] = c.trig_enabled;
  j["trigger"]["spread_deg"] = c.trig_spread_deg;
  j["trigger"]["hitmarkers"] = c.hitmarkers;
  j["world"]["target_count"] = c.target_count;
  j["world"]["target_min_dist"] = c.target_min_dist;
  j["world"]["target_max_dist"] = c.target_max_dist;
  j["camera"]["mouse_sens"] = c.mouse_sens;
  j["perf"]["target_hz"] = c.target_hz;
  j["perf"]["vsync"] = c.vsync;
  j["server"]["api_base"] = c.api_base;
  j["server"]["update_url"] = c.update_url;
  j["server"]["auto_check"] = c.auto_check;
  j["cvlab"]["enabled"] = c.cv_lab;
  j["cvlab"]["overlay"] = c.cv_lab_overlay;
  j["ogfnil"]["launcher_path"] = c.ogfnil_launcher_path;
  j["ogfnil"]["game_path"] = c.ogfnil_game_path;
  j["ogfnil"]["monitor"] = c.ogfnil_monitor;
  j["ogfnil"]["profile"] = c.ogfnil_profile;
  j["ogfnil"]["auto_profile"] = c.ogfnil_auto_profile;
  return j;
}

static void from_json(const json& j, Config& c) {
  auto get_bool   = [&](const char* a, const char* b, bool def = false) { return j.contains(a) && j[a].contains(b) && j[a][b].is_boolean() ? j[a][b].get<bool>() : def; };
  auto get_float  = [&](const char* a, const char* b, float def) { return j.contains(a) && j[a].contains(b) && j[a][b].is_number() ? j[a][b].get<float>() : def; };
  auto get_int    = [&](const char* a, const char* b, int def)   { return j.contains(a) && j[a].contains(b) && j[a][b].is_number() ? j[a][b].get<int>() : def; };
  auto get_string = [&](const char* a, const char* b) { return j.contains(a) && j[a].contains(b) && j[a][b].is_string() ? j[a][b].get<std::string>() : std::string{}; };

  c.advanced_mode   = get_bool("mode", "advanced");
  c.esp_boxes       = get_bool("esp", "boxes");
  c.esp_skeleton    = get_bool("esp", "skeleton");
  c.esp_health      = get_bool("esp", "health");
  c.esp_distance    = get_bool("esp", "distance");
  c.esp_names       = get_bool("esp", "names");
  c.esp_fov_ring    = get_bool("esp", "fov_ring");
  c.aura_alpha      = get_float("esp", "aura_alpha", c.aura_alpha);
  c.box_thick       = get_float("esp", "box_thick", c.box_thick);
  c.fov_px          = get_float("esp", "fov_px", c.fov_px);
  c.line_thick      = get_float("esp", "line_thick", c.line_thick);
  c.aim_enabled     = get_bool("aim", "enabled");
  c.aim_fov_deg     = get_float("aim", "fov_deg", c.aim_fov_deg);
  c.aim_smooth      = get_float("aim", "smooth", c.aim_smooth);
  c.aim_head        = get_bool("aim", "aim_head");
  c.reaction_ms     = get_int("aim", "reaction_ms", c.reaction_ms);
  c.trig_enabled    = get_bool("trigger", "enabled");
  c.trig_spread_deg = get_float("trigger", "spread_deg", c.trig_spread_deg);
  c.hitmarkers      = get_bool("trigger", "hitmarkers");
  c.target_count    = get_int("world", "target_count", c.target_count);
  c.target_min_dist = get_float("world", "target_min_dist", c.target_min_dist);
  c.target_max_dist = get_float("world", "target_max_dist", c.target_max_dist);
  c.mouse_sens      = get_float("camera", "mouse_sens", c.mouse_sens);
  c.target_hz       = get_int("perf", "target_hz", c.target_hz);
  c.vsync           = get_bool("perf", "vsync");
  c.api_base        = get_string("server", "api_base");
  c.update_url      = get_string("server", "update_url");
  c.auto_check      = get_bool("server", "auto_check");
  c.cv_lab          = get_bool("cvlab", "enabled");
  c.cv_lab_overlay  = get_bool("cvlab", "overlay");
  c.ogfnil_launcher_path = get_string("ogfnil", "launcher_path");
  c.ogfnil_game_path     = get_string("ogfnil", "game_path");
  c.ogfnil_monitor       = get_bool("ogfnil", "monitor", true);   // default-on for pre-existing configs
  c.ogfnil_profile       = get_string("ogfnil", "profile");
  c.ogfnil_auto_profile  = get_bool("ogfnil", "auto_profile");

  // Clamp to sane ranges — config is user-editable, never trust it blindly.
  c.aura_alpha   = std::clamp(c.aura_alpha, 0.2f, 1.0f);
  c.box_thick    = std::clamp(c.box_thick, 0.5f, 6.0f);
  c.fov_px       = std::clamp(c.fov_px, 20.f, 900.f);
  c.line_thick   = std::clamp(c.line_thick, 0.5f, 6.0f);
  c.aim_fov_deg  = std::clamp(c.aim_fov_deg, 1.f, 89.f);
  c.aim_smooth   = std::clamp(c.aim_smooth, 0.02f, 0.95f);
  c.mouse_sens   = std::clamp(c.mouse_sens, 0.0001f, 0.02f);
  c.reaction_ms  = std::clamp(c.reaction_ms, 30, 900);
  c.target_count = std::clamp(c.target_count, 1, 64);
  if (c.target_min_dist < 3.f) c.target_min_dist = 3.f;
  if (c.target_max_dist > 400.f) c.target_max_dist = 400.f;
  if (c.target_min_dist > c.target_max_dist) c.target_max_dist = c.target_min_dist + 5.f;
  if (c.target_hz < 0) c.target_hz = 0;
  if (c.target_hz > 360) c.target_hz = 360;
}

std::string config_to_raw(const Config& c) {
  std::ostringstream os;
  os << to_json(c).dump(2) << "\n";
  return os.str();
}

Config config_from_raw(const std::string& raw, bool& ok) {
  Config c;
  try {
    json j = json::parse(raw);
    from_json(j, c);
    ok = true;
  } catch (...) {
    ok = false;
  }
  return c;
}

Config load_config() {
  Config c;
  std::ifstream f(paths::config_file());
  if (!f) return c; // defaults
  std::stringstream ss;
  ss << f.rdbuf();
  bool ok = false;
  c = config_from_raw(ss.str(), ok);
  if (!ok) c = Config{}; // corrupt config → factory defaults; integrity module flags the file
  return c;
}

void save_config(const Config& c) {
  std::ofstream f(paths::config_file(), std::ios::binary | std::ios::trunc);
  if (f) f << config_to_raw(c);
}

} // namespace sfs4
