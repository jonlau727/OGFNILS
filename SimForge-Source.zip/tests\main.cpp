// sfs4_tests — automated suite for Phase 1 sim/core + Phase 2 crypto/licensing
// primitives. Exit code 0 = all pass; nonzero = failures (CTest-compatible).
#include "core/ed25519.hpp"
#include "core/integrity.hpp"
#include "core/license.hpp"
#include "common/config.hpp"
#include "common/profiles.hpp"
#include "companion/ogfnil.hpp"
#include "sim/targets.hpp"
#include "sim/camera.hpp"
#include "sim/cvlab.hpp"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>

#include <cstdio>
#include <cstring>
#include <cmath>
#include <string>
#include <vector>

using namespace sfs4;

static int g_pass = 0, g_fail = 0;

#define CHECK(cond, name) do { \
  if (cond) { ++g_pass; } \
  else { ++g_fail; fprintf(stderr, "[FAIL] %s (line %d)\n", name, __LINE__); } \
} while (0)

static void test_ed25519_roundtrip() {
  uint8_t pub[sfs4::ed::PUB], sec[sfs4::ed::SEC];
  CHECK(sfs4::ed::keypair(pub, sec), "ed25519 keypair");

  const std::string msg = "simforge-s4|tester|device|1700000000|0|pro";
  uint8_t sig[sfs4::ed::SIG];
  CHECK(sfs4::ed::sign(sec, msg, sig), "ed25519 sign");
  CHECK(sfs4::ed::verify(pub, msg, sig), "ed25519 verify accepts valid");

  // tamper: one byte flipped in the message
  std::string bad = msg;
  bad[3] = (char)(bad[3] ^ 1);
  CHECK(!sfs4::ed::verify(pub, bad, sig), "ed25519 rejects tampered message");

  // tamper: one byte flipped in the signature
  uint8_t badsig[sfs4::ed::SIG];
  std::memcpy(badsig, sig, sizeof(badsig));
  badsig[10] ^= 0x40;
  CHECK(!sfs4::ed::verify(pub, msg, badsig), "ed25519 rejects tampered signature");

  // base64 roundtrip (with whitespace tolerated on decode)
  const std::vector<uint8_t> raw = {0, 1, 2, 250, 251, 252, 253, 254, 255, 77};
  const std::string enc = sfs4::ed::b64_encode(raw.data(), raw.size());
  std::vector<uint8_t> dec;
  CHECK(sfs4::ed::b64_decode(enc, dec) && dec == raw, "base64 roundtrip");
  CHECK(sfs4::ed::b64_decode(enc.substr(0, 4) + "\n" + enc.substr(4), dec) && dec == raw,
        "base64 tolerates embedded whitespace");
}

static void test_sha256_vector() {
  // FIPS 180-4 vector: SHA-256("abc")
  std::string hex;
  CHECK(integrity::sha256_bytes("abc", hex), "sha256_bytes runs");
  CHECK(hex == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
        "sha256('abc') matches FIPS vector");
}

static void test_license_canonical() {
  lic::Fields f;
  f.product = "simforge-s4"; f.licensee = "ada lovelace";
  f.device_id = "deadbeefdeadbeefdeadbeefdeadbeef";
  f.issued = 1700000000; f.expires = 1800000000; f.plan = "pro";
  CHECK(lic::canonical(f) ==
        "simforge-s4|ada lovelace|deadbeefdeadbeefdeadbeefdeadbeef|1700000000|1800000000|pro",
        "license canonical string format");

  lic::Fields g = f;
  g.expires = 0;
  CHECK(lic::canonical(g) ==
        "simforge-s4|ada lovelace|deadbeefdeadbeefdeadbeefdeadbeef|1700000000|0|pro",
        "license canonical: zero expiry serialized as 0");
}

static void test_license_verify_paths() {
  // Sign a license with a fresh key, then verify canonical + reject tamper.
  uint8_t pub[sfs4::ed::PUB], sec[sfs4::ed::SEC];
  CHECK(sfs4::ed::keypair(pub, sec), "license test keypair");

  lic::Fields f;
  f.product = "simforge-s4"; f.licensee = "tester";
  f.device_id = "*"; f.issued = 1700000000; f.expires = 0; f.plan = "standard";
  uint8_t sig[sfs4::ed::SIG];
  CHECK(sfs4::ed::sign(sec, lic::canonical(f), sig), "license sign");
  CHECK(sfs4::ed::verify(pub, lic::canonical(f), sig), "license verify ok");

  lic::Fields g = f;
  g.plan = "dev";   // plan escalation must break the signature
  CHECK(!sfs4::ed::verify(pub, lic::canonical(g), sig), "license verify rejects plan swap");

  lic::Fields h = f;
  h.device_id = "otherdevice";   // device rebinding must break the signature
  CHECK(!sfs4::ed::verify(pub, lic::canonical(h), sig), "license verify rejects device swap");
}

static void test_manifest_canonical() {
  // updater canonical = version|url|sha256 — verify sign/verify/tamper here
  // (the network path is exercised in integration, not unit tests).
  uint8_t pub[sfs4::ed::PUB], sec[sfs4::ed::SEC];
  CHECK(sfs4::ed::keypair(pub, sec), "manifest test keypair");

  const std::string canon = "2|https://updates.example.com/s4-2.bin|"
      "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
  uint8_t sig[sfs4::ed::SIG];
  CHECK(sfs4::ed::sign(sec, canon, sig), "manifest sign");
  CHECK(sfs4::ed::verify(pub, canon, sig), "manifest verify ok");

  std::string tampered = canon;
  tampered[tampered.size() - 1] = '0';   // hash digit swap
  CHECK(!sfs4::ed::verify(pub, tampered, sig), "manifest verify rejects hash swap");
}

static void test_config_roundtrip() {
  Config c;
  c.advanced_mode = true;
  c.aura_alpha = 0.66f;
  c.aim_fov_deg = 23.5f;
  c.reaction_ms = 220;
  c.target_count = 17;
  c.api_base = "http://127.0.0.1:8085";
  c.cv_lab = true;

  bool ok = false;
  const Config back = config_from_raw(config_to_raw(c), ok);
  CHECK(ok, "config raw parse");
  CHECK(back.advanced_mode == c.advanced_mode, "config roundtrip: mode");
  CHECK(std::fabs(back.aura_alpha - c.aura_alpha) < 1e-4f, "config roundtrip: aura_alpha");
  CHECK(std::fabs(back.aim_fov_deg - c.aim_fov_deg) < 1e-4f, "config roundtrip: aim fov");
  CHECK(back.reaction_ms == c.reaction_ms, "config roundtrip: reaction_ms");
  CHECK(back.target_count == c.target_count, "config roundtrip: target_count");
  CHECK(back.api_base == c.api_base, "config roundtrip: api_base");
  CHECK(back.cv_lab == c.cv_lab, "config roundtrip: cv_lab flag");

  // clamps
  Config bad;
  bad.reaction_ms = 99999;
  bad.target_count = 100000;
  bad.target_hz = -5;
  bool ok2 = false;
  const Config clamped = config_from_raw(config_to_raw(bad), ok2);
  CHECK(ok2 && clamped.reaction_ms <= 900, "config clamp: reaction_ms");
  CHECK(ok2 && clamped.target_count <= 64, "config clamp: target_count");
  CHECK(ok2 && clamped.target_hz >= 0, "config clamp: target_hz");
}

static void test_targets() {
  sim::TargetField field;
  field.config(12, 8.f, 45.f);
  field.reset(1337);
  const size_t n = field.all().size();
  CHECK(n == 12, "field population matches config");

  // determinism: same seed -> same layout
  sim::TargetField f2;
  f2.config(12, 8.f, 45.f);
  f2.reset(1337);
  bool same = f2.all().size() == n;
  for (size_t i = 0; same && i < n; ++i) {
    const glm::vec3 a = field.all()[i].pos, b = f2.all()[i].pos;
    same = std::fabs(a.x - b.x) < 1e-4f && std::fabs(a.y - b.y) < 1e-4f &&
           std::fabs(a.z - b.z) < 1e-4f;
  }
  CHECK(same, "field reset is deterministic per seed");

  // damage/kill/respawn — shield absorbs before hp
  field.tick(0.016f, {0, 0, 0});
  const float shield0 = field.all()[0].shield;
  const int hp_before = field.all()[0].hp;
  field.apply_damage(0, shield0 * 0.5f);
  CHECK(field.all()[0].hp == hp_before, "shield absorbs before hp");
  CHECK(std::fabs(field.all()[0].shield - shield0 * 0.5f) < 0.01f, "shield depletes");

  // lethal damage = remaining shield + full hp
  const bool killed = field.apply_damage(
      0, field.all()[0].shield + (float)field.all()[0].hp);
  CHECK(killed, "lethal damage kills");
  CHECK(field.all()[0].hp == 0 && !field.all()[0].alive, "dead target state");

  // advance past respawn delay -> target returns alive with full hp
  for (int i = 0; i < 600; ++i) field.tick(0.016f, {0, 0, 0});
  CHECK(field.alive_count() == 12, "all targets respawn within window");
}

static void test_w2s() {
  sim::Camera cam;
  cam.pos = {0, 1.62f, 0};
  cam.fov_deg = 90.f;
  const glm::mat4 vp = cam.vp(16.f / 9.f);

  float sx = 0, sy = 0;
  // straight ahead, slightly below eye: on-screen, near center
  CHECK(sim::world_to_screen({0.f, 1.0f, 10.f}, vp, 1600, 900, sx, sy), "w2s: front point projects");
  CHECK(std::fabs(sx - 800.f) < 2.f, "w2s: centered horizontally");
  CHECK(sy > 450.f && sy < 500.f, "w2s: below eye maps below center");

  // behind the camera must fail
  CHECK(!sim::world_to_screen({0.f, 1.f, -10.f}, vp, 1600, 900, sx, sy), "w2s: behind camera rejected");
}

static void test_cvlab() {
  cvlab::Frame f;
  cvlab::generate_frame(7, 320, 240, f);
  CHECK(f.rgb.size() == (size_t)320 * 240 * 3, "cvlab frame buffer size");
  CHECK(f.ground_truth.size() >= 3 && f.ground_truth.size() <= 6, "cvlab target count in range");

  // determinism
  cvlab::Frame g;
  cvlab::generate_frame(7, 320, 240, g);
  CHECK(std::memcmp(f.rgb.data(), g.rgb.data(), f.rgb.size()) == 0, "cvlab frames deterministic");

  // baseline detector finds the planted targets
  std::vector<cvlab::Rect> dets;
  double ms = 0;
  CHECK(cvlab::detect_pure(f, dets, ms), "cvlab baseline detect runs");
  const cvlab::Metrics m = cvlab::score(f, dets);
  CHECK(m.true_pos >= 3, "cvlab baseline detects planted targets");
  CHECK(m.mean_iou > 0.5f, "cvlab baseline IoU sane");

  // benchmark path (pure C++ here; OpenCV path when built with SFS4_WITH_OPENCV)
  cvlab::Metrics bm;
  const std::string err = cvlab::run_benchmark(10, 1, 320, 240, bm);
  CHECK(err.empty(), "cvlab benchmark completes");
  CHECK(bm.frames == 10, "cvlab benchmark frame count");
}

static void test_ogfnil() {
  // 1) Toolhelp scan finds this very process (hermetic — no external deps)
  wchar_t exe[MAX_PATH]{};
  GetModuleFileNameW(nullptr, exe, MAX_PATH);
  const wchar_t* base = exe;
  for (const wchar_t* c = exe; *c; ++c) if (*c == L'\\') base = c + 1;
  const auto procs = ogfnil::find_processes_by_name(base);
  bool self_found = false;
  for (const auto& p : procs) if (p.pid == GetCurrentProcessId()) self_found = true;
  CHECK(self_found, "toolhelp scan finds own process");

  // 2) version resource parsing on a stable system file
  const std::wstring v = ogfnil::file_version(L"C:\\Windows\\System32\\kernel32.dll");
  CHECK(!v.empty() && v.find(L'.') != std::wstring::npos, "file version resource parsed");

  // 3) transition state machine (pure logic, synthetic observations)
  ogfnil::TargetState st;
  std::string ev;
  ogfnil::apply_observation(st, {}, false, true, "game", ev);
  CHECK(st.state == ogfnil::ProcState::Stopped, "first observation: stopped");

  const std::vector<ogfnil::ProcessInfo> one{{4242}};
  const ogfnil::Transition t1 = ogfnil::apply_observation(st, one, true, false, "game", ev);
  CHECK(t1 == ogfnil::Transition::Started && st.pids.size() == 1 &&
        st.pids[0] == 4242 && ev.find("restarted") != std::string::npos,
        "running transition counts as restart");

  const ogfnil::Transition t2 = ogfnil::apply_observation(st, {}, false, false, "game", ev);
  CHECK(t2 == ogfnil::Transition::Stopped && st.unexpected_exit &&
        ev.find("unexpected") != std::string::npos, "unexpected exit flagged");

  const unsigned r = st.restarts;
  ogfnil::apply_observation(st, one, true, false, "game", ev);
  CHECK(st.restarts == r + 1, "restart counter increments");

  // name match but path mismatch -> not our target
  ogfnil::TargetState st2;
  ogfnil::apply_observation(st2, one, false, true, "game", ev);
  CHECK(st2.state == ogfnil::ProcState::Stopped, "path mismatch ignored");

  // clean exit (first observation on a stopped field) never flags unexpected
  ogfnil::TargetState st3;
  st3.state = ogfnil::ProcState::Stopped;
  ogfnil::apply_observation(st3, {}, false, false, "game", ev);
  CHECK(!st3.unexpected_exit, "clean stop keeps exit flag clear");
}

static void test_profiles() {
  Config a;
  a.esp_boxes = false;
  a.target_count = 7;
  a.aim_fov_deg = 33.f;
  std::string err;
  CHECK(profiles::save(a, L"test-profile-x", err), "profile save");
  CHECK(err.empty(), "profile save error empty");

  Config b;
  CHECK(profiles::load(L"test-profile-x", b, err), "profile load");
  CHECK(b.esp_boxes == false && b.target_count == 7 && b.aim_fov_deg == 33.f,
        "profile roundtrip");

  Config missing;
  CHECK(!profiles::load(L"no-such-profile-zz", missing, err) && !err.empty(),
        "missing profile fails clean");

  // apply_sim copies the sim subset, preserves server + companion fields
  Config dst;
  dst.api_base = "https://keep";
  dst.ogfnil_launcher_path = "keep-launcher";
  dst.ogfnil_auto_profile = true;
  profiles::apply_sim(dst, b);
  CHECK(dst.target_count == 7 && dst.aim_fov_deg == 33.f && dst.esp_boxes == false,
        "apply_sim copies sim fields");
  CHECK(dst.api_base == "https://keep" && dst.ogfnil_launcher_path == "keep-launcher" &&
        dst.ogfnil_auto_profile == true, "apply_sim preserves server + companion");

  // profile names sanitize path separators
  CHECK(profiles::save(a, L"bad/name:here", err), "sanitized name saves");

  CHECK(profiles::remove(L"test-profile-x"), "profile cleanup 1");
  CHECK(profiles::remove(L"bad_name_here"), "profile cleanup 2");
  CHECK(!profiles::remove(L"test-profile-x"), "double remove reports false");
}

static void test_config_ogfnil_roundtrip() {
  Config c;
  c.ogfnil_launcher_path = "C:/x/launcher.exe";
  c.ogfnil_game_path = "C:/y/game.exe";
  c.ogfnil_monitor = false;
  c.ogfnil_profile = "p1";
  c.ogfnil_auto_profile = true;
  bool ok = false;
  const Config d = config_from_raw(config_to_raw(c), ok);
  CHECK(ok, "ogfnil config parses");
  CHECK(d.ogfnil_launcher_path == "C:/x/launcher.exe" &&
        d.ogfnil_game_path == "C:/y/game.exe" &&
        d.ogfnil_monitor == false &&
        d.ogfnil_profile == "p1" &&
        d.ogfnil_auto_profile == true, "ogfnil config roundtrip");
}

int main() {
  test_ed25519_roundtrip();
  test_sha256_vector();
  test_license_canonical();
  test_license_verify_paths();
  test_manifest_canonical();
  test_config_roundtrip();
  test_targets();
  test_w2s();
  test_cvlab();
  test_ogfnil();
  test_profiles();
  test_config_ogfnil_roundtrip();

  printf("sfs4_tests: %d passed, %d failed\n", g_pass, g_fail);
  return g_fail == 0 ? 0 : 1;
}
