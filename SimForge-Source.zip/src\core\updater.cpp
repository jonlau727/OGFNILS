#include "core/updater.hpp"
#include "core/ed25519.hpp"
#include "core/integrity.hpp"
#include "common/net.hpp"
#include "common/paths.hpp"
#include "common/log.hpp"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <shellapi.h>
#include <nlohmann/json.hpp>
#include <fstream>
#include <sstream>

#pragma comment(lib, "shell32.lib")

using json = nlohmann::json;

namespace sfs4::upd {

static constexpr long long CURRENT_VERSION = 1;   // manifest version units

std::optional<Manifest> check(const std::string& update_url, std::string& reason) {
  reason.clear();
  if (update_url.empty()) { reason = "update endpoint not configured"; return std::nullopt; }

  const net::Response r = net::get(update_url);
  if (r.status == 0) { reason = "manifest fetch failed: " + r.error; return std::nullopt; }
  if (!r.ok()) { reason = "manifest fetch returned " + std::to_string(r.status); return std::nullopt; }

  json j;
  try { j = json::parse(r.body); }
  catch (...) { reason = "manifest unparseable"; return std::nullopt; }

  Manifest m;
  try {
    m.version = j.at("version").get<long long>();
    m.url     = j.at("url").get<std::string>();
    m.sha256  = j.at("sha256").get<std::string>();
    m.sig     = j.at("sig").get<std::string>();
  } catch (...) { reason = "manifest missing required fields"; return std::nullopt; }

  // Canonical = version|url|sha256 (identical on the signing tool side).
  std::ostringstream canon;
  canon << m.version << '|' << m.url << '|' << m.sha256;

  uint8_t pub[ed::PUB];
  std::string kerr;
  if (!ed::load_pub_file(paths::key_file(), pub, kerr)) {
    reason = "public key unavailable: " + kerr;
    return std::nullopt;
  }
  std::vector<uint8_t> sig;
  if (!ed::b64_decode(m.sig, sig) || sig.size() != ed::SIG) {
    reason = "manifest signature malformed";
    return std::nullopt;
  }
  if (!ed::verify(pub, canon.str(), sig.data())) {
    reason = "manifest signature rejected";
    return std::nullopt;
  }
  if (m.version <= CURRENT_VERSION) { reason = "no newer version available"; return std::nullopt; }
  return m;
}

bool stage(const Manifest& m, const std::filesystem::path& install_dir, std::string& err) {
  err.clear();
  const net::Response r = net::get(m.url);
  if (r.status == 0 || r.body.empty()) { err = "update download failed: " + r.error; return false; }

  std::string got;
  if (!integrity::sha256_bytes(r.body, got) || _stricmp(got.c_str(), m.sha256.c_str()) != 0) {
    err = "update hash mismatch - discarded (install dir untouched)";
    return false;
  }

  const std::filesystem::path stage_dir = paths::update_stage_dir();
  const std::filesystem::path exe = stage_dir / L"stage.exe";
  {
    std::ofstream f(exe, std::ios::binary | std::ios::trunc);
    f.write(r.body.data(), (std::streamsize)r.body.size());
    if (!f) { err = "staging write failed"; return false; }
  }

  // Atomic swap + rollback. Elevated because the install dir is usually
  // Program Files. Sequence: wait for this process to exit, move current exe
  // to .old, move staged exe in, start it; on any failure restore .old.
  const std::filesystem::path cmd = stage_dir / L"apply-update.cmd";
  const std::string app = (install_dir / L"SimForgeS4.exe").string();
  const std::string old = (install_dir / L"SimForgeS4.exe.old").string();
  std::ostringstream bat;
  bat << "@echo off\r\n"
      << "ping -n 3 127.0.0.1 >nul\r\n"
      << "move /y \"" << app << "\" \"" << old << "\" >nul\r\n"
      << "if errorlevel 1 goto :rollback_done\r\n"
      << "move /y \"" << exe.string() << "\" \"" << app << "\" >nul\r\n"
      << "if errorlevel 1 (\r\n"
      << "  move /y \"" << old << "\" \"" << app << "\" >nul\r\n"
      << "  exit /b 1\r\n"
      << ")\r\n"
      << "start \"\" \"" << app << "\" --updated\r\n"
      << "ping -n 6 127.0.0.1 >nul\r\n"
      << "tasklist /FI \"IMAGENAME eq SimForgeS4.exe\" | find /I \"SimForgeS4.exe\" >nul\r\n"
      << "if errorlevel 1 (\r\n"
      << "  del \"" << app << "\" >nul 2>&1\r\n"
      << "  move /y \"" << old << "\" \"" << app << "\" >nul\r\n"
      << "  exit /b 1\r\n"
      << ")\r\n"
      << "del \"" << old << "\" >nul 2>&1\r\n"
      << ":rollback_done\r\n"
      << "exit /b 0\r\n";
  std::ofstream f(cmd, std::ios::binary | std::ios::trunc);
  if (!f) { err = "apply script write failed"; return false; }
  f << bat.str();
  return true;
}

bool apply_staged(const std::filesystem::path& install_dir) {
  (void)install_dir;   // apply script paths are absolute; param kept for API symmetry
  const std::filesystem::path cmd = paths::update_stage_dir() / L"apply-update.cmd";
  if (!std::filesystem::exists(cmd)) return false;

  std::wstring params = L"/c \"" + cmd.wstring() + L"\"";
  SHELLEXECUTEINFOW sei{sizeof(sei)};
  sei.lpVerb = L"runas";                 // install dir may be Program Files
  sei.lpFile = L"cmd.exe";
  sei.lpParameters = params.c_str();
  sei.nShow = SW_HIDE;
  if (!ShellExecuteExW(&sei)) {
    log::warn("update: failed to launch apply script");
    return false;
  }
  log::info("update: apply script launched");
  return true;
}

} // namespace sfs4::upd
