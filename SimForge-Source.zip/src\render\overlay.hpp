#pragma once
// HUD + ESP drawing over the synthetic scene. ImGui draw-list based; every
// call is scoped to our own window, never to another application's.
#include "common/config.hpp"
#include "core/license.hpp"
#include "sim/targets.hpp"
#include "sim/camera.hpp"
#include "sim/aimsim.hpp"
#include "sim/cvlab.hpp"
#include <glm/glm.hpp>
#include <atomic>
#include <string>
#include <vector>

namespace sfs4::ui {

// Per-target screen data prepared once per frame in main.cpp.
struct TargetDraw {
  bool  visible = false;
  float dist_m = 0.f;
  float sx[(int)sim::Bone::Count] = {};
  float sy[(int)sim::Bone::Count] = {};
  bool  on_screen[(int)sim::Bone::Count] = {};
  int   hp = 0;
  float shield = 0.f;
  int   index = 0;
  int   kind = 0;   // sim::TargetKind
};

struct FrameData {
  std::vector<TargetDraw> targets;
  float w = 0.f, h = 0.f;
  // CV Lab inset: last detector output on the synthetic frame, drawn in a
  // mini-viewport (bottom-right) so research output never mixes with the
  // game-world overlay.
  std::vector<cvlab::Rect> cv_boxes;
  cvlab::Metrics cv_metrics;
};

int sim_alive_count(const FrameData& fd);

void draw_esp(const Config& cfg, const FrameData& fd);
void draw_aim_overlay(const Config& cfg, const sim::AimSim& aim, const FrameData& fd);
void draw_stats(const Config& cfg, const FrameData& fd, const sim::AimSim& aim,
                float fps, float avg_ms, float p99_ms, float cpu_pct, const std::wstring& gpu);
void draw_cv_inset(const Config& cfg, const FrameData& fd);
void draw_settings(Config& cfg, sim::TargetField& field, float session_t);
void draw_license_banner(const sfs4::lic::Fields* lic, bool dev_mode);

// CV Lab benchmark state, shared between the settings UI and the worker
// thread in app/main.cpp. Guarded by atomics; metrics/error copied after
// completion.
extern std::atomic<bool> cv_bench_request;
extern std::atomic<bool> cv_bench_active;
extern std::atomic<bool> cv_bench_done;
extern std::string cv_bench_error;
extern cvlab::Metrics cv_bench_metrics;

} // namespace sfs4::ui
