#pragma once
// Filesystem layout helpers. Everything is rooted next to the executable or
// under %LOCALAPPDATA%\SimForgeS4 so an installer-drop works portably.
#include <filesystem>
#include <string>

namespace sfs4::paths {

std::filesystem::path exe_path();
std::filesystem::path exe_dir();

std::filesystem::path app_data_dir();      // %LOCALAPPDATA%\SimForgeS4  (created on demand)
std::filesystem::path log_file();
std::filesystem::path config_file();       // config.json, next to the exe
std::filesystem::path config_hmac_file();  // %LOCALAPPDATA%\SimForgeS4\config.hmac
std::filesystem::path integrity_key_file();// %LOCALAPPDATA%\SimForgeS4\integrity.key (DPAPI blob)
std::filesystem::path key_file();          // verify.pub (XML public key), next to exe
std::filesystem::path license_file();      // license.sfs4.json, next to exe
std::filesystem::path session_file();      // %LOCALAPPDATA%\SimForgeS4\session.bin (DPAPI cache)
std::filesystem::path update_stage_dir();

} // namespace sfs4::paths

namespace sfs4 {
std::string to_narrow(const std::wstring& w);
std::wstring to_wide(const std::string& s);
}
