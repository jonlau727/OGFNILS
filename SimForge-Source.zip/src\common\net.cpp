#include "common/net.hpp"

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <winhttp.h>
#include <vector>

#pragma comment(lib, "winhttp.lib")

namespace sfs4::net {

namespace {

constexpr DWORD kMaxBody = 16u << 20;   // 16 MiB response ceiling

struct UrlParts {
  std::wstring host, path;
  unsigned short port = 443;
  bool https = true;
};

bool crack(const std::string& in, UrlParts& out) {
  // URLs are ASCII in this product; widen defensively.
  const std::wstring w(in.begin(), in.end());
  URL_COMPONENTS uc{};
  uc.dwStructSize = sizeof(uc);
  wchar_t host[256]{}, path[2048]{};
  uc.lpszHostName = host; uc.dwHostNameLength = 255;
  uc.lpszUrlPath = path; uc.dwUrlPathLength = 2047;
  if (!WinHttpCrackUrl(w.c_str(), (DWORD)w.size(), 0, &uc)) return false;
  out.host = host;
  out.path = path;
  out.port = uc.nPort;
  out.https = (uc.nScheme == INTERNET_SCHEME_HTTPS);
  return true;
}

} // namespace

Response request(const std::string& method, const std::string& url,
                 const std::string& body, const std::string& content_type) {
  Response r;
  UrlParts u;
  if (!crack(url, u)) { r.error = "bad url"; return r; }

  const std::wstring wmethod(method.begin(), method.end());
  const std::wstring wctype(content_type.begin(), content_type.end());

  HINTERNET hs = WinHttpOpen(L"SimForgeS4/0.2",
                             WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                             WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
  if (!hs) { r.error = "winhttp open failed"; return r; }
  WinHttpSetTimeouts(hs, 10000, 10000, 10000, 30000);

  HINTERNET hc = WinHttpConnect(hs, u.host.c_str(), u.port, 0);
  HINTERNET hr = nullptr;
  if (hc) {
    hr = WinHttpOpenRequest(hc, wmethod.c_str(), u.path.c_str(), nullptr,
                            WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
                            u.https ? WINHTTP_FLAG_SECURE : 0);
  }
  if (!hr) {
    r.error = "request setup failed";
    if (hc) WinHttpCloseHandle(hc);
    WinHttpCloseHandle(hs);
    return r;
  }

  const void* payload = body.empty() ? WINHTTP_NO_REQUEST_DATA : body.data();
  const DWORD payload_len = (DWORD)body.size();
  LPCWSTR extra_hdr = body.empty() ? WINHTTP_NO_ADDITIONAL_HEADERS : L"Content-Type: application/json\r\n";

  if (WinHttpSendRequest(hr, extra_hdr, (DWORD)-1L,
                         (LPVOID)payload, payload_len, payload_len, 0) &&
      WinHttpReceiveResponse(hr, nullptr)) {
    DWORD status = 0, sz = sizeof(status);
    WinHttpQueryHeaders(hr, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                        WINHTTP_HEADER_NAME_BY_INDEX, &status, &sz, WINHTTP_NO_HEADER_INDEX);
    r.status = status;
    size_t total = 0;
    for (;;) {
      DWORD avail = 0;
      if (!WinHttpQueryDataAvailable(hr, &avail) || avail == 0) break;
      if (total + avail > kMaxBody) { r.error = "response too large"; break; }
      std::vector<char> buf(avail);
      DWORD got = 0;
      if (!WinHttpReadData(hr, buf.data(), avail, &got) || got == 0) break;
      r.body.append(buf.data(), got);
      total += got;
    }
  } else {
    r.error = "send/receive failed (win32 " + std::to_string(GetLastError()) + ")";
  }

  WinHttpCloseHandle(hr);
  WinHttpCloseHandle(hc);
  WinHttpCloseHandle(hs);
  return r;
}

} // namespace sfs4::net
