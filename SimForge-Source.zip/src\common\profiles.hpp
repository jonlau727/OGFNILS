#pragma once
// Named configuration profiles stored under
//   %LocalAppData%\SimForgeS4\profiles\<name>.json
// A profile is a full Config snapshot in the same format as config.json.
// apply_sim() copies only the simulation-relevant subset, so loading a
// profile never clobbers server endpoints or companion paths.
#include "common/config.hpp"
#include <filesystem>
#include <string>
#include <vector>

namespace sfs4::profiles {

std::filesystem::path dir();

// Sorted list of profile names (without extension).
std::vector<std::wstring> list();

bool save(const Config& c, const std::wstring& name, std::string& err);
bool load(const std::wstring& name, Config& c, std::string& err);   // false + err when missing/corrupt
bool remove(const std::wstring& name);

// Copies the simulation subset (mode/esp/aim/trigger/world/camera/perf/cvlab)
// from src into dst. Server + OGFNIL companion fields in dst are preserved.
void apply_sim(Config& dst, const Config& src);

} // namespace sfs4::profiles
